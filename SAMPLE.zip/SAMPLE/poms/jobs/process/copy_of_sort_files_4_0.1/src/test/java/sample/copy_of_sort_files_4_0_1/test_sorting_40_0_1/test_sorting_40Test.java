package sample.copy_of_sort_files_4_0_1.test_sorting_40_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.DataQualityDependencies;
import routines.Mathematical;
import routines.SQLike;
import routines.Numeric;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.DQTechnical;
import routines.StringHandling;
import routines.DataMasking;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
import org.junit.Test;
import static org.junit.Assert.assertTrue;

@SuppressWarnings("unused")
/**
 * Job: test_sorting_40Test Purpose: <br>
 * Description:  <br>
 * @author user@talend.com
 * @version 7.1.1.20181026_1147
 * @status 
 */
public class test_sorting_40Test implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset
			.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

			if (InputFile != null) {

				this.setProperty("InputFile", InputFile.toString());

			}

			if (OutputFile != null) {

				this.setProperty("OutputFile", OutputFile.toString());

			}

			if (Host != null) {

				this.setProperty("Host", Host.toString());

			}

			if (Port != null) {

				this.setProperty("Port", Port.toString());

			}

			if (Database != null) {

				this.setProperty("Database", Database.toString());

			}

			if (Username != null) {

				this.setProperty("Username", Username.toString());

			}

			if (Password != null) {

				this.setProperty("Password", Password.toString());

			}

			if (Table != null) {

				this.setProperty("Table", Table.toString());

			}

		}

		public String InputFile;

		public String getInputFile() {
			return this.InputFile;
		}

		public String OutputFile;

		public String getOutputFile() {
			return this.OutputFile;
		}

		public String Host;

		public String getHost() {
			return this.Host;
		}

		public String Port;

		public String getPort() {
			return this.Port;
		}

		public String Database;

		public String getDatabase() {
			return this.Database;
		}

		public String Username;

		public String getUsername() {
			return this.Username;
		}

		public String Password;

		public String getPassword() {
			return this.Password;
		}

		public String Table;

		public String getTable() {
			return this.Table;
		}
	}

	private ContextProperties context = new ContextProperties();

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "test_sorting_40";
	private final String projectName = "SAMPLE";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(
			java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources
				.entrySet()) {
			talendDataSources.put(
					dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry
							.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap
				.put(KEY_DB_DATASOURCES_RAW,
						new java.util.HashMap<String, javax.sql.DataSource>(
								dataSources));
	}

	LogCatcherUtils tLogCatcher_1 = new LogCatcherUtils();
	StatCatcherUtils tStatCatcher_1 = new StatCatcherUtils(
			"_N1QSUI6nEemJkYDSUKjW-w", "0.1");
	AssertCatcherUtils tAssertCatcher_1 = new AssertCatcherUtils();

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(
			new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent,
				final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null
						&& currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE",
							getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE",
						getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent
						+ " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					test_sorting_40Test.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass()
							.getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(test_sorting_40Test.this, new Object[] {
									e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
						tLogCatcher_1.addMessage("Java Exception",
								currentComponent, 6, e.getClass().getName()
										+ ":" + e.getMessage(), 1);
						tAssertCatcher_1Process(globalMap);
					}
				} catch (TalendException e) {
					// do nothing

				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tAssertCatcher_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tAssertCatcher_1Process(globalMap);
		}

		status = "failure";

		tAssertCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tAssertCatcher_1Process(globalMap);
		}

		status = "failure";

		tAssertCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUnite_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tAssertCatcher_1Process(globalMap);
		}

		status = "failure";

		tAssertCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tAssertCatcher_1Process(globalMap);
		}

		status = "failure";

		tAssertCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tAssertCatcher_1Process(globalMap);
		}

		status = "failure";

		tAssertCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogCatcher_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tAssertCatcher_1Process(globalMap);
		}

		status = "failure";

		tAssertCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tAssertCatcher_1Process(globalMap);
		}

		status = "failure";

		tAssertCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tStatCatcher_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tAssertCatcher_1Process(globalMap);
		}

		status = "failure";

		tAssertCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tAssertCatcher_1Process(globalMap);
		}

		status = "failure";

		tAssertCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAssertCatcher_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row1Struct implements
			routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_SAMPLE_test_sorting_40 = new byte[0];
		static byte[] commonByteArray_SAMPLE_test_sorting_40 = new byte[0];

		public java.util.Date Timestamp;

		public java.util.Date getTimestamp() {
			return this.Timestamp;
		}

		public String RunID;

		public String getRunID() {
			return this.RunID;
		}

		public Long Connection_node;

		public Long getConnection_node() {
			return this.Connection_node;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String log_type;

		public String getLog_type() {
			return this.log_type;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		public String Source_file;

		public String getSource_file() {
			return this.Source_file;
		}

		public String Target_file;

		public String getTarget_file() {
			return this.Target_file;
		}

		public Integer Row_count;

		public Integer getRow_count() {
			return this.Row_count;
		}

		public Integer Row_processed;

		public Integer getRow_processed() {
			return this.Row_processed;
		}

		public Integer Row_rejected;

		public Integer getRow_rejected() {
			return this.Row_rejected;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_test_sorting_40.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_test_sorting_40.length == 0) {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_test_sorting_40, 0, length);
				strReturn = new String(commonByteArray_SAMPLE_test_sorting_40,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_test_sorting_40) {

				try {

					int length = 0;

					this.Timestamp = readDate(dis);

					this.RunID = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Connection_node = null;
					} else {
						this.Connection_node = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.log_type = readString(dis);

					this.origin = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

					this.Source_file = readString(dis);

					this.Target_file = readString(dis);

					this.Row_count = readInteger(dis);

					this.Row_processed = readInteger(dis);

					this.Row_rejected = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.Timestamp, dos);

				// String

				writeString(this.RunID, dos);

				// Long

				if (this.Connection_node == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.Connection_node);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.log_type, dos);

				// String

				writeString(this.origin, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

				// String

				writeString(this.Source_file, dos);

				// String

				writeString(this.Target_file, dos);

				// Integer

				writeInteger(this.Row_count, dos);

				// Integer

				writeInteger(this.Row_processed, dos);

				// Integer

				writeInteger(this.Row_rejected, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Timestamp=" + String.valueOf(Timestamp));
			sb.append(",RunID=" + RunID);
			sb.append(",Connection_node=" + String.valueOf(Connection_node));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",log_type=" + log_type);
			sb.append(",origin=" + origin);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append(",Source_file=" + Source_file);
			sb.append(",Target_file=" + Target_file);
			sb.append(",Row_count=" + String.valueOf(Row_count));
			sb.append(",Row_processed=" + String.valueOf(Row_processed));
			sb.append(",Row_rejected=" + String.valueOf(Row_rejected));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row9Struct implements
			routines.system.IPersistableRow<row9Struct> {
		final static byte[] commonByteArrayLock_SAMPLE_test_sorting_40 = new byte[0];
		static byte[] commonByteArray_SAMPLE_test_sorting_40 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String log_type;

		public String getLog_type() {
			return this.log_type;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		public String Source_file;

		public String getSource_file() {
			return this.Source_file;
		}

		public String Target_file;

		public String getTarget_file() {
			return this.Target_file;
		}

		public Integer Row_count;

		public Integer getRow_count() {
			return this.Row_count;
		}

		public Integer Row_processed;

		public Integer getRow_processed() {
			return this.Row_processed;
		}

		public Integer Row_rejected;

		public Integer getRow_rejected() {
			return this.Row_rejected;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_test_sorting_40.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_test_sorting_40.length == 0) {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_test_sorting_40, 0, length);
				strReturn = new String(commonByteArray_SAMPLE_test_sorting_40,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_test_sorting_40) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.log_type = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

					this.Source_file = readString(dis);

					this.Target_file = readString(dis);

					this.Row_count = readInteger(dis);

					this.Row_processed = readInteger(dis);

					this.Row_rejected = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.log_type, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

				// String

				writeString(this.Source_file, dos);

				// String

				writeString(this.Target_file, dos);

				// Integer

				writeInteger(this.Row_count, dos);

				// Integer

				writeInteger(this.Row_processed, dos);

				// Integer

				writeInteger(this.Row_rejected, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",log_type=" + log_type);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",Source_file=" + Source_file);
			sb.append(",Target_file=" + Target_file);
			sb.append(",Row_count=" + String.valueOf(Row_count));
			sb.append(",Row_processed=" + String.valueOf(Row_processed));
			sb.append(",Row_rejected=" + String.valueOf(Row_rejected));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row9Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Assert_DataStruct implements
			routines.system.IPersistableRow<Assert_DataStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_test_sorting_40 = new byte[0];
		static byte[] commonByteArray_SAMPLE_test_sorting_40 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String log_type;

		public String getLog_type() {
			return this.log_type;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		public String Source_file;

		public String getSource_file() {
			return this.Source_file;
		}

		public String Target_file;

		public String getTarget_file() {
			return this.Target_file;
		}

		public Integer Row_count;

		public Integer getRow_count() {
			return this.Row_count;
		}

		public Integer Row_processed;

		public Integer getRow_processed() {
			return this.Row_processed;
		}

		public Integer Row_rejected;

		public Integer getRow_rejected() {
			return this.Row_rejected;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_test_sorting_40.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_test_sorting_40.length == 0) {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_test_sorting_40, 0, length);
				strReturn = new String(commonByteArray_SAMPLE_test_sorting_40,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_test_sorting_40) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.log_type = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

					this.Source_file = readString(dis);

					this.Target_file = readString(dis);

					this.Row_count = readInteger(dis);

					this.Row_processed = readInteger(dis);

					this.Row_rejected = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.log_type, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

				// String

				writeString(this.Source_file, dos);

				// String

				writeString(this.Target_file, dos);

				// Integer

				writeInteger(this.Row_count, dos);

				// Integer

				writeInteger(this.Row_processed, dos);

				// Integer

				writeInteger(this.Row_rejected, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",log_type=" + log_type);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",Source_file=" + Source_file);
			sb.append(",Target_file=" + Target_file);
			sb.append(",Row_count=" + String.valueOf(Row_count));
			sb.append(",Row_processed=" + String.valueOf(Row_processed));
			sb.append(",Row_rejected=" + String.valueOf(Row_rejected));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Assert_DataStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row6Struct implements
			routines.system.IPersistableRow<row6Struct> {
		final static byte[] commonByteArrayLock_SAMPLE_test_sorting_40 = new byte[0];
		static byte[] commonByteArray_SAMPLE_test_sorting_40 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String language;

		public String getLanguage() {
			return this.language;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String status;

		public String getStatus() {
			return this.status;
		}

		public String substatus;

		public String getSubstatus() {
			return this.substatus;
		}

		public String description;

		public String getDescription() {
			return this.description;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_test_sorting_40.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_test_sorting_40.length == 0) {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_test_sorting_40, 0, length);
				strReturn = new String(commonByteArray_SAMPLE_test_sorting_40,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_test_sorting_40) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.project = readString(dis);

					this.job = readString(dis);

					this.language = readString(dis);

					this.origin = readString(dis);

					this.status = readString(dis);

					this.substatus = readString(dis);

					this.description = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.language, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.status, dos);

				// String

				writeString(this.substatus, dos);

				// String

				writeString(this.description, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",language=" + language);
			sb.append(",origin=" + origin);
			sb.append(",status=" + status);
			sb.append(",substatus=" + substatus);
			sb.append(",description=" + description);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row6Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class logDataStruct implements
			routines.system.IPersistableRow<logDataStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_test_sorting_40 = new byte[0];
		static byte[] commonByteArray_SAMPLE_test_sorting_40 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String log_type;

		public String getLog_type() {
			return this.log_type;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		public String Source_file;

		public String getSource_file() {
			return this.Source_file;
		}

		public String Target_file;

		public String getTarget_file() {
			return this.Target_file;
		}

		public Integer Row_count;

		public Integer getRow_count() {
			return this.Row_count;
		}

		public Integer Row_processed;

		public Integer getRow_processed() {
			return this.Row_processed;
		}

		public Integer Row_rejected;

		public Integer getRow_rejected() {
			return this.Row_rejected;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_test_sorting_40.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_test_sorting_40.length == 0) {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_test_sorting_40, 0, length);
				strReturn = new String(commonByteArray_SAMPLE_test_sorting_40,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_test_sorting_40) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.log_type = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

					this.Source_file = readString(dis);

					this.Target_file = readString(dis);

					this.Row_count = readInteger(dis);

					this.Row_processed = readInteger(dis);

					this.Row_rejected = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.log_type, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

				// String

				writeString(this.Source_file, dos);

				// String

				writeString(this.Target_file, dos);

				// Integer

				writeInteger(this.Row_count, dos);

				// Integer

				writeInteger(this.Row_processed, dos);

				// Integer

				writeInteger(this.Row_rejected, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",log_type=" + log_type);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",Source_file=" + Source_file);
			sb.append(",Target_file=" + Target_file);
			sb.append(",Row_count=" + String.valueOf(Row_count));
			sb.append(",Row_processed=" + String.valueOf(Row_processed));
			sb.append(",Row_rejected=" + String.valueOf(Row_rejected));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(logDataStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row4Struct implements
			routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_SAMPLE_test_sorting_40 = new byte[0];
		static byte[] commonByteArray_SAMPLE_test_sorting_40 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_test_sorting_40.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_test_sorting_40.length == 0) {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_test_sorting_40, 0, length);
				strReturn = new String(commonByteArray_SAMPLE_test_sorting_40,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_test_sorting_40) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					this.project = readString(dis);

					this.job = readString(dis);

					this.context = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.origin = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.context, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",context=" + context);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",origin=" + origin);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class StatDataStruct implements
			routines.system.IPersistableRow<StatDataStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_test_sorting_40 = new byte[0];
		static byte[] commonByteArray_SAMPLE_test_sorting_40 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String log_type;

		public String getLog_type() {
			return this.log_type;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		public String Source_file;

		public String getSource_file() {
			return this.Source_file;
		}

		public String Target_file;

		public String getTarget_file() {
			return this.Target_file;
		}

		public Integer Row_count;

		public Integer getRow_count() {
			return this.Row_count;
		}

		public Integer Row_processed;

		public Integer getRow_processed() {
			return this.Row_processed;
		}

		public Integer Row_rejected;

		public Integer getRow_rejected() {
			return this.Row_rejected;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_test_sorting_40.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_test_sorting_40.length == 0) {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_test_sorting_40, 0, length);
				strReturn = new String(commonByteArray_SAMPLE_test_sorting_40,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_test_sorting_40) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.log_type = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

					this.Source_file = readString(dis);

					this.Target_file = readString(dis);

					this.Row_count = readInteger(dis);

					this.Row_processed = readInteger(dis);

					this.Row_rejected = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.log_type, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

				// String

				writeString(this.Source_file, dos);

				// String

				writeString(this.Target_file, dos);

				// Integer

				writeInteger(this.Row_count, dos);

				// Integer

				writeInteger(this.Row_processed, dos);

				// Integer

				writeInteger(this.Row_rejected, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",log_type=" + log_type);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",Source_file=" + Source_file);
			sb.append(",Target_file=" + Target_file);
			sb.append(",Row_count=" + String.valueOf(Row_count));
			sb.append(",Row_processed=" + String.valueOf(Row_processed));
			sb.append(",Row_rejected=" + String.valueOf(Row_rejected));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(StatDataStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements
			routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_SAMPLE_test_sorting_40 = new byte[0];
		static byte[] commonByteArray_SAMPLE_test_sorting_40 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message_type;

		public String getMessage_type() {
			return this.message_type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_test_sorting_40.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_test_sorting_40.length == 0) {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_test_sorting_40 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_test_sorting_40, 0, length);
				strReturn = new String(commonByteArray_SAMPLE_test_sorting_40,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_test_sorting_40) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.father_pid = readString(dis);

					this.root_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.message_type = readString(dis);

					this.message = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.root_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message_type, dos);

				// String

				writeString(this.message, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",message_type=" + message_type);
			sb.append(",message=" + message);
			sb.append(",duration=" + String.valueOf(duration));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tAssertCatcher_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tAssertCatcher_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception()
						.getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row6Struct row6 = new row6Struct();
				Assert_DataStruct Assert_Data = new Assert_DataStruct();

				row3Struct row3 = new row3Struct();
				StatDataStruct StatData = new StatDataStruct();

				row4Struct row4 = new row4Struct();
				logDataStruct logData = new logDataStruct();

				row9Struct row9 = new row9Struct();
				row1Struct row1 = new row1Struct();

				/**
				 * [tDBOutput_2 begin ] start
				 */

				ok_Hash.put("tDBOutput_2", false);
				start_Hash.put("tDBOutput_2", System.currentTimeMillis());

				currentComponent = "tDBOutput_2";

				int tos_count_tDBOutput_2 = 0;

				int nb_line_tDBOutput_2 = 0;
				int nb_line_update_tDBOutput_2 = 0;
				int nb_line_inserted_tDBOutput_2 = 0;
				int nb_line_deleted_tDBOutput_2 = 0;
				int nb_line_rejected_tDBOutput_2 = 0;

				int deletedCount_tDBOutput_2 = 0;
				int updatedCount_tDBOutput_2 = 0;
				int insertedCount_tDBOutput_2 = 0;

				int rejectedCount_tDBOutput_2 = 0;

				String tableName_tDBOutput_2 = context.Table;
				boolean whetherReject_tDBOutput_2 = false;

				java.util.Calendar calendar_tDBOutput_2 = java.util.Calendar
						.getInstance();
				calendar_tDBOutput_2.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_2 = calendar_tDBOutput_2.getTime()
						.getTime();
				calendar_tDBOutput_2.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_2 = calendar_tDBOutput_2.getTime()
						.getTime();
				long date_tDBOutput_2;

				java.sql.Connection conn_tDBOutput_2 = null;
				String dbProperties_tDBOutput_2 = "useUnicode=true&characterEncoding=utf8";
				String url_tDBOutput_2 = null;
				if (dbProperties_tDBOutput_2 == null
						|| dbProperties_tDBOutput_2.trim().length() == 0) {
					url_tDBOutput_2 = "jdbc:mysql://" + context.Host + ":"
							+ context.Port + "/" + context.Database + "?"
							+ "rewriteBatchedStatements=true";
				} else {
					String properties_tDBOutput_2 = "useUnicode=true&characterEncoding=utf8";
					if (!properties_tDBOutput_2
							.contains("rewriteBatchedStatements")) {
						properties_tDBOutput_2 += "&rewriteBatchedStatements=true";
					}

					url_tDBOutput_2 = "jdbc:mysql://" + context.Host + ":"
							+ context.Port + "/" + context.Database + "?"
							+ properties_tDBOutput_2;
				}
				String driverClass_tDBOutput_2 = "com.mysql.cj.jdbc.Driver";

				String dbUser_tDBOutput_2 = context.Username;

				final String decryptedPassword_tDBOutput_2 = context.Password;

				String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;
				java.lang.Class.forName(driverClass_tDBOutput_2);

				conn_tDBOutput_2 = java.sql.DriverManager.getConnection(
						url_tDBOutput_2, dbUser_tDBOutput_2, dbPwd_tDBOutput_2);

				resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);
				conn_tDBOutput_2.setAutoCommit(false);
				int commitEvery_tDBOutput_2 = 10000;
				int commitCounter_tDBOutput_2 = 0;

				int count_tDBOutput_2 = 0;

				java.sql.DatabaseMetaData dbMetaData_tDBOutput_2 = conn_tDBOutput_2
						.getMetaData();
				boolean whetherExist_tDBOutput_2 = false;
				try (java.sql.ResultSet rsTable_tDBOutput_2 = dbMetaData_tDBOutput_2
						.getTables(context.Database, null, null,
								new String[] { "TABLE" })) {
					while (rsTable_tDBOutput_2.next()) {
						String table_tDBOutput_2 = rsTable_tDBOutput_2
								.getString("TABLE_NAME");
						if (table_tDBOutput_2.equalsIgnoreCase(context.Table)) {
							whetherExist_tDBOutput_2 = true;
							break;
						}
					}
				}
				if (!whetherExist_tDBOutput_2) {
					try (java.sql.Statement stmtCreate_tDBOutput_2 = conn_tDBOutput_2
							.createStatement()) {
						stmtCreate_tDBOutput_2
								.execute("CREATE TABLE `"
										+ tableName_tDBOutput_2
										+ "`(`Timestamp` DATETIME ,`RunID` VARCHAR(0)  ,`Connection_node` BIGINT(8)  ,`project` VARCHAR(50)  ,`job` VARCHAR(255)  ,`log_type` VARCHAR(100)  ,`origin` VARCHAR(255)  ,`priority` INT(3)  ,`type` VARCHAR(255)  ,`message` VARCHAR(255)  ,`code` INT(3)  ,`Source_file` VARCHAR(100)  ,`Target_file` VARCHAR(100)  ,`Row_count` INT(0)  ,`Row_processed` INT(0)  ,`Row_rejected` INT(0)  )");
					}
				}

				String insert_tDBOutput_2 = "INSERT INTO `"
						+ context.Table
						+ "` (`Timestamp`,`RunID`,`Connection_node`,`project`,`job`,`log_type`,`origin`,`priority`,`type`,`message`,`code`,`Source_file`,`Target_file`,`Row_count`,`Row_processed`,`Row_rejected`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				int batchSize_tDBOutput_2 = 100;
				int batchSizeCounter_tDBOutput_2 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2
						.prepareStatement(insert_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);

				/**
				 * [tDBOutput_2 begin ] stop
				 */

				/**
				 * [tMap_5 begin ] start
				 */

				ok_Hash.put("tMap_5", false);
				start_Hash.put("tMap_5", System.currentTimeMillis());

				currentComponent = "tMap_5";

				int tos_count_tMap_5 = 0;

				// ###############################
				// # Lookup's keys initialization
				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_5__Struct {
				}
				Var__tMap_5__Struct Var__tMap_5 = new Var__tMap_5__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				row1Struct row1_tmp = new row1Struct();
				// ###############################

				/**
				 * [tMap_5 begin ] stop
				 */

				/**
				 * [tUnite_1 begin ] start
				 */

				ok_Hash.put("tUnite_1", false);
				start_Hash.put("tUnite_1", System.currentTimeMillis());

				currentComponent = "tUnite_1";

				int tos_count_tUnite_1 = 0;

				int nb_line_tUnite_1 = 0;

				/**
				 * [tUnite_1 begin ] stop
				 */

				/**
				 * [tMap_4 begin ] start
				 */

				ok_Hash.put("tMap_4", false);
				start_Hash.put("tMap_4", System.currentTimeMillis());

				currentComponent = "tMap_4";

				int tos_count_tMap_4 = 0;

				// ###############################
				// # Lookup's keys initialization
				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_4__Struct {
				}
				Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				Assert_DataStruct Assert_Data_tmp = new Assert_DataStruct();
				// ###############################

				/**
				 * [tMap_4 begin ] stop
				 */

				/**
				 * [tAssertCatcher_1 begin ] start
				 */

				ok_Hash.put("tAssertCatcher_1", false);
				start_Hash.put("tAssertCatcher_1", System.currentTimeMillis());

				currentComponent = "tAssertCatcher_1";

				int tos_count_tAssertCatcher_1 = 0;

				for (AssertCatcherUtils.AssertCatcherMessage acm : tAssertCatcher_1
						.getMessages()) {
					row6.moment = acm.getMoment();
					row6.pid = acm.getPid();
					row6.project = acm.getProject();
					row6.job = acm.getJob();
					row6.language = acm.getLanguage();

					row6.origin = (acm.getOrigin() == null
							|| acm.getOrigin().length() < 1 ? null : acm
							.getOrigin());

					row6.status = acm.getStatus();
					row6.substatus = acm.getSubstatus();
					row6.description = acm.getDescription();

					/**
					 * [tAssertCatcher_1 begin ] stop
					 */

					/**
					 * [tAssertCatcher_1 main ] start
					 */

					currentComponent = "tAssertCatcher_1";

					tos_count_tAssertCatcher_1++;

					/**
					 * [tAssertCatcher_1 main ] stop
					 */

					/**
					 * [tAssertCatcher_1 process_data_begin ] start
					 */

					currentComponent = "tAssertCatcher_1";

					/**
					 * [tAssertCatcher_1 process_data_begin ] stop
					 */

					/**
					 * [tMap_4 main ] start
					 */

					currentComponent = "tMap_4";

					boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;

					// ###############################
					// # Input tables (lookups)
					boolean rejectedInnerJoin_tMap_4 = false;
					boolean mainRowRejected_tMap_4 = false;

					// ###############################
					{ // start of Var scope

						// ###############################
						// # Vars tables

						Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
						// ###############################
						// # Output tables

						Assert_Data = null;

						// # Output table : 'Assert_Data'
						Assert_Data_tmp.moment = row6.moment;
						Assert_Data_tmp.pid = row6.pid;
						Assert_Data_tmp.root_pid = null;
						Assert_Data_tmp.father_pid = null;
						Assert_Data_tmp.system_pid = null;
						Assert_Data_tmp.project = row6.project;
						Assert_Data_tmp.job = row6.job;
						Assert_Data_tmp.job_repository_id = null;
						Assert_Data_tmp.job_version = null;
						Assert_Data_tmp.log_type = "Assert Log";
						Assert_Data_tmp.context = null;
						Assert_Data_tmp.origin = null;
						Assert_Data_tmp.priority = null;
						Assert_Data_tmp.type = null;
						Assert_Data_tmp.message = "Status" + row6.status
								+ "Substatus" + row6.substatus
								+ row6.description;
						Assert_Data_tmp.code = null;
						Assert_Data_tmp.duration = null;
						Assert_Data_tmp.Source_file = context.InputFile;
						Assert_Data_tmp.Target_file = context.OutputFile;
						Assert_Data_tmp.Row_count = Relational
								.ISNULL((Integer) globalMap.get(row6.origin
										+ "_NB_LINE")) ? 0
								: ((Integer) globalMap.get(row6.origin
										+ "_NB_LINE"));
						Assert_Data_tmp.Row_processed = Relational
								.ISNULL((Integer) globalMap.get(row6.origin
										+ "_NB_LINE_INSERTED"))
								|| Relational.ISNULL((Integer) globalMap
										.get(row6.origin + "_NB_LINE_UPDATED"))
								|| Relational.ISNULL((Integer) globalMap
										.get(row6.origin + "_NB_LINE_DELETED")) ? 0
								: (((Integer) globalMap.get(row6.origin
										+ "_NB_LINE_INSERTED"))
										+ ((Integer) globalMap.get(row6.origin
												+ "_NB_LINE_UPDATED")) + ((Integer) globalMap
										.get(row6.origin + "_NB_LINE_DELETED")));
						Assert_Data_tmp.Row_rejected = Relational
								.ISNULL(((Integer) globalMap.get(row6.origin
										+ "_NB_LINE_REJECTED"))) ? 0
								: ((Integer) globalMap.get(row6.origin
										+ "_NB_LINE_REJECTED"));
						Assert_Data = Assert_Data_tmp;
						// ###############################

					} // end of Var scope

					rejectedInnerJoin_tMap_4 = false;

					tos_count_tMap_4++;

					/**
					 * [tMap_4 main ] stop
					 */

					/**
					 * [tMap_4 process_data_begin ] start
					 */

					currentComponent = "tMap_4";

					/**
					 * [tMap_4 process_data_begin ] stop
					 */
					// Start of branch "Assert_Data"
					if (Assert_Data != null) {

						/**
						 * [tUnite_1 main ] start
						 */

						currentComponent = "tUnite_1";

						// ////////

						// for output
						row9 = new row9Struct();

						row9.moment = Assert_Data.moment;
						row9.pid = Assert_Data.pid;
						row9.root_pid = Assert_Data.root_pid;
						row9.father_pid = Assert_Data.father_pid;
						row9.system_pid = Assert_Data.system_pid;
						row9.project = Assert_Data.project;
						row9.job = Assert_Data.job;
						row9.job_repository_id = Assert_Data.job_repository_id;
						row9.job_version = Assert_Data.job_version;
						row9.log_type = Assert_Data.log_type;
						row9.context = Assert_Data.context;
						row9.origin = Assert_Data.origin;
						row9.priority = Assert_Data.priority;
						row9.type = Assert_Data.type;
						row9.message = Assert_Data.message;
						row9.code = Assert_Data.code;
						row9.duration = Assert_Data.duration;
						row9.Source_file = Assert_Data.Source_file;
						row9.Target_file = Assert_Data.Target_file;
						row9.Row_count = Assert_Data.Row_count;
						row9.Row_processed = Assert_Data.Row_processed;
						row9.Row_rejected = Assert_Data.Row_rejected;

						nb_line_tUnite_1++;

						// ////////

						tos_count_tUnite_1++;

						/**
						 * [tUnite_1 main ] stop
						 */

						/**
						 * [tUnite_1 process_data_begin ] start
						 */

						currentComponent = "tUnite_1";

						/**
						 * [tUnite_1 process_data_begin ] stop
						 */

						/**
						 * [tMap_5 main ] start
						 */

						currentComponent = "tMap_5";

						boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;

						// ###############################
						// # Input tables (lookups)
						boolean rejectedInnerJoin_tMap_5 = false;
						boolean mainRowRejected_tMap_5 = false;

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
							// ###############################
							// # Output tables

							row1 = null;

							// # Output table : 'row1'
							row1_tmp.Timestamp = null;
							row1_tmp.RunID = null;
							row1_tmp.Connection_node = null;
							row1_tmp.project = null;
							row1_tmp.job = null;
							row1_tmp.log_type = null;
							row1_tmp.origin = null;
							row1_tmp.priority = null;
							row1_tmp.type = null;
							row1_tmp.message = null;
							row1_tmp.code = null;
							row1_tmp.Source_file = null;
							row1_tmp.Target_file = null;
							row1_tmp.Row_count = null;
							row1_tmp.Row_processed = null;
							row1_tmp.Row_rejected = null;
							row1 = row1_tmp;
							// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_5 = false;

						tos_count_tMap_5++;

						/**
						 * [tMap_5 main ] stop
						 */

						/**
						 * [tMap_5 process_data_begin ] start
						 */

						currentComponent = "tMap_5";

						/**
						 * [tMap_5 process_data_begin ] stop
						 */
						// Start of branch "row1"
						if (row1 != null) {

							/**
							 * [tDBOutput_2 main ] start
							 */

							currentComponent = "tDBOutput_2";

							whetherReject_tDBOutput_2 = false;
							if (row1.Timestamp != null) {
								date_tDBOutput_2 = row1.Timestamp.getTime();
								if (date_tDBOutput_2 < year1_tDBOutput_2
										|| date_tDBOutput_2 >= year10000_tDBOutput_2) {
									pstmt_tDBOutput_2.setString(1,
											"0000-00-00 00:00:00");
								} else {
									pstmt_tDBOutput_2.setTimestamp(1,
											new java.sql.Timestamp(
													date_tDBOutput_2));
								}
							} else {
								pstmt_tDBOutput_2.setNull(1,
										java.sql.Types.DATE);
							}

							if (row1.RunID == null) {
								pstmt_tDBOutput_2.setNull(2,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(2, row1.RunID);
							}

							if (row1.Connection_node == null) {
								pstmt_tDBOutput_2.setNull(3,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setLong(3,
										row1.Connection_node);
							}

							if (row1.project == null) {
								pstmt_tDBOutput_2.setNull(4,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(4, row1.project);
							}

							if (row1.job == null) {
								pstmt_tDBOutput_2.setNull(5,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(5, row1.job);
							}

							if (row1.log_type == null) {
								pstmt_tDBOutput_2.setNull(6,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(6, row1.log_type);
							}

							if (row1.origin == null) {
								pstmt_tDBOutput_2.setNull(7,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(7, row1.origin);
							}

							if (row1.priority == null) {
								pstmt_tDBOutput_2.setNull(8,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(8, row1.priority);
							}

							if (row1.type == null) {
								pstmt_tDBOutput_2.setNull(9,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(9, row1.type);
							}

							if (row1.message == null) {
								pstmt_tDBOutput_2.setNull(10,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(10, row1.message);
							}

							if (row1.code == null) {
								pstmt_tDBOutput_2.setNull(11,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(11, row1.code);
							}

							if (row1.Source_file == null) {
								pstmt_tDBOutput_2.setNull(12,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(12,
										row1.Source_file);
							}

							if (row1.Target_file == null) {
								pstmt_tDBOutput_2.setNull(13,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(13,
										row1.Target_file);
							}

							if (row1.Row_count == null) {
								pstmt_tDBOutput_2.setNull(14,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(14, row1.Row_count);
							}

							if (row1.Row_processed == null) {
								pstmt_tDBOutput_2.setNull(15,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2
										.setInt(15, row1.Row_processed);
							}

							if (row1.Row_rejected == null) {
								pstmt_tDBOutput_2.setNull(16,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(16, row1.Row_rejected);
							}

							pstmt_tDBOutput_2.addBatch();
							nb_line_tDBOutput_2++;

							batchSizeCounter_tDBOutput_2++;
							if (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2) {
								try {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
											.executeBatch()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 == java.sql.Statement.EXECUTE_FAILED ? 0
												: 1);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
								} catch (java.sql.BatchUpdateException e) {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : e
											.getUpdateCounts()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
												: countEach_tDBOutput_2);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									System.err.println(e.getMessage());
								}

								batchSizeCounter_tDBOutput_2 = 0;
							}
							commitCounter_tDBOutput_2++;

							if (commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {

								try {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
											.executeBatch()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
												: 1);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
								} catch (java.sql.BatchUpdateException e) {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : e
											.getUpdateCounts()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
												: countEach_tDBOutput_2);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									System.err.println(e.getMessage());

								}
								conn_tDBOutput_2.commit();
								commitCounter_tDBOutput_2 = 0;

							}

							tos_count_tDBOutput_2++;

							/**
							 * [tDBOutput_2 main ] stop
							 */

							/**
							 * [tDBOutput_2 process_data_begin ] start
							 */

							currentComponent = "tDBOutput_2";

							/**
							 * [tDBOutput_2 process_data_begin ] stop
							 */

							/**
							 * [tDBOutput_2 process_data_end ] start
							 */

							currentComponent = "tDBOutput_2";

							/**
							 * [tDBOutput_2 process_data_end ] stop
							 */

						} // End of branch "row1"

						/**
						 * [tMap_5 process_data_end ] start
						 */

						currentComponent = "tMap_5";

						/**
						 * [tMap_5 process_data_end ] stop
						 */

						/**
						 * [tUnite_1 process_data_end ] start
						 */

						currentComponent = "tUnite_1";

						/**
						 * [tUnite_1 process_data_end ] stop
						 */

					} // End of branch "Assert_Data"

					/**
					 * [tMap_4 process_data_end ] start
					 */

					currentComponent = "tMap_4";

					/**
					 * [tMap_4 process_data_end ] stop
					 */

					/**
					 * [tAssertCatcher_1 process_data_end ] start
					 */

					currentComponent = "tAssertCatcher_1";

					/**
					 * [tAssertCatcher_1 process_data_end ] stop
					 */

					/**
					 * [tAssertCatcher_1 end ] start
					 */

					currentComponent = "tAssertCatcher_1";

				}

				ok_Hash.put("tAssertCatcher_1", true);
				end_Hash.put("tAssertCatcher_1", System.currentTimeMillis());

				/**
				 * [tAssertCatcher_1 end ] stop
				 */

				/**
				 * [tMap_4 end ] start
				 */

				currentComponent = "tMap_4";

				// ###############################
				// # Lookup hashes releasing
				// ###############################

				ok_Hash.put("tMap_4", true);
				end_Hash.put("tMap_4", System.currentTimeMillis());

				/**
				 * [tMap_4 end ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				int tos_count_tMap_1 = 0;

				// ###############################
				// # Lookup's keys initialization
				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				StatDataStruct StatData_tmp = new StatDataStruct();
				// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tStatCatcher_1 begin ] start
				 */

				ok_Hash.put("tStatCatcher_1", false);
				start_Hash.put("tStatCatcher_1", System.currentTimeMillis());

				currentComponent = "tStatCatcher_1";

				int tos_count_tStatCatcher_1 = 0;

				for (StatCatcherUtils.StatCatcherMessage scm : tStatCatcher_1
						.getMessages()) {
					row3.pid = pid;
					row3.root_pid = rootPid;
					row3.father_pid = fatherPid;
					row3.project = projectName;
					row3.job = jobName;
					row3.context = contextStr;
					row3.origin = (scm.getOrigin() == null
							|| scm.getOrigin().length() < 1 ? null : scm
							.getOrigin());
					row3.message = scm.getMessage();
					row3.duration = scm.getDuration();
					row3.moment = scm.getMoment();
					row3.message_type = scm.getMessageType();
					row3.job_version = scm.getJobVersion();
					row3.job_repository_id = scm.getJobId();
					row3.system_pid = scm.getSystemPid();

					/**
					 * [tStatCatcher_1 begin ] stop
					 */

					/**
					 * [tStatCatcher_1 main ] start
					 */

					currentComponent = "tStatCatcher_1";

					tos_count_tStatCatcher_1++;

					/**
					 * [tStatCatcher_1 main ] stop
					 */

					/**
					 * [tStatCatcher_1 process_data_begin ] start
					 */

					currentComponent = "tStatCatcher_1";

					/**
					 * [tStatCatcher_1 process_data_begin ] stop
					 */

					/**
					 * [tMap_1 main ] start
					 */

					currentComponent = "tMap_1";

					boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

					// ###############################
					// # Input tables (lookups)
					boolean rejectedInnerJoin_tMap_1 = false;
					boolean mainRowRejected_tMap_1 = false;

					// ###############################
					{ // start of Var scope

						// ###############################
						// # Vars tables

						Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
						// ###############################
						// # Output tables

						StatData = null;

						// # Output table : 'StatData'
						StatData_tmp.moment = row3.moment;
						StatData_tmp.pid = row3.pid;
						StatData_tmp.root_pid = row3.root_pid;
						StatData_tmp.father_pid = row3.father_pid;
						StatData_tmp.system_pid = row3.system_pid;
						StatData_tmp.project = row3.project;
						StatData_tmp.job = row3.job;
						StatData_tmp.job_repository_id = row3.job_repository_id;
						StatData_tmp.job_version = null;
						StatData_tmp.log_type = "Statistics Log";
						StatData_tmp.context = row3.context;
						StatData_tmp.origin = row3.origin;
						StatData_tmp.priority = null;
						StatData_tmp.type = row3.message_type;
						StatData_tmp.message = row3.message;
						StatData_tmp.code = null;
						StatData_tmp.duration = row3.duration;
						StatData_tmp.Source_file = context.InputFile;
						StatData_tmp.Target_file = context.OutputFile;
						StatData_tmp.Row_count = Relational
								.ISNULL((Integer) globalMap.get(row3.origin
										+ "_NB_LINE")) ? 0
								: ((Integer) globalMap.get(row3.origin
										+ "_NB_LINE"));
						StatData_tmp.Row_processed = Relational
								.ISNULL((Integer) globalMap.get(row3.origin
										+ "_NB_LINE_INSERTED"))
								|| Relational.ISNULL((Integer) globalMap
										.get(row3.origin + "_NB_LINE_UPDATED"))
								|| Relational.ISNULL((Integer) globalMap
										.get(row3.origin + "_NB_LINE_DELETED")) ? 0
								: (((Integer) globalMap.get(row3.origin
										+ "_NB_LINE_INSERTED"))
										+ ((Integer) globalMap.get(row3.origin
												+ "_NB_LINE_UPDATED")) + ((Integer) globalMap
										.get(row3.origin + "_NB_LINE_DELETED")));
						StatData_tmp.Row_rejected = Relational
								.ISNULL((Integer) globalMap.get(row3.origin
										+ "_NB_LINE_REJECTED")) ? 0
								: ((Integer) globalMap.get(row3.origin
										+ "_NB_LINE_REJECTED"));
						StatData = StatData_tmp;
						// ###############################

					} // end of Var scope

					rejectedInnerJoin_tMap_1 = false;

					tos_count_tMap_1++;

					/**
					 * [tMap_1 main ] stop
					 */

					/**
					 * [tMap_1 process_data_begin ] start
					 */

					currentComponent = "tMap_1";

					/**
					 * [tMap_1 process_data_begin ] stop
					 */
					// Start of branch "StatData"
					if (StatData != null) {

						/**
						 * [tUnite_1 main ] start
						 */

						currentComponent = "tUnite_1";

						// ////////

						// for output
						row9 = new row9Struct();

						row9.moment = StatData.moment;
						row9.pid = StatData.pid;
						row9.root_pid = StatData.root_pid;
						row9.father_pid = StatData.father_pid;
						row9.system_pid = StatData.system_pid;
						row9.project = StatData.project;
						row9.job = StatData.job;
						row9.job_repository_id = StatData.job_repository_id;
						row9.job_version = StatData.job_version;
						row9.log_type = StatData.log_type;
						row9.context = StatData.context;
						row9.origin = StatData.origin;
						row9.priority = StatData.priority;
						row9.type = StatData.type;
						row9.message = StatData.message;
						row9.code = StatData.code;
						row9.duration = StatData.duration;
						row9.Source_file = StatData.Source_file;
						row9.Target_file = StatData.Target_file;
						row9.Row_count = StatData.Row_count;
						row9.Row_processed = StatData.Row_processed;
						row9.Row_rejected = StatData.Row_rejected;

						nb_line_tUnite_1++;

						// ////////

						tos_count_tUnite_1++;

						/**
						 * [tUnite_1 main ] stop
						 */

						/**
						 * [tUnite_1 process_data_begin ] start
						 */

						currentComponent = "tUnite_1";

						/**
						 * [tUnite_1 process_data_begin ] stop
						 */

						/**
						 * [tMap_5 main ] start
						 */

						currentComponent = "tMap_5";

						boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;

						// ###############################
						// # Input tables (lookups)
						boolean rejectedInnerJoin_tMap_5 = false;
						boolean mainRowRejected_tMap_5 = false;

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
							// ###############################
							// # Output tables

							row1 = null;

							// # Output table : 'row1'
							row1_tmp.Timestamp = null;
							row1_tmp.RunID = null;
							row1_tmp.Connection_node = null;
							row1_tmp.project = null;
							row1_tmp.job = null;
							row1_tmp.log_type = null;
							row1_tmp.origin = null;
							row1_tmp.priority = null;
							row1_tmp.type = null;
							row1_tmp.message = null;
							row1_tmp.code = null;
							row1_tmp.Source_file = null;
							row1_tmp.Target_file = null;
							row1_tmp.Row_count = null;
							row1_tmp.Row_processed = null;
							row1_tmp.Row_rejected = null;
							row1 = row1_tmp;
							// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_5 = false;

						tos_count_tMap_5++;

						/**
						 * [tMap_5 main ] stop
						 */

						/**
						 * [tMap_5 process_data_begin ] start
						 */

						currentComponent = "tMap_5";

						/**
						 * [tMap_5 process_data_begin ] stop
						 */
						// Start of branch "row1"
						if (row1 != null) {

							/**
							 * [tDBOutput_2 main ] start
							 */

							currentComponent = "tDBOutput_2";

							whetherReject_tDBOutput_2 = false;
							if (row1.Timestamp != null) {
								date_tDBOutput_2 = row1.Timestamp.getTime();
								if (date_tDBOutput_2 < year1_tDBOutput_2
										|| date_tDBOutput_2 >= year10000_tDBOutput_2) {
									pstmt_tDBOutput_2.setString(1,
											"0000-00-00 00:00:00");
								} else {
									pstmt_tDBOutput_2.setTimestamp(1,
											new java.sql.Timestamp(
													date_tDBOutput_2));
								}
							} else {
								pstmt_tDBOutput_2.setNull(1,
										java.sql.Types.DATE);
							}

							if (row1.RunID == null) {
								pstmt_tDBOutput_2.setNull(2,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(2, row1.RunID);
							}

							if (row1.Connection_node == null) {
								pstmt_tDBOutput_2.setNull(3,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setLong(3,
										row1.Connection_node);
							}

							if (row1.project == null) {
								pstmt_tDBOutput_2.setNull(4,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(4, row1.project);
							}

							if (row1.job == null) {
								pstmt_tDBOutput_2.setNull(5,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(5, row1.job);
							}

							if (row1.log_type == null) {
								pstmt_tDBOutput_2.setNull(6,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(6, row1.log_type);
							}

							if (row1.origin == null) {
								pstmt_tDBOutput_2.setNull(7,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(7, row1.origin);
							}

							if (row1.priority == null) {
								pstmt_tDBOutput_2.setNull(8,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(8, row1.priority);
							}

							if (row1.type == null) {
								pstmt_tDBOutput_2.setNull(9,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(9, row1.type);
							}

							if (row1.message == null) {
								pstmt_tDBOutput_2.setNull(10,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(10, row1.message);
							}

							if (row1.code == null) {
								pstmt_tDBOutput_2.setNull(11,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(11, row1.code);
							}

							if (row1.Source_file == null) {
								pstmt_tDBOutput_2.setNull(12,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(12,
										row1.Source_file);
							}

							if (row1.Target_file == null) {
								pstmt_tDBOutput_2.setNull(13,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(13,
										row1.Target_file);
							}

							if (row1.Row_count == null) {
								pstmt_tDBOutput_2.setNull(14,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(14, row1.Row_count);
							}

							if (row1.Row_processed == null) {
								pstmt_tDBOutput_2.setNull(15,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2
										.setInt(15, row1.Row_processed);
							}

							if (row1.Row_rejected == null) {
								pstmt_tDBOutput_2.setNull(16,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(16, row1.Row_rejected);
							}

							pstmt_tDBOutput_2.addBatch();
							nb_line_tDBOutput_2++;

							batchSizeCounter_tDBOutput_2++;
							if (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2) {
								try {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
											.executeBatch()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 == java.sql.Statement.EXECUTE_FAILED ? 0
												: 1);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
								} catch (java.sql.BatchUpdateException e) {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : e
											.getUpdateCounts()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
												: countEach_tDBOutput_2);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									System.err.println(e.getMessage());
								}

								batchSizeCounter_tDBOutput_2 = 0;
							}
							commitCounter_tDBOutput_2++;

							if (commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {

								try {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
											.executeBatch()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
												: 1);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
								} catch (java.sql.BatchUpdateException e) {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : e
											.getUpdateCounts()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
												: countEach_tDBOutput_2);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									System.err.println(e.getMessage());

								}
								conn_tDBOutput_2.commit();
								commitCounter_tDBOutput_2 = 0;

							}

							tos_count_tDBOutput_2++;

							/**
							 * [tDBOutput_2 main ] stop
							 */

							/**
							 * [tDBOutput_2 process_data_begin ] start
							 */

							currentComponent = "tDBOutput_2";

							/**
							 * [tDBOutput_2 process_data_begin ] stop
							 */

							/**
							 * [tDBOutput_2 process_data_end ] start
							 */

							currentComponent = "tDBOutput_2";

							/**
							 * [tDBOutput_2 process_data_end ] stop
							 */

						} // End of branch "row1"

						/**
						 * [tMap_5 process_data_end ] start
						 */

						currentComponent = "tMap_5";

						/**
						 * [tMap_5 process_data_end ] stop
						 */

						/**
						 * [tUnite_1 process_data_end ] start
						 */

						currentComponent = "tUnite_1";

						/**
						 * [tUnite_1 process_data_end ] stop
						 */

					} // End of branch "StatData"

					/**
					 * [tMap_1 process_data_end ] start
					 */

					currentComponent = "tMap_1";

					/**
					 * [tMap_1 process_data_end ] stop
					 */

					/**
					 * [tStatCatcher_1 process_data_end ] start
					 */

					currentComponent = "tStatCatcher_1";

					/**
					 * [tStatCatcher_1 process_data_end ] stop
					 */

					/**
					 * [tStatCatcher_1 end ] start
					 */

					currentComponent = "tStatCatcher_1";

				}

				ok_Hash.put("tStatCatcher_1", true);
				end_Hash.put("tStatCatcher_1", System.currentTimeMillis());

				/**
				 * [tStatCatcher_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

				// ###############################
				// # Lookup hashes releasing
				// ###############################

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tMap_3 begin ] start
				 */

				ok_Hash.put("tMap_3", false);
				start_Hash.put("tMap_3", System.currentTimeMillis());

				currentComponent = "tMap_3";

				int tos_count_tMap_3 = 0;

				// ###############################
				// # Lookup's keys initialization
				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_3__Struct {
				}
				Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				logDataStruct logData_tmp = new logDataStruct();
				// ###############################

				/**
				 * [tMap_3 begin ] stop
				 */

				/**
				 * [tLogCatcher_1 begin ] start
				 */

				ok_Hash.put("tLogCatcher_1", false);
				start_Hash.put("tLogCatcher_1", System.currentTimeMillis());

				currentComponent = "tLogCatcher_1";

				int tos_count_tLogCatcher_1 = 0;

				try {
					for (LogCatcherUtils.LogCatcherMessage lcm : tLogCatcher_1
							.getMessages()) {
						row4.type = lcm.getType();
						row4.origin = (lcm.getOrigin() == null
								|| lcm.getOrigin().length() < 1 ? null : lcm
								.getOrigin());
						row4.priority = lcm.getPriority();
						row4.message = lcm.getMessage();
						row4.code = lcm.getCode();

						row4.moment = java.util.Calendar.getInstance()
								.getTime();

						row4.pid = pid;
						row4.root_pid = rootPid;
						row4.father_pid = fatherPid;

						row4.project = projectName;
						row4.job = jobName;
						row4.context = contextStr;

						/**
						 * [tLogCatcher_1 begin ] stop
						 */

						/**
						 * [tLogCatcher_1 main ] start
						 */

						currentComponent = "tLogCatcher_1";

						tos_count_tLogCatcher_1++;

						/**
						 * [tLogCatcher_1 main ] stop
						 */

						/**
						 * [tLogCatcher_1 process_data_begin ] start
						 */

						currentComponent = "tLogCatcher_1";

						/**
						 * [tLogCatcher_1 process_data_begin ] stop
						 */

						/**
						 * [tMap_3 main ] start
						 */

						currentComponent = "tMap_3";

						boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;

						// ###############################
						// # Input tables (lookups)
						boolean rejectedInnerJoin_tMap_3 = false;
						boolean mainRowRejected_tMap_3 = false;

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
							// ###############################
							// # Output tables

							logData = null;

							// # Output table : 'logData'
							logData_tmp.moment = row4.moment;
							logData_tmp.pid = row4.pid;
							logData_tmp.root_pid = row4.root_pid;
							logData_tmp.father_pid = row4.father_pid;
							logData_tmp.system_pid = null;
							logData_tmp.project = row4.project;
							logData_tmp.job = row4.job;
							logData_tmp.job_repository_id = null;
							logData_tmp.job_version = null;
							logData_tmp.log_type = "Error Log";
							logData_tmp.context = row4.context;
							logData_tmp.origin = row4.origin;
							logData_tmp.priority = row4.priority;
							logData_tmp.type = row4.type;
							logData_tmp.message = row4.message;
							logData_tmp.code = row4.code;
							logData_tmp.duration = null;
							logData_tmp.Source_file = context.InputFile;
							logData_tmp.Target_file = context.OutputFile;
							logData_tmp.Row_count = Relational
									.ISNULL(row4.origin) ? 0
									: ((Integer) globalMap.get(row4.origin
											+ "_NB_LINE"));
							logData_tmp.Row_processed = Relational
									.ISNULL((Integer) globalMap.get(row4.origin
											+ "_NB_LINE_INSERTED"))
									|| Relational.ISNULL((Integer) globalMap
											.get(row4.origin
													+ "_NB_LINE_UPDATED"))
									|| Relational.ISNULL((Integer) globalMap
											.get(row4.origin
													+ "_NB_LINE_DELETED")) ? 0
									: (((Integer) globalMap.get(row4.origin
											+ "_NB_LINE_INSERTED"))
											+ ((Integer) globalMap
													.get(row4.origin
															+ "_NB_LINE_UPDATED")) + ((Integer) globalMap
											.get(row4.origin
													+ "_NB_LINE_DELETED")));
							logData_tmp.Row_rejected = Relational
									.ISNULL(((Integer) globalMap
											.get(row4.origin
													+ "_NB_LINE_REJECTED"))) ? 0
									: ((Integer) globalMap.get(row4.origin
											+ "_NB_LINE_REJECTED"));
							logData = logData_tmp;
							// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_3 = false;

						tos_count_tMap_3++;

						/**
						 * [tMap_3 main ] stop
						 */

						/**
						 * [tMap_3 process_data_begin ] start
						 */

						currentComponent = "tMap_3";

						/**
						 * [tMap_3 process_data_begin ] stop
						 */
						// Start of branch "logData"
						if (logData != null) {

							/**
							 * [tUnite_1 main ] start
							 */

							currentComponent = "tUnite_1";

							// ////////

							// for output
							row9 = new row9Struct();

							row9.moment = logData.moment;
							row9.pid = logData.pid;
							row9.root_pid = logData.root_pid;
							row9.father_pid = logData.father_pid;
							row9.system_pid = logData.system_pid;
							row9.project = logData.project;
							row9.job = logData.job;
							row9.job_repository_id = logData.job_repository_id;
							row9.job_version = logData.job_version;
							row9.log_type = logData.log_type;
							row9.context = logData.context;
							row9.origin = logData.origin;
							row9.priority = logData.priority;
							row9.type = logData.type;
							row9.message = logData.message;
							row9.code = logData.code;
							row9.duration = logData.duration;
							row9.Source_file = logData.Source_file;
							row9.Target_file = logData.Target_file;
							row9.Row_count = logData.Row_count;
							row9.Row_processed = logData.Row_processed;
							row9.Row_rejected = logData.Row_rejected;

							nb_line_tUnite_1++;

							// ////////

							tos_count_tUnite_1++;

							/**
							 * [tUnite_1 main ] stop
							 */

							/**
							 * [tUnite_1 process_data_begin ] start
							 */

							currentComponent = "tUnite_1";

							/**
							 * [tUnite_1 process_data_begin ] stop
							 */

							/**
							 * [tMap_5 main ] start
							 */

							currentComponent = "tMap_5";

							boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_5 = false;
							boolean mainRowRejected_tMap_5 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
								// ###############################
								// # Output tables

								row1 = null;

								// # Output table : 'row1'
								row1_tmp.Timestamp = null;
								row1_tmp.RunID = null;
								row1_tmp.Connection_node = null;
								row1_tmp.project = null;
								row1_tmp.job = null;
								row1_tmp.log_type = null;
								row1_tmp.origin = null;
								row1_tmp.priority = null;
								row1_tmp.type = null;
								row1_tmp.message = null;
								row1_tmp.code = null;
								row1_tmp.Source_file = null;
								row1_tmp.Target_file = null;
								row1_tmp.Row_count = null;
								row1_tmp.Row_processed = null;
								row1_tmp.Row_rejected = null;
								row1 = row1_tmp;
								// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_5 = false;

							tos_count_tMap_5++;

							/**
							 * [tMap_5 main ] stop
							 */

							/**
							 * [tMap_5 process_data_begin ] start
							 */

							currentComponent = "tMap_5";

							/**
							 * [tMap_5 process_data_begin ] stop
							 */
							// Start of branch "row1"
							if (row1 != null) {

								/**
								 * [tDBOutput_2 main ] start
								 */

								currentComponent = "tDBOutput_2";

								whetherReject_tDBOutput_2 = false;
								if (row1.Timestamp != null) {
									date_tDBOutput_2 = row1.Timestamp.getTime();
									if (date_tDBOutput_2 < year1_tDBOutput_2
											|| date_tDBOutput_2 >= year10000_tDBOutput_2) {
										pstmt_tDBOutput_2.setString(1,
												"0000-00-00 00:00:00");
									} else {
										pstmt_tDBOutput_2.setTimestamp(1,
												new java.sql.Timestamp(
														date_tDBOutput_2));
									}
								} else {
									pstmt_tDBOutput_2.setNull(1,
											java.sql.Types.DATE);
								}

								if (row1.RunID == null) {
									pstmt_tDBOutput_2.setNull(2,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(2, row1.RunID);
								}

								if (row1.Connection_node == null) {
									pstmt_tDBOutput_2.setNull(3,
											java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setLong(3,
											row1.Connection_node);
								}

								if (row1.project == null) {
									pstmt_tDBOutput_2.setNull(4,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2
											.setString(4, row1.project);
								}

								if (row1.job == null) {
									pstmt_tDBOutput_2.setNull(5,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(5, row1.job);
								}

								if (row1.log_type == null) {
									pstmt_tDBOutput_2.setNull(6,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(6,
											row1.log_type);
								}

								if (row1.origin == null) {
									pstmt_tDBOutput_2.setNull(7,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(7, row1.origin);
								}

								if (row1.priority == null) {
									pstmt_tDBOutput_2.setNull(8,
											java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(8, row1.priority);
								}

								if (row1.type == null) {
									pstmt_tDBOutput_2.setNull(9,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(9, row1.type);
								}

								if (row1.message == null) {
									pstmt_tDBOutput_2.setNull(10,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(10,
											row1.message);
								}

								if (row1.code == null) {
									pstmt_tDBOutput_2.setNull(11,
											java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(11, row1.code);
								}

								if (row1.Source_file == null) {
									pstmt_tDBOutput_2.setNull(12,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(12,
											row1.Source_file);
								}

								if (row1.Target_file == null) {
									pstmt_tDBOutput_2.setNull(13,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(13,
											row1.Target_file);
								}

								if (row1.Row_count == null) {
									pstmt_tDBOutput_2.setNull(14,
											java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2
											.setInt(14, row1.Row_count);
								}

								if (row1.Row_processed == null) {
									pstmt_tDBOutput_2.setNull(15,
											java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(15,
											row1.Row_processed);
								}

								if (row1.Row_rejected == null) {
									pstmt_tDBOutput_2.setNull(16,
											java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(16,
											row1.Row_rejected);
								}

								pstmt_tDBOutput_2.addBatch();
								nb_line_tDBOutput_2++;

								batchSizeCounter_tDBOutput_2++;
								if (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2) {
									try {
										int countSum_tDBOutput_2 = 0;
										for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
												.executeBatch()) {
											countSum_tDBOutput_2 += (countEach_tDBOutput_2 == java.sql.Statement.EXECUTE_FAILED ? 0
													: 1);
										}
										insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									} catch (java.sql.BatchUpdateException e) {
										int countSum_tDBOutput_2 = 0;
										for (int countEach_tDBOutput_2 : e
												.getUpdateCounts()) {
											countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
													: countEach_tDBOutput_2);
										}
										insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
										System.err.println(e.getMessage());
									}

									batchSizeCounter_tDBOutput_2 = 0;
								}
								commitCounter_tDBOutput_2++;

								if (commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {

									try {
										int countSum_tDBOutput_2 = 0;
										for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
												.executeBatch()) {
											countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
													: 1);
										}
										insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									} catch (java.sql.BatchUpdateException e) {
										int countSum_tDBOutput_2 = 0;
										for (int countEach_tDBOutput_2 : e
												.getUpdateCounts()) {
											countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
													: countEach_tDBOutput_2);
										}
										insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
										System.err.println(e.getMessage());

									}
									conn_tDBOutput_2.commit();
									commitCounter_tDBOutput_2 = 0;

								}

								tos_count_tDBOutput_2++;

								/**
								 * [tDBOutput_2 main ] stop
								 */

								/**
								 * [tDBOutput_2 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_2";

								/**
								 * [tDBOutput_2 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_2 process_data_end ] start
								 */

								currentComponent = "tDBOutput_2";

								/**
								 * [tDBOutput_2 process_data_end ] stop
								 */

							} // End of branch "row1"

							/**
							 * [tMap_5 process_data_end ] start
							 */

							currentComponent = "tMap_5";

							/**
							 * [tMap_5 process_data_end ] stop
							 */

							/**
							 * [tUnite_1 process_data_end ] start
							 */

							currentComponent = "tUnite_1";

							/**
							 * [tUnite_1 process_data_end ] stop
							 */

						} // End of branch "logData"

						/**
						 * [tMap_3 process_data_end ] start
						 */

						currentComponent = "tMap_3";

						/**
						 * [tMap_3 process_data_end ] stop
						 */

						/**
						 * [tLogCatcher_1 process_data_end ] start
						 */

						currentComponent = "tLogCatcher_1";

						/**
						 * [tLogCatcher_1 process_data_end ] stop
						 */

						/**
						 * [tLogCatcher_1 end ] start
						 */

						currentComponent = "tLogCatcher_1";

					}
				} catch (Exception e_tLogCatcher_1) {
					logIgnoredError(
							String.format(
									"tLogCatcher_1 - tLogCatcher failed to process log message(s) due to internal error: %s",
									e_tLogCatcher_1), e_tLogCatcher_1);
				}

				ok_Hash.put("tLogCatcher_1", true);
				end_Hash.put("tLogCatcher_1", System.currentTimeMillis());

				/**
				 * [tLogCatcher_1 end ] stop
				 */

				/**
				 * [tMap_3 end ] start
				 */

				currentComponent = "tMap_3";

				// ###############################
				// # Lookup hashes releasing
				// ###############################

				ok_Hash.put("tMap_3", true);
				end_Hash.put("tMap_3", System.currentTimeMillis());

				/**
				 * [tMap_3 end ] stop
				 */

				/**
				 * [tUnite_1 end ] start
				 */

				currentComponent = "tUnite_1";

				globalMap.put("tUnite_1_NB_LINE", nb_line_tUnite_1);

				ok_Hash.put("tUnite_1", true);
				end_Hash.put("tUnite_1", System.currentTimeMillis());

				/**
				 * [tUnite_1 end ] stop
				 */

				/**
				 * [tMap_5 end ] start
				 */

				currentComponent = "tMap_5";

				// ###############################
				// # Lookup hashes releasing
				// ###############################

				ok_Hash.put("tMap_5", true);
				end_Hash.put("tMap_5", System.currentTimeMillis());

				/**
				 * [tMap_5 end ] stop
				 */

				/**
				 * [tDBOutput_2 end ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					if (batchSizeCounter_tDBOutput_2 != 0) {
						int countSum_tDBOutput_2 = 0;

						for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
								.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}

						insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

					}

				} catch (java.sql.BatchUpdateException e) {

					int countSum_tDBOutput_2 = 0;
					for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
								: countEach_tDBOutput_2);
					}

					insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

					globalMap.put(currentComponent + "_ERROR_MESSAGE",
							e.getMessage());
					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_2 = 0;

				if (pstmt_tDBOutput_2 != null) {

					pstmt_tDBOutput_2.close();
					resourceMap.remove("pstmt_tDBOutput_2");

				}
				resourceMap.put("statementClosed_tDBOutput_2", true);
				if (commitCounter_tDBOutput_2 > 0) {

					conn_tDBOutput_2.commit();

				}

				conn_tDBOutput_2.close();

				resourceMap.put("finish_tDBOutput_2", true);

				nb_line_deleted_tDBOutput_2 = nb_line_deleted_tDBOutput_2
						+ deletedCount_tDBOutput_2;
				nb_line_update_tDBOutput_2 = nb_line_update_tDBOutput_2
						+ updatedCount_tDBOutput_2;
				nb_line_inserted_tDBOutput_2 = nb_line_inserted_tDBOutput_2
						+ insertedCount_tDBOutput_2;
				nb_line_rejected_tDBOutput_2 = nb_line_rejected_tDBOutput_2
						+ rejectedCount_tDBOutput_2;

				globalMap.put("tDBOutput_2_NB_LINE", nb_line_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_UPDATED",
						nb_line_update_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_INSERTED",
						nb_line_inserted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_DELETED",
						nb_line_deleted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_REJECTED",
						nb_line_rejected_tDBOutput_2);

				ok_Hash.put("tDBOutput_2", true);
				end_Hash.put("tDBOutput_2", System.currentTimeMillis());

				/**
				 * [tDBOutput_2 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tAssertCatcher_1 finally ] start
				 */

				currentComponent = "tAssertCatcher_1";

				/**
				 * [tAssertCatcher_1 finally ] stop
				 */

				/**
				 * [tMap_4 finally ] start
				 */

				currentComponent = "tMap_4";

				/**
				 * [tMap_4 finally ] stop
				 */

				/**
				 * [tStatCatcher_1 finally ] start
				 */

				currentComponent = "tStatCatcher_1";

				/**
				 * [tStatCatcher_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tLogCatcher_1 finally ] start
				 */

				currentComponent = "tLogCatcher_1";

				/**
				 * [tLogCatcher_1 finally ] stop
				 */

				/**
				 * [tMap_3 finally ] start
				 */

				currentComponent = "tMap_3";

				/**
				 * [tMap_3 finally ] stop
				 */

				/**
				 * [tUnite_1 finally ] start
				 */

				currentComponent = "tUnite_1";

				/**
				 * [tUnite_1 finally ] stop
				 */

				/**
				 * [tMap_5 finally ] start
				 */

				currentComponent = "tMap_5";

				/**
				 * [tMap_5 finally ] stop
				 */

				/**
				 * [tDBOutput_2 finally ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
						if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_2")) != null) {
							pstmtToClose_tDBOutput_2.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_2") == null) {
						java.sql.Connection ctn_tDBOutput_2 = null;
						if ((ctn_tDBOutput_2 = (java.sql.Connection) resourceMap
								.get("conn_tDBOutput_2")) != null) {
							try {
								ctn_tDBOutput_2.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_2) {
								String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :"
										+ sqlEx_tDBOutput_2.getMessage();
								System.err.println(errorMessage_tDBOutput_2);
							}
						}
					}
				}

				/**
				 * [tDBOutput_2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tAssertCatcher_1_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	private PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final test_sorting_40Test test_sorting_40TestClass = new test_sorting_40Test();

		int exitCode = test_sorting_40TestClass.runJobInTOS(args);

		System.exit(exitCode);
	}

	@Test
	public void testDefault() throws java.lang.Exception {
		if (0 <= 0) {
			throw new java.lang.Exception(
					"There is no tAssert in your test case!");
		}
		junitGlobalMap.put("tests.log", new String());
		junitGlobalMap.put("tests.nbFailure", new Integer(0));
		final test_sorting_40Test test_sorting_40TestClass = new test_sorting_40Test();
		java.util.List<String> paraList_Default = new java.util.ArrayList<String>();
		paraList_Default.add("--context=Default");
		String[] arrays = new String[paraList_Default.size()];
		for (int i = 0; i < paraList_Default.size(); i++) {
			arrays[i] = (String) paraList_Default.get(i);
		}
		test_sorting_40TestClass.runJobInTOS(arrays);

		String errors = (String) junitGlobalMap.get("tests.log");
		Integer nbFailure = (Integer) junitGlobalMap.get("tests.nbFailure");
		assertTrue(
				"Failure=" + nbFailure
						+ java.lang.System.getProperty("line.separator")
						+ errors, errors.isEmpty());

		if (test_sorting_40TestClass.exception != null) {
			throw test_sorting_40TestClass.exception;
		}
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		try {
			// call job/subjob with an existing context, like:
			// --context=production. if without this parameter, there will use
			// the default context instead.
			java.io.InputStream inContext = test_sorting_40Test.class
					.getClassLoader().getResourceAsStream(
							"sample/copy_of_sort_files_4_0_1/test_sorting_40_0_1/contexts/"
									+ contextStr + ".properties");
			if (inContext == null) {
				inContext = test_sorting_40Test.class
						.getClassLoader()
						.getResourceAsStream(
								"config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				// defaultProps is in order to keep the original context value
				defaultProps.load(inContext);
				inContext.close();
				context = new ContextProperties(defaultProps);
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param
				// is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param
							.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			context.setContextType("InputFile", "id_String");

			context.InputFile = (String) context.getProperty("InputFile");
			context.setContextType("OutputFile", "id_String");

			context.OutputFile = (String) context.getProperty("OutputFile");
			context.setContextType("Host", "id_String");

			context.Host = (String) context.getProperty("Host");
			context.setContextType("Port", "id_String");

			context.Port = (String) context.getProperty("Port");
			context.setContextType("Database", "id_String");

			context.Database = (String) context.getProperty("Database");
			context.setContextType("Username", "id_String");

			context.Username = (String) context.getProperty("Username");
			context.setContextType("Password", "id_String");

			context.Password = (String) context.getProperty("Password");
			context.setContextType("Table", "id_String");

			context.Table = (String) context.getProperty("Table");
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
			if (parentContextMap.containsKey("InputFile")) {
				context.InputFile = (String) parentContextMap.get("InputFile");
			}
			if (parentContextMap.containsKey("OutputFile")) {
				context.OutputFile = (String) parentContextMap
						.get("OutputFile");
			}
			if (parentContextMap.containsKey("Host")) {
				context.Host = (String) parentContextMap.get("Host");
			}
			if (parentContextMap.containsKey("Port")) {
				context.Port = (String) parentContextMap.get("Port");
			}
			if (parentContextMap.containsKey("Database")) {
				context.Database = (String) parentContextMap.get("Database");
			}
			if (parentContextMap.containsKey("Username")) {
				context.Username = (String) parentContextMap.get("Username");
			}
			if (parentContextMap.containsKey("Password")) {
				context.Password = (String) parentContextMap.get("Password");
			}
			if (parentContextMap.containsKey("Table")) {
				context.Table = (String) parentContextMap.get("Table");
			}
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil
				.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName,
				jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName,
				parent_part_launcher, Thread.currentThread().getId() + "", "",
				"", "", "",
				resumeUtil.convertToJsonText(context, parametersToEncrypt));

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();
		tStatCatcher_1.addMessage("begin");

		this.globalResumeTicket = true;// to run tPreJob

		try {
			tAssertCatcher_1Process(globalMap);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}

		this.globalResumeTicket = false;// to run others jobs

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		if (false) {
			System.out
					.println((endUsedMemory - startUsedMemory)
							+ " bytes memory increase when running : test_sorting_40Test");
		}
		tStatCatcher_1.addMessage(status == "" ? "end" : status,
				(end - startTime));
		try {
			tAssertCatcher_1Process(globalMap);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}

		int returnCode = 0;
		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher,
				Thread.currentThread().getId() + "", "", "" + returnCode, "",
				"", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index),
							keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index),
							keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		}

	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" },
			{ "\\'", "\'" }, { "\\r", "\r" }, { "\\f", "\f" }, { "\\b", "\b" },
			{ "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex,
							index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left
			// into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 159987 characters generated by Talend Real-time Big Data Platform on the June
 * 15, 2019 12:05:28 AM IST
 ************************************************************************************************/
