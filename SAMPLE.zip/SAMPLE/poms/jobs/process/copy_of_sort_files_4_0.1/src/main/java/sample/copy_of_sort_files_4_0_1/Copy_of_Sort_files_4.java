package sample.copy_of_sort_files_4_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.Mathematical;
import routines.DataQualityDependencies;
import routines.SQLike;
import routines.Numeric;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.DQTechnical;
import routines.TalendDate;
import routines.DataMasking;
import routines.DqStringHandling;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

//the import part of tJava_1
import java.util.*;

@SuppressWarnings("unused")
/**
 * Job: Copy_of_Sort_files_4 Purpose: Sorting<br>
 * Description:  <br>
 * @author user@talend.com
 * @version 7.1.1.20181026_1147
 * @status 
 */
public class Copy_of_Sort_files_4 implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset
			.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

			if (InputFile != null) {

				this.setProperty("InputFile", InputFile.toString());

			}

			if (OutputFile != null) {

				this.setProperty("OutputFile", OutputFile.toString());

			}

			if (Host != null) {

				this.setProperty("Host", Host.toString());

			}

			if (Port != null) {

				this.setProperty("Port", Port.toString());

			}

			if (Database != null) {

				this.setProperty("Database", Database.toString());

			}

			if (Username != null) {

				this.setProperty("Username", Username.toString());

			}

			if (Password != null) {

				this.setProperty("Password", Password.toString());

			}

			if (Table != null) {

				this.setProperty("Table", Table.toString());

			}

		}

		public String InputFile;

		public String getInputFile() {
			return this.InputFile;
		}

		public String OutputFile;

		public String getOutputFile() {
			return this.OutputFile;
		}

		public String Host;

		public String getHost() {
			return this.Host;
		}

		public String Port;

		public String getPort() {
			return this.Port;
		}

		public String Database;

		public String getDatabase() {
			return this.Database;
		}

		public String Username;

		public String getUsername() {
			return this.Username;
		}

		public String Password;

		public String getPassword() {
			return this.Password;
		}

		public String Table;

		public String getTable() {
			return this.Table;
		}
	}

	private ContextProperties context = new ContextProperties();

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "Copy_of_Sort_files_4";
	private final String projectName = "SAMPLE";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(
			java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources
				.entrySet()) {
			talendDataSources.put(
					dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry
							.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap
				.put(KEY_DB_DATASOURCES_RAW,
						new java.util.HashMap<String, javax.sql.DataSource>(
								dataSources));
	}

	LogCatcherUtils tLogCatcher_1 = new LogCatcherUtils();
	LogCatcherUtils talendLogs_LOGS = new LogCatcherUtils();
	StatCatcherUtils tStatCatcher_1 = new StatCatcherUtils(
			"_jAKbsIz4EemHDMZDAQ4V7A", "0.1");
	StatCatcherUtils talendStats_STATS = new StatCatcherUtils(
			"_jAKbsIz4EemHDMZDAQ4V7A", "0.1");
	MetterCatcherUtils talendMeter_METTER = new MetterCatcherUtils(
			"_jAKbsIz4EemHDMZDAQ4V7A", "0.1");
	AssertCatcherUtils tAssertCatcher_1 = new AssertCatcherUtils();

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(
			new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent,
				final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null
						&& currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE",
							getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE",
						getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent
						+ " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					Copy_of_Sort_files_4.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass()
							.getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(Copy_of_Sort_files_4.this, new Object[] {
									e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
						tLogCatcher_1.addMessage("Java Exception",
								currentComponent, 6, e.getClass().getName()
										+ ":" + e.getMessage(), 1);
						talendLogs_LOGS.addMessage("Java Exception",
								currentComponent, 6, e.getClass().getName()
										+ ":" + e.getMessage(), 1);
						try {
							tLogCatcher_1Process(globalMap);
						} finally {
							talendLogs_LOGSProcess(globalMap);
						}
					}
				} catch (TalendException e) {
					// do nothing

				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tAssert_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		tStatCatcher_1.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		tLogCatcher_1Process(globalMap);

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		status = "failure";

		tAssert_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAssertCatcher_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUnite_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		tStatCatcher_1.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		tLogCatcher_1Process(globalMap);

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		tStatCatcher_1.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		tLogCatcher_1Process(globalMap);

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tFileOutputExcel_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		tStatCatcher_1.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		tLogCatcher_1Process(globalMap);

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tFileInputDelimited_2_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tContextLoad_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tJava_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tJava_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogCatcher_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tPrejob_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tStatCatcher_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_1_SortOut_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		tSortRow_1_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_1_SortIn_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		tStatCatcher_1.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		tLogCatcher_1Process(globalMap);

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void talendStats_STATS_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		talendStats_FILE_error(exception, errorComponent, globalMap);

	}

	public void talendStats_FILE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		talendStats_CONSOLE_error(exception, errorComponent, globalMap);

	}

	public void talendStats_CONSOLE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		talendStats_STATS_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendLogs_LOGS_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		talendLogs_FILE_error(exception, errorComponent, globalMap);

	}

	public void talendLogs_FILE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		talendLogs_CONSOLE_error(exception, errorComponent, globalMap);

	}

	public void talendLogs_CONSOLE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		talendLogs_LOGS_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendMeter_METTER_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		talendMeter_FILE_error(exception, errorComponent, globalMap);

	}

	public void talendMeter_FILE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		talendMeter_CONSOLE_error(exception, errorComponent, globalMap);

	}

	public void talendMeter_CONSOLE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		if (!(exception instanceof TDieException)) {

			tAssertCatcher_1.addMessage(pid, projectName, jobName, "java",
					null, "Failed", "Job execution error",
					exception.getMessage());

			tLogCatcher_1Process(globalMap);
		}

		status = "failure";

		talendMeter_METTER_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAssert_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_2_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tLogCatcher_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tPrejob_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendStats_STATS_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendLogs_LOGS_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendMeter_METTER_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tAssert_1Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tAssert_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception()
						.getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tAssert_1 begin ] start
				 */

				ok_Hash.put("tAssert_1", false);
				start_Hash.put("tAssert_1", System.currentTimeMillis());

				tStatCatcher_1.addMessage("begin", "tAssert_1");
				tLogCatcher_1Process(globalMap);

				talendStats_STATS.addMessage("begin", "tAssert_1");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tAssert_1";

				int tos_count_tAssert_1 = 0;

				/**
				 * [tAssert_1 begin ] stop
				 */

				/**
				 * [tAssert_1 main ] start
				 */

				currentComponent = "tAssert_1";

				if ((Integer) globalMap.get("tDBOutput_1_NB_LINE_INSERTED") >= 20) {
					tAssertCatcher_1.addMessage(pid, projectName, jobName,
							"java", "tAssert_1", "Ok", "--",
							"Item are more than 20");
					tLogCatcher_1Process(globalMap);
				} else {
					tAssertCatcher_1.addMessage(pid, projectName, jobName,
							"java", "tAssert_1", "Failed",
							"Test logically failed", "Item are more than 20");
					tLogCatcher_1Process(globalMap);
				}

				tos_count_tAssert_1++;

				/**
				 * [tAssert_1 main ] stop
				 */

				/**
				 * [tAssert_1 process_data_begin ] start
				 */

				currentComponent = "tAssert_1";

				/**
				 * [tAssert_1 process_data_begin ] stop
				 */

				/**
				 * [tAssert_1 process_data_end ] start
				 */

				currentComponent = "tAssert_1";

				/**
				 * [tAssert_1 process_data_end ] stop
				 */

				/**
				 * [tAssert_1 end ] start
				 */

				currentComponent = "tAssert_1";

				ok_Hash.put("tAssert_1", true);
				end_Hash.put("tAssert_1", System.currentTimeMillis());

				tStatCatcher_1
						.addMessage(
								"end",
								"tAssert_1",
								end_Hash.get("tAssert_1")
										- start_Hash.get("tAssert_1"));
				tLogCatcher_1Process(globalMap);
				talendStats_STATS
						.addMessage(
								"end",
								"tAssert_1",
								end_Hash.get("tAssert_1")
										- start_Hash.get("tAssert_1"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tAssert_1 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tAssert_1 finally ] start
				 */

				currentComponent = "tAssert_1";

				/**
				 * [tAssert_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tAssert_1_SUBPROCESS_STATE", 1);
	}

	public static class copyStruct implements
			routines.system.IPersistableRow<copyStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public String Region;

		public String getRegion() {
			return this.Region;
		}

		public String Rep;

		public String getRep() {
			return this.Rep;
		}

		public String Item;

		public String getItem() {
			return this.Item;
		}

		public Integer Units;

		public Integer getUnits() {
			return this.Units;
		}

		public String Unit_Cost;

		public String getUnit_Cost() {
			return this.Unit_Cost;
		}

		public String Total;

		public String getTotal() {
			return this.Total;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.Region = readString(dis);

					this.Rep = readString(dis);

					this.Item = readString(dis);

					this.Units = readInteger(dis);

					this.Unit_Cost = readString(dis);

					this.Total = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.Region, dos);

				// String

				writeString(this.Rep, dos);

				// String

				writeString(this.Item, dos);

				// Integer

				writeInteger(this.Units, dos);

				// String

				writeString(this.Unit_Cost, dos);

				// String

				writeString(this.Total, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Region=" + Region);
			sb.append(",Rep=" + Rep);
			sb.append(",Item=" + Item);
			sb.append(",Units=" + String.valueOf(Units));
			sb.append(",Unit_Cost=" + Unit_Cost);
			sb.append(",Total=" + Total);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(copyStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class mainmStruct implements
			routines.system.IPersistableRow<mainmStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public String Region;

		public String getRegion() {
			return this.Region;
		}

		public String Rep;

		public String getRep() {
			return this.Rep;
		}

		public String Item;

		public String getItem() {
			return this.Item;
		}

		public Integer Units;

		public Integer getUnits() {
			return this.Units;
		}

		public String Unit_Cost;

		public String getUnit_Cost() {
			return this.Unit_Cost;
		}

		public String Total;

		public String getTotal() {
			return this.Total;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.Region = readString(dis);

					this.Rep = readString(dis);

					this.Item = readString(dis);

					this.Units = readInteger(dis);

					this.Unit_Cost = readString(dis);

					this.Total = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.Region, dos);

				// String

				writeString(this.Rep, dos);

				// String

				writeString(this.Item, dos);

				// Integer

				writeInteger(this.Units, dos);

				// String

				writeString(this.Unit_Cost, dos);

				// String

				writeString(this.Total, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Region=" + Region);
			sb.append(",Rep=" + Rep);
			sb.append(",Item=" + Item);
			sb.append(",Units=" + String.valueOf(Units));
			sb.append(",Unit_Cost=" + Unit_Cost);
			sb.append(",Total=" + Total);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(mainmStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements
			routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public String Region;

		public String getRegion() {
			return this.Region;
		}

		public String Rep;

		public String getRep() {
			return this.Rep;
		}

		public String Item;

		public String getItem() {
			return this.Item;
		}

		public Integer Units;

		public Integer getUnits() {
			return this.Units;
		}

		public String Unit_Cost;

		public String getUnit_Cost() {
			return this.Unit_Cost;
		}

		public String Total;

		public String getTotal() {
			return this.Total;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.Region = readString(dis);

					this.Rep = readString(dis);

					this.Item = readString(dis);

					this.Units = readInteger(dis);

					this.Unit_Cost = readString(dis);

					this.Total = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.Region, dos);

				// String

				writeString(this.Rep, dos);

				// String

				writeString(this.Item, dos);

				// Integer

				writeInteger(this.Units, dos);

				// String

				writeString(this.Unit_Cost, dos);

				// String

				writeString(this.Total, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Region=" + Region);
			sb.append(",Rep=" + Rep);
			sb.append(",Item=" + Item);
			sb.append(",Units=" + String.valueOf(Units));
			sb.append(",Unit_Cost=" + Unit_Cost);
			sb.append(",Total=" + Total);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_1 implements
			routines.system.IPersistableRow<OnRowsEndStructtSortRow_1> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public String Region;

		public String getRegion() {
			return this.Region;
		}

		public String Rep;

		public String getRep() {
			return this.Rep;
		}

		public String Item;

		public String getItem() {
			return this.Item;
		}

		public Integer Units;

		public Integer getUnits() {
			return this.Units;
		}

		public String Unit_Cost;

		public String getUnit_Cost() {
			return this.Unit_Cost;
		}

		public String Total;

		public String getTotal() {
			return this.Total;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.Region = readString(dis);

					this.Rep = readString(dis);

					this.Item = readString(dis);

					this.Units = readInteger(dis);

					this.Unit_Cost = readString(dis);

					this.Total = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.Region, dos);

				// String

				writeString(this.Rep, dos);

				// String

				writeString(this.Item, dos);

				// Integer

				writeInteger(this.Units, dos);

				// String

				writeString(this.Unit_Cost, dos);

				// String

				writeString(this.Total, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Region=" + Region);
			sb.append(",Rep=" + Rep);
			sb.append(",Item=" + Item);
			sb.append(",Units=" + String.valueOf(Units));
			sb.append(",Unit_Cost=" + Unit_Cost);
			sb.append(",Total=" + Total);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_1 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements
			routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public String Region;

		public String getRegion() {
			return this.Region;
		}

		public String Rep;

		public String getRep() {
			return this.Rep;
		}

		public String Item;

		public String getItem() {
			return this.Item;
		}

		public Integer Units;

		public Integer getUnits() {
			return this.Units;
		}

		public String Unit_Cost;

		public String getUnit_Cost() {
			return this.Unit_Cost;
		}

		public String Total;

		public String getTotal() {
			return this.Total;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.Region = readString(dis);

					this.Rep = readString(dis);

					this.Item = readString(dis);

					this.Units = readInteger(dis);

					this.Unit_Cost = readString(dis);

					this.Total = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.Region, dos);

				// String

				writeString(this.Rep, dos);

				// String

				writeString(this.Item, dos);

				// Integer

				writeInteger(this.Units, dos);

				// String

				writeString(this.Unit_Cost, dos);

				// String

				writeString(this.Total, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Region=" + Region);
			sb.append(",Rep=" + Rep);
			sb.append(",Item=" + Item);
			sb.append(",Units=" + String.valueOf(Units));
			sb.append(",Unit_Cost=" + Unit_Cost);
			sb.append(",Total=" + Total);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception()
						.getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				row2Struct row2 = new row2Struct();
				copyStruct copy = new copyStruct();
				mainmStruct mainm = new mainmStruct();

				/**
				 * [tSortRow_1_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_1_SortOut", false);
				start_Hash
						.put("tSortRow_1_SortOut", System.currentTimeMillis());

				tStatCatcher_1.addMessage("begin", "tSortRow_1_SortOut");
				tLogCatcher_1Process(globalMap);

				talendStats_STATS.addMessage("begin", "tSortRow_1_SortOut");
				talendStats_STATSProcess(globalMap);

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortOut";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("row1" + iterateId, 0, 0);

					}
				}

				int tos_count_tSortRow_1_SortOut = 0;

				class Comparablerow1Struct extends row1Struct implements
						Comparable<Comparablerow1Struct> {

					public int compareTo(Comparablerow1Struct other) {

						if (this.Region == null && other.Region != null) {
							return -1;

						} else if (this.Region != null && other.Region == null) {
							return 1;

						} else if (this.Region != null && other.Region != null) {
							if (!this.Region.equals(other.Region)) {
								return this.Region.compareTo(other.Region);
							}
						}
						return 0;
					}
				}

				java.util.List<Comparablerow1Struct> list_tSortRow_1_SortOut = new java.util.ArrayList<Comparablerow1Struct>();

				/**
				 * [tSortRow_1_SortOut begin ] stop
				 */

				/**
				 * [tFileInputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_1", false);
				start_Hash.put("tFileInputDelimited_1",
						System.currentTimeMillis());

				tStatCatcher_1.addMessage("begin", "tFileInputDelimited_1");
				tLogCatcher_1Process(globalMap);

				talendStats_STATS.addMessage("begin", "tFileInputDelimited_1");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tFileInputDelimited_1";

				int tos_count_tFileInputDelimited_1 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				try {

					Object filename_tFileInputDelimited_1 = context.InputFile;
					if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
						if (footer_value_tFileInputDelimited_1 > 0
								|| random_value_tFileInputDelimited_1 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(
								context.InputFile, "ISO-8859-15", ",", "\n",
								true, 1, 0, -1, -1, false);
					} catch (java.lang.Exception e) {

						throw e;

					}

					while (fid_tFileInputDelimited_1 != null
							&& fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();

						row1 = null;

						boolean whetherReject_tFileInputDelimited_1 = false;
						row1 = new row1Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_1 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_1 = 0;

							row1.Region = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 1;

							row1.Rep = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 2;

							row1.Item = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 3;

							temp = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.Units = ParserUtils
											.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									rowstate_tFileInputDelimited_1
											.setException(new RuntimeException(
													String.format(
															"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
															"Units", "row1",
															temp,
															ex_tFileInputDelimited_1),
													ex_tFileInputDelimited_1));
								}

							} else {

								row1.Units = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 4;

							row1.Unit_Cost = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 5;

							row1.Total = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							if (rowstate_tFileInputDelimited_1.getException() != null) {
								throw rowstate_tFileInputDelimited_1
										.getException();
							}

						} catch (java.lang.Exception e) {
							whetherReject_tFileInputDelimited_1 = true;

							throw (e);

						}

						/**
						 * [tFileInputDelimited_1 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_1 main ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						tos_count_tFileInputDelimited_1++;

						/**
						 * [tFileInputDelimited_1 main ] stop
						 */

						/**
						 * [tFileInputDelimited_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_begin ] stop
						 */
						// Start of branch "row1"
						if (row1 != null) {

							/**
							 * [tSortRow_1_SortOut main ] start
							 */

							currentVirtualComponent = "tSortRow_1";

							currentComponent = "tSortRow_1_SortOut";

							// row1
							// row1

							if (execStat) {
								runStat.updateStatOnConnection("row1"
										+ iterateId, 1, 1);
							}

							Comparablerow1Struct arrayRowtSortRow_1_SortOut = new Comparablerow1Struct();

							arrayRowtSortRow_1_SortOut.Region = row1.Region;
							arrayRowtSortRow_1_SortOut.Rep = row1.Rep;
							arrayRowtSortRow_1_SortOut.Item = row1.Item;
							arrayRowtSortRow_1_SortOut.Units = row1.Units;
							arrayRowtSortRow_1_SortOut.Unit_Cost = row1.Unit_Cost;
							arrayRowtSortRow_1_SortOut.Total = row1.Total;
							list_tSortRow_1_SortOut
									.add(arrayRowtSortRow_1_SortOut);

							tos_count_tSortRow_1_SortOut++;

							/**
							 * [tSortRow_1_SortOut main ] stop
							 */

							/**
							 * [tSortRow_1_SortOut process_data_begin ] start
							 */

							currentVirtualComponent = "tSortRow_1";

							currentComponent = "tSortRow_1_SortOut";

							/**
							 * [tSortRow_1_SortOut process_data_begin ] stop
							 */

							/**
							 * [tSortRow_1_SortOut process_data_end ] start
							 */

							currentVirtualComponent = "tSortRow_1";

							currentComponent = "tSortRow_1_SortOut";

							/**
							 * [tSortRow_1_SortOut process_data_end ] stop
							 */

						} // End of branch "row1"

						/**
						 * [tFileInputDelimited_1 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_1 end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

					}
				} finally {
					if (!((Object) (context.InputFile) instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_1 != null) {
							fid_tFileInputDelimited_1.close();
						}
					}
					if (fid_tFileInputDelimited_1 != null) {
						globalMap.put("tFileInputDelimited_1_NB_LINE",
								fid_tFileInputDelimited_1.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_1", true);
				end_Hash.put("tFileInputDelimited_1",
						System.currentTimeMillis());

				tStatCatcher_1.addMessage(
						"end",
						"tFileInputDelimited_1",
						end_Hash.get("tFileInputDelimited_1")
								- start_Hash.get("tFileInputDelimited_1"));
				tLogCatcher_1Process(globalMap);
				talendStats_STATS.addMessage(
						"end",
						"tFileInputDelimited_1",
						end_Hash.get("tFileInputDelimited_1")
								- start_Hash.get("tFileInputDelimited_1"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tFileInputDelimited_1 end ] stop
				 */

				/**
				 * [tSortRow_1_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortOut";

				row1Struct[] array_tSortRow_1_SortOut = list_tSortRow_1_SortOut
						.toArray(new Comparablerow1Struct[0]);

				java.util.Arrays.sort(array_tSortRow_1_SortOut);

				globalMap.put("tSortRow_1", array_tSortRow_1_SortOut);

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("row1" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("tSortRow_1_SortOut", true);
				end_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());

				tStatCatcher_1.addMessage(
						"end",
						"tSortRow_1_SortOut",
						end_Hash.get("tSortRow_1_SortOut")
								- start_Hash.get("tSortRow_1_SortOut"));
				tLogCatcher_1Process(globalMap);
				talendStats_STATS.addMessage(
						"end",
						"tSortRow_1_SortOut",
						end_Hash.get("tSortRow_1_SortOut")
								- start_Hash.get("tSortRow_1_SortOut"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tSortRow_1_SortOut end ] stop
				 */

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("copy" + iterateId, 0, 0);

					}
				}

				int tos_count_tDBOutput_1 = 0;

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;
				String dbschema_tDBOutput_1 = null;
				String tableName_tDBOutput_1 = null;
				boolean whetherReject_tDBOutput_1 = false;

				java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar
						.getInstance();
				long year1_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd",
						"0001-01-01").getTime();
				long year2_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd",
						"1753-01-01").getTime();
				long year10000_tDBOutput_1 = TalendDate.parseDate(
						"yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00").getTime();
				long date_tDBOutput_1;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_1 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_1 = null;
				String dbUser_tDBOutput_1 = null;
				dbschema_tDBOutput_1 = "";
				String driverClass_tDBOutput_1 = "net.sourceforge.jtds.jdbc.Driver";

				java.lang.Class.forName(driverClass_tDBOutput_1);
				String port_tDBOutput_1 = "1433";
				String dbname_tDBOutput_1 = "classicmodels";
				String url_tDBOutput_1 = "jdbc:jtds:sqlserver://"
						+ "cdp-rds01.us-east-1.mgnt-xspdev.in";
				if (!"".equals(port_tDBOutput_1)) {
					url_tDBOutput_1 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_1)) {
					url_tDBOutput_1 += "//" + "classicmodels";

				}
				url_tDBOutput_1 += ";appName=" + projectName + ";"
						+ "noDatetimeStringSync=true";
				dbUser_tDBOutput_1 = "root";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("d3241f39786ada470065ab1ce440459f");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(
						url_tDBOutput_1, dbUser_tDBOutput_1, dbPwd_tDBOutput_1);

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);

				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;

				int batchSize_tDBOutput_1 = 10000;
				int batchSizeCounter_tDBOutput_1 = 0;

				if (dbschema_tDBOutput_1 == null
						|| dbschema_tDBOutput_1.trim().length() == 0) {
					tableName_tDBOutput_1 = "";
				} else {
					tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "].[" + "";
				}
				int count_tDBOutput_1 = 0;

				String insert_tDBOutput_1 = "INSERT INTO ["
						+ tableName_tDBOutput_1
						+ "] ([Region],[Rep],[Item],[Units],[Unit_Cost],[Total]) VALUES (?,?,?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1
						.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tFileOutputExcel_1 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_1", false);
				start_Hash
						.put("tFileOutputExcel_1", System.currentTimeMillis());

				tStatCatcher_1.addMessage("begin", "tFileOutputExcel_1");
				tLogCatcher_1Process(globalMap);

				talendStats_STATS.addMessage("begin", "tFileOutputExcel_1");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tFileOutputExcel_1";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("mainm" + iterateId, 0,
								0);

					}
				}

				int tos_count_tFileOutputExcel_1 = 0;

				int columnIndex_tFileOutputExcel_1 = 0;

				String fileName_tFileOutputExcel_1 = "C:/Users/ruchiagarwal3/Documents/Ruchi- Deloitte/CDP 2.0/talend/SortedData.xls";
				int nb_line_tFileOutputExcel_1 = 0;
				org.talend.ExcelTool xlsxTool_tFileOutputExcel_1 = new org.talend.ExcelTool();
				xlsxTool_tFileOutputExcel_1.setSheet("Sheet1");
				xlsxTool_tFileOutputExcel_1.setAppend(true, false);
				xlsxTool_tFileOutputExcel_1.setRecalculateFormula(false);
				xlsxTool_tFileOutputExcel_1.setXY(false, 0, 0, false);

				xlsxTool_tFileOutputExcel_1
						.prepareXlsxFile(fileName_tFileOutputExcel_1);

				xlsxTool_tFileOutputExcel_1.setFont("");

				if (xlsxTool_tFileOutputExcel_1.getStartRow() == 0) {

					xlsxTool_tFileOutputExcel_1.addRow();

					xlsxTool_tFileOutputExcel_1.addCellValue("Region");

					xlsxTool_tFileOutputExcel_1.addCellValue("Rep");

					xlsxTool_tFileOutputExcel_1.addCellValue("Item");

					xlsxTool_tFileOutputExcel_1.addCellValue("Units");

					xlsxTool_tFileOutputExcel_1.addCellValue("Unit_Cost");

					xlsxTool_tFileOutputExcel_1.addCellValue("Total");

					nb_line_tFileOutputExcel_1++;

				}

				/**
				 * [tFileOutputExcel_1 begin ] stop
				 */

				/**
				 * [tMap_2 begin ] start
				 */

				ok_Hash.put("tMap_2", false);
				start_Hash.put("tMap_2", System.currentTimeMillis());

				tStatCatcher_1.addMessage("begin", "tMap_2");
				tLogCatcher_1Process(globalMap);

				talendStats_STATS.addMessage("begin", "tMap_2");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tMap_2";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("row2" + iterateId, 0, 0);

					}
				}

				int tos_count_tMap_2 = 0;

				// ###############################
				// # Lookup's keys initialization
				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_2__Struct {
					int var1;
				}
				Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				copyStruct copy_tmp = new copyStruct();
				mainmStruct mainm_tmp = new mainmStruct();
				// ###############################

				/**
				 * [tMap_2 begin ] stop
				 */

				/**
				 * [tSortRow_1_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_1_SortIn", false);
				start_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());

				tStatCatcher_1.addMessage("begin", "tSortRow_1_SortIn");
				tLogCatcher_1Process(globalMap);

				talendStats_STATS.addMessage("begin", "tSortRow_1_SortIn");
				talendStats_STATSProcess(globalMap);

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortIn";

				int tos_count_tSortRow_1_SortIn = 0;

				row1Struct[] array_tSortRow_1_SortIn = (row1Struct[]) globalMap
						.remove("tSortRow_1");

				int nb_line_tSortRow_1_SortIn = 0;

				row1Struct current_tSortRow_1_SortIn = null;

				for (int i_tSortRow_1_SortIn = 0; i_tSortRow_1_SortIn < array_tSortRow_1_SortIn.length; i_tSortRow_1_SortIn++) {
					current_tSortRow_1_SortIn = array_tSortRow_1_SortIn[i_tSortRow_1_SortIn];
					row2.Region = current_tSortRow_1_SortIn.Region;
					row2.Rep = current_tSortRow_1_SortIn.Rep;
					row2.Item = current_tSortRow_1_SortIn.Item;
					row2.Units = current_tSortRow_1_SortIn.Units;
					row2.Unit_Cost = current_tSortRow_1_SortIn.Unit_Cost;
					row2.Total = current_tSortRow_1_SortIn.Total;
					// increase number of line sorted
					nb_line_tSortRow_1_SortIn++;

					/**
					 * [tSortRow_1_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_1_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

					tos_count_tSortRow_1_SortIn++;

					/**
					 * [tSortRow_1_SortIn main ] stop
					 */

					/**
					 * [tSortRow_1_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

					/**
					 * [tSortRow_1_SortIn process_data_begin ] stop
					 */

					/**
					 * [tMap_2 main ] start
					 */

					currentComponent = "tMap_2";

					// row2
					// row2

					if (execStat) {
						runStat.updateStatOnConnection("row2" + iterateId, 1, 1);
					}

					boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

					// ###############################
					// # Input tables (lookups)
					boolean rejectedInnerJoin_tMap_2 = false;
					boolean mainRowRejected_tMap_2 = false;

					// ###############################
					{ // start of Var scope

						// ###############################
						// # Vars tables

						Var__tMap_2__Struct Var = Var__tMap_2;
						Var.var1 = 1;// ###############################
						// ###############################
						// # Output tables

						copy = null;
						mainm = null;

						// # Output table : 'copy'
						copy_tmp.Region = null;
						copy_tmp.Rep = null;
						copy_tmp.Item = null;
						copy_tmp.Units = null;
						copy_tmp.Unit_Cost = null;
						copy_tmp.Total = null;
						copy = copy_tmp;

						// # Output table : 'mainm'
						mainm_tmp.Region = null;
						mainm_tmp.Rep = null;
						mainm_tmp.Item = null;
						mainm_tmp.Units = null;
						mainm_tmp.Unit_Cost = null;
						mainm_tmp.Total = null;
						mainm = mainm_tmp;
						// ###############################

					} // end of Var scope

					rejectedInnerJoin_tMap_2 = false;

					tos_count_tMap_2++;

					/**
					 * [tMap_2 main ] stop
					 */

					/**
					 * [tMap_2 process_data_begin ] start
					 */

					currentComponent = "tMap_2";

					/**
					 * [tMap_2 process_data_begin ] stop
					 */
					// Start of branch "copy"
					if (copy != null) {

						/**
						 * [tDBOutput_1 main ] start
						 */

						currentComponent = "tDBOutput_1";

						// copy
						// copy

						if (execStat) {
							runStat.updateStatOnConnection("copy" + iterateId,
									1, 1);
						}

						whetherReject_tDBOutput_1 = false;
						if (copy.Region == null) {
							pstmt_tDBOutput_1
									.setNull(1, java.sql.Types.VARCHAR);
						} else {
							pstmt_tDBOutput_1.setString(1, copy.Region);
						}

						if (copy.Rep == null) {
							pstmt_tDBOutput_1
									.setNull(2, java.sql.Types.VARCHAR);
						} else {
							pstmt_tDBOutput_1.setString(2, copy.Rep);
						}

						if (copy.Item == null) {
							pstmt_tDBOutput_1
									.setNull(3, java.sql.Types.VARCHAR);
						} else {
							pstmt_tDBOutput_1.setString(3, copy.Item);
						}

						if (copy.Units == null) {
							pstmt_tDBOutput_1
									.setNull(4, java.sql.Types.INTEGER);
						} else {
							pstmt_tDBOutput_1.setInt(4, copy.Units);
						}

						if (copy.Unit_Cost == null) {
							pstmt_tDBOutput_1
									.setNull(5, java.sql.Types.VARCHAR);
						} else {
							pstmt_tDBOutput_1.setString(5, copy.Unit_Cost);
						}

						if (copy.Total == null) {
							pstmt_tDBOutput_1
									.setNull(6, java.sql.Types.VARCHAR);
						} else {
							pstmt_tDBOutput_1.setString(6, copy.Total);
						}

						pstmt_tDBOutput_1.addBatch();
						nb_line_tDBOutput_1++;

						batchSizeCounter_tDBOutput_1++;

						// ////////batch execute by batch size///////
						class LimitBytesHelper_tDBOutput_1 {
							public int limitBytePart1(int counter,
									java.sql.PreparedStatement pstmt_tDBOutput_1)
									throws Exception {
								try {

									for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1
											.executeBatch()) {
										if (countEach_tDBOutput_1 == -2
												|| countEach_tDBOutput_1 == -3) {
											break;
										}
										counter += countEach_tDBOutput_1;
									}

								} catch (java.sql.BatchUpdateException e) {

									int countSum_tDBOutput_1 = 0;
									for (int countEach_tDBOutput_1 : e
											.getUpdateCounts()) {
										counter += (countEach_tDBOutput_1 < 0 ? 0
												: countEach_tDBOutput_1);
									}

									System.err.println(e.getMessage());

								}
								return counter;
							}

							public int limitBytePart2(int counter,
									java.sql.PreparedStatement pstmt_tDBOutput_1)
									throws Exception {
								try {

									for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1
											.executeBatch()) {
										if (countEach_tDBOutput_1 == -2
												|| countEach_tDBOutput_1 == -3) {
											break;
										}
										counter += countEach_tDBOutput_1;
									}

								} catch (java.sql.BatchUpdateException e) {

									for (int countEach_tDBOutput_1 : e
											.getUpdateCounts()) {
										counter += (countEach_tDBOutput_1 < 0 ? 0
												: countEach_tDBOutput_1);
									}

									System.err.println(e.getMessage());

								}
								return counter;
							}
						}
						if ((batchSize_tDBOutput_1 > 0)
								&& (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {

							insertedCount_tDBOutput_1 = new LimitBytesHelper_tDBOutput_1()
									.limitBytePart1(insertedCount_tDBOutput_1,
											pstmt_tDBOutput_1);

							batchSizeCounter_tDBOutput_1 = 0;
						}

						// //////////commit every////////////

						commitCounter_tDBOutput_1++;
						if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
							if ((batchSize_tDBOutput_1 > 0)
									&& (batchSizeCounter_tDBOutput_1 > 0)) {

								insertedCount_tDBOutput_1 = new LimitBytesHelper_tDBOutput_1()
										.limitBytePart1(
												insertedCount_tDBOutput_1,
												pstmt_tDBOutput_1);

								batchSizeCounter_tDBOutput_1 = 0;
							}

							conn_tDBOutput_1.commit();

							commitCounter_tDBOutput_1 = 0;
						}

						tos_count_tDBOutput_1++;

						/**
						 * [tDBOutput_1 main ] stop
						 */

						/**
						 * [tDBOutput_1 process_data_begin ] start
						 */

						currentComponent = "tDBOutput_1";

						/**
						 * [tDBOutput_1 process_data_begin ] stop
						 */

						/**
						 * [tDBOutput_1 process_data_end ] start
						 */

						currentComponent = "tDBOutput_1";

						/**
						 * [tDBOutput_1 process_data_end ] stop
						 */

					} // End of branch "copy"

					// Start of branch "mainm"
					if (mainm != null) {

						/**
						 * [tFileOutputExcel_1 main ] start
						 */

						currentComponent = "tFileOutputExcel_1";

						// mainm
						// mainm

						if (execStat) {
							runStat.updateStatOnConnection("mainm" + iterateId,
									1, 1);
						}

						xlsxTool_tFileOutputExcel_1.addRow();

						if (mainm.Region != null) {

							xlsxTool_tFileOutputExcel_1.addCellValue(String
									.valueOf(mainm.Region));
						} else {
							xlsxTool_tFileOutputExcel_1.addCellNullValue();
						}

						if (mainm.Rep != null) {

							xlsxTool_tFileOutputExcel_1.addCellValue(String
									.valueOf(mainm.Rep));
						} else {
							xlsxTool_tFileOutputExcel_1.addCellNullValue();
						}

						if (mainm.Item != null) {

							xlsxTool_tFileOutputExcel_1.addCellValue(String
									.valueOf(mainm.Item));
						} else {
							xlsxTool_tFileOutputExcel_1.addCellNullValue();
						}

						if (mainm.Units != null) {

							xlsxTool_tFileOutputExcel_1.addCellValue(Double
									.parseDouble(String.valueOf(mainm.Units)));
						} else {
							xlsxTool_tFileOutputExcel_1.addCellNullValue();
						}

						if (mainm.Unit_Cost != null) {

							xlsxTool_tFileOutputExcel_1.addCellValue(String
									.valueOf(mainm.Unit_Cost));
						} else {
							xlsxTool_tFileOutputExcel_1.addCellNullValue();
						}

						if (mainm.Total != null) {

							xlsxTool_tFileOutputExcel_1.addCellValue(String
									.valueOf(mainm.Total));
						} else {
							xlsxTool_tFileOutputExcel_1.addCellNullValue();
						}

						nb_line_tFileOutputExcel_1++;

						tos_count_tFileOutputExcel_1++;

						/**
						 * [tFileOutputExcel_1 main ] stop
						 */

						/**
						 * [tFileOutputExcel_1 process_data_begin ] start
						 */

						currentComponent = "tFileOutputExcel_1";

						/**
						 * [tFileOutputExcel_1 process_data_begin ] stop
						 */

						/**
						 * [tFileOutputExcel_1 process_data_end ] start
						 */

						currentComponent = "tFileOutputExcel_1";

						/**
						 * [tFileOutputExcel_1 process_data_end ] stop
						 */

					} // End of branch "mainm"

					/**
					 * [tMap_2 process_data_end ] start
					 */

					currentComponent = "tMap_2";

					/**
					 * [tMap_2 process_data_end ] stop
					 */

					/**
					 * [tSortRow_1_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

					/**
					 * [tSortRow_1_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_1_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

				}

				globalMap.put("tSortRow_1_SortIn_NB_LINE",
						nb_line_tSortRow_1_SortIn);

				ok_Hash.put("tSortRow_1_SortIn", true);
				end_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());

				tStatCatcher_1.addMessage(
						"end",
						"tSortRow_1_SortIn",
						end_Hash.get("tSortRow_1_SortIn")
								- start_Hash.get("tSortRow_1_SortIn"));
				tLogCatcher_1Process(globalMap);
				talendStats_STATS.addMessage(
						"end",
						"tSortRow_1_SortIn",
						end_Hash.get("tSortRow_1_SortIn")
								- start_Hash.get("tSortRow_1_SortIn"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tSortRow_1_SortIn end ] stop
				 */

				/**
				 * [tMap_2 end ] start
				 */

				currentComponent = "tMap_2";

				// ###############################
				// # Lookup hashes releasing
				// ###############################

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("row2" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("tMap_2", true);
				end_Hash.put("tMap_2", System.currentTimeMillis());

				tStatCatcher_1.addMessage("end", "tMap_2",
						end_Hash.get("tMap_2") - start_Hash.get("tMap_2"));
				tLogCatcher_1Process(globalMap);
				talendStats_STATS.addMessage("end", "tMap_2",
						end_Hash.get("tMap_2") - start_Hash.get("tMap_2"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tMap_2 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					int countSum_tDBOutput_1 = 0;
					if (pstmt_tDBOutput_1 != null
							&& batchSizeCounter_tDBOutput_1 > 0) {

						for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1
								.executeBatch()) {
							if (countEach_tDBOutput_1 == -2
									|| countEach_tDBOutput_1 == -3) {
								break;
							}
							countSum_tDBOutput_1 += countEach_tDBOutput_1;
						}

					}

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

				} catch (java.sql.BatchUpdateException e) {

					int countSum_tDBOutput_1 = 0;
					for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0
								: countEach_tDBOutput_1);
					}

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_1 != null) {

					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");

				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				conn_tDBOutput_1.commit();

				conn_tDBOutput_1.close();
				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1
						+ deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1
						+ updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1
						+ insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1
						+ rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED",
						nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED",
						nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED",
						nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED",
						nb_line_rejected_tDBOutput_1);

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("copy" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

				/**
				 * [tFileOutputExcel_1 end ] start
				 */

				currentComponent = "tFileOutputExcel_1";

				xlsxTool_tFileOutputExcel_1.writeExcel(
						fileName_tFileOutputExcel_1, true);

				nb_line_tFileOutputExcel_1 = nb_line_tFileOutputExcel_1 - 1;

				globalMap.put("tFileOutputExcel_1_NB_LINE",
						nb_line_tFileOutputExcel_1);

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("mainm" + iterateId, 2,
								0);
					}
				}

				ok_Hash.put("tFileOutputExcel_1", true);
				end_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());

				tStatCatcher_1.addMessage(
						"end",
						"tFileOutputExcel_1",
						end_Hash.get("tFileOutputExcel_1")
								- start_Hash.get("tFileOutputExcel_1"));
				tLogCatcher_1Process(globalMap);
				talendStats_STATS.addMessage(
						"end",
						"tFileOutputExcel_1",
						end_Hash.get("tFileOutputExcel_1")
								- start_Hash.get("tFileOutputExcel_1"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tFileOutputExcel_1 end ] stop
				 */

			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil
						.addLog("CHECKPOINT",
								"CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk",
								"", Thread.currentThread().getId() + "", "",
								"", "", "", "");
			}

			if (execStat) {
				runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
			}

			tAssert_1Process(globalMap);

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tSortRow_1_SortIn"
			globalMap.remove("tSortRow_1");

			try {

				/**
				 * [tFileInputDelimited_1 finally ] start
				 */

				currentComponent = "tFileInputDelimited_1";

				/**
				 * [tFileInputDelimited_1 finally ] stop
				 */

				/**
				 * [tSortRow_1_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortOut";

				/**
				 * [tSortRow_1_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_1_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortIn";

				/**
				 * [tSortRow_1_SortIn finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap
								.get("conn_tDBOutput_1")) != null) {
							try {
								ctn_tDBOutput_1.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

				/**
				 * [tFileOutputExcel_1 finally ] start
				 */

				currentComponent = "tFileOutputExcel_1";

				/**
				 * [tFileOutputExcel_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public static class row10Struct implements
			routines.system.IPersistableRow<row10Struct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public String key;

		public String getKey() {
			return this.key;
		}

		public String value;

		public String getValue() {
			return this.value;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.key = readString(dis);

					this.value = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.key, dos);

				// String

				writeString(this.value, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("key=" + key);
			sb.append(",value=" + value);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row10Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row10Struct row10 = new row10Struct();




	
	/**
	 * [tContextLoad_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tContextLoad_1", false);
		start_Hash.put("tContextLoad_1", System.currentTimeMillis());
		
	
	currentComponent="tContextLoad_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row10" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tContextLoad_1 = 0;
		
	java.util.List<String> assignList_tContextLoad_1 = new java.util.ArrayList<String>();
	java.util.List<String> newPropertyList_tContextLoad_1 = new java.util.ArrayList<String>();
	java.util.List<String> noAssignList_tContextLoad_1 = new java.util.ArrayList<String>();
	int nb_line_tContextLoad_1 = 0;

 



/**
 * [tContextLoad_1 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_2", false);
		start_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_2";

	
		int tos_count_tFileInputDelimited_2 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_2 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_2 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_2 = null;
				try{
					
						Object filename_tFileInputDelimited_2 = "D:\Users\ruchi.agarwal\Documents\config.csv";
						if(filename_tFileInputDelimited_2 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_2 = 0, random_value_tFileInputDelimited_2 = -1;
			if(footer_value_tFileInputDelimited_2 >0 || random_value_tFileInputDelimited_2 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_2 = new org.talend.fileprocess.FileInputDelimited("D:\Users\ruchi.agarwal\Documents\config.csv", "ISO-8859-15",",","\n",true,0,0,-1,-1, false);
						} catch(java.lang.Exception e) {
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_2!=null && fid_tFileInputDelimited_2.nextRecord()) {
						rowstate_tFileInputDelimited_2.reset();
						
			    						row10 = null;			
												
									boolean whetherReject_tFileInputDelimited_2 = false;
									row10 = new row10Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_2 = 0;
				
					columnIndexWithD_tFileInputDelimited_2 = 0;
					
							row10.key = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 1;
					
							row10.value = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
				
										
										if(rowstate_tFileInputDelimited_2.getException()!=null) {
											throw rowstate_tFileInputDelimited_2.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
			        					whetherReject_tFileInputDelimited_2 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row10 = null;
			                				
			    					}
								

 



/**
 * [tFileInputDelimited_2 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 


	tos_count_tFileInputDelimited_2++;

/**
 * [tFileInputDelimited_2 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 process_data_begin ] stop
 */
// Start of branch "row10"
if(row10 != null) { 



	
	/**
	 * [tContextLoad_1 main ] start
	 */

	

	
	
	currentComponent="tContextLoad_1";

	

			//row10
			//row10


			
				if(execStat){
					runStat.updateStatOnConnection("row10"+iterateId,1, 1);
				} 
			

		
        //////////////////////////
        String tmp_key_tContextLoad_1 = null;
                    String key_tContextLoad_1 = null;
                      if (row10.key != null){
                          tmp_key_tContextLoad_1 = row10.key.trim();
                        if ((tmp_key_tContextLoad_1.startsWith("#") || tmp_key_tContextLoad_1.startsWith("!") )){
                          tmp_key_tContextLoad_1 = null;
                        } else {
                          row10.key = tmp_key_tContextLoad_1;
                        }
                      }
                        if(row10.key != null) {
                    key_tContextLoad_1 =
                        row10.key;
                        }
                    String value_tContextLoad_1 = null;
                        if(row10.value != null) {
                    value_tContextLoad_1 =
                        row10.value;
                        }
				
				String currentValue_tContextLoad_1 = value_tContextLoad_1;
				

  if (tmp_key_tContextLoad_1 != null){
  try{
        if(key_tContextLoad_1!=null && "InputFile".equals(key_tContextLoad_1))
        {
           context.InputFile=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "OutputFile".equals(key_tContextLoad_1))
        {
           context.OutputFile=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Host".equals(key_tContextLoad_1))
        {
           context.Host=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Port".equals(key_tContextLoad_1))
        {
           context.Port=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Database".equals(key_tContextLoad_1))
        {
           context.Database=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Username".equals(key_tContextLoad_1))
        {
           context.Username=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Password".equals(key_tContextLoad_1))
        {
           context.Password=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Table".equals(key_tContextLoad_1))
        {
           context.Table=value_tContextLoad_1;
        }


        if (context.getProperty(key_tContextLoad_1)!=null)
        {
            assignList_tContextLoad_1.add(key_tContextLoad_1);
        }else  {
            newPropertyList_tContextLoad_1.add(key_tContextLoad_1);
        }
        if(value_tContextLoad_1 == null){
            context.setProperty(key_tContextLoad_1, "");
        }else{
            context.setProperty(key_tContextLoad_1,value_tContextLoad_1);
        }
    }catch(java.lang.Exception e){
        System.err.println("Setting a value for the key \"" + key_tContextLoad_1 + "\" has failed. Error message: " + e.getMessage());
    }
        nb_line_tContextLoad_1++;
    }
        //////////////////////////

 


	tos_count_tContextLoad_1++;

/**
 * [tContextLoad_1 main ] stop
 */
	
	/**
	 * [tContextLoad_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tContextLoad_1";

	

 



/**
 * [tContextLoad_1 process_data_begin ] stop
 */
	
	/**
	 * [tContextLoad_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tContextLoad_1";

	

 



/**
 * [tContextLoad_1 process_data_end ] stop
 */

} // End of branch "row10"




	
	/**
	 * [tFileInputDelimited_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	



            }
            }finally{
                if(!((Object)("D:\Users\ruchi.agarwal\Documents\config.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_2!=null){
                		fid_tFileInputDelimited_2.close();
                	}
                }
                if(fid_tFileInputDelimited_2!=null){
                	globalMap.put("tFileInputDelimited_2_NB_LINE", fid_tFileInputDelimited_2.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_2", true);
end_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());




/**
 * [tFileInputDelimited_2 end ] stop
 */

	
	/**
	 * [tContextLoad_1 end ] start
	 */

	

	
	
	currentComponent="tContextLoad_1";

	
	
	java.util.Enumeration<?> enu_tContextLoad_1 = context.propertyNames();
    while(enu_tContextLoad_1.hasMoreElements())
    {           
    	String key_tContextLoad_1 = (String)enu_tContextLoad_1.nextElement();
        if(!assignList_tContextLoad_1.contains(key_tContextLoad_1) && !newPropertyList_tContextLoad_1.contains(key_tContextLoad_1))
        {
            noAssignList_tContextLoad_1.add(key_tContextLoad_1);
        }          
    } 

    String newPropertyStr_tContextLoad_1 = newPropertyList_tContextLoad_1.toString();
    String newProperty_tContextLoad_1 = newPropertyStr_tContextLoad_1.substring(1, newPropertyStr_tContextLoad_1.length() - 1);
    
    String noAssignStr_tContextLoad_1 = noAssignList_tContextLoad_1.toString();
    String noAssign_tContextLoad_1 = noAssignStr_tContextLoad_1.substring(1, noAssignStr_tContextLoad_1.length() - 1);
    
    globalMap.put("tContextLoad_1_KEY_NOT_INCONTEXT", newProperty_tContextLoad_1);
    globalMap.put("tContextLoad_1_KEY_NOT_LOADED", noAssign_tContextLoad_1);

    globalMap.put("tContextLoad_1_NB_LINE",nb_line_tContextLoad_1);

	List<String> parametersToEncrypt_tContextLoad_1 = new java.util.ArrayList<String>();
	
	
	resumeUtil.addLog("NODE", "NODE:tContextLoad_1", "", Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt_tContextLoad_1));    
    
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row10"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tContextLoad_1", true);
end_Hash.put("tContextLoad_1", System.currentTimeMillis());




/**
 * [tContextLoad_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_2 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 finally ] stop
 */

	
	/**
	 * [tContextLoad_1 finally ] start
	 */

	

	
	
	currentComponent="tContextLoad_1";

	

 



/**
 * [tContextLoad_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}

	public void tJava_1Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception()
						.getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tJava_1 begin ] start
				 */

				ok_Hash.put("tJava_1", false);
				start_Hash.put("tJava_1", System.currentTimeMillis());

				currentComponent = "tJava_1";

				int tos_count_tJava_1 = 0;

				UUID uniqueKey = java.util.UUID.randomUUID();
				System.out.println(uniqueKey);
				globalMap.put("workspace_UUID", uniqueKey);

				/**
				 * [tJava_1 begin ] stop
				 */

				/**
				 * [tJava_1 main ] start
				 */

				currentComponent = "tJava_1";

				tos_count_tJava_1++;

				/**
				 * [tJava_1 main ] stop
				 */

				/**
				 * [tJava_1 process_data_begin ] start
				 */

				currentComponent = "tJava_1";

				/**
				 * [tJava_1 process_data_begin ] stop
				 */

				/**
				 * [tJava_1 process_data_end ] start
				 */

				currentComponent = "tJava_1";

				/**
				 * [tJava_1 process_data_end ] stop
				 */

				/**
				 * [tJava_1 end ] start
				 */

				currentComponent = "tJava_1";

				ok_Hash.put("tJava_1", true);
				end_Hash.put("tJava_1", System.currentTimeMillis());

				/**
				 * [tJava_1 end ] stop
				 */
			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT",
						"CONNECTION:SUBJOB_OK:tJava_1:OnSubjobOk", "", Thread
								.currentThread().getId() + "", "", "", "", "",
						"");
			}

			if (execStat) {
				runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
			}

			tFileInputDelimited_2Process(globalMap);

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tJava_1 finally ] start
				 */

				currentComponent = "tJava_1";

				/**
				 * [tJava_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}

	public static class Output_rowStruct implements
			routines.system.IPersistableRow<Output_rowStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date Timestamp;

		public java.util.Date getTimestamp() {
			return this.Timestamp;
		}

		public String RunID;

		public String getRunID() {
			return this.RunID;
		}

		public Long Connection_node;

		public Long getConnection_node() {
			return this.Connection_node;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String log_type;

		public String getLog_type() {
			return this.log_type;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		public String Source_file;

		public String getSource_file() {
			return this.Source_file;
		}

		public String Target_file;

		public String getTarget_file() {
			return this.Target_file;
		}

		public Integer Row_count;

		public Integer getRow_count() {
			return this.Row_count;
		}

		public Integer Row_processed;

		public Integer getRow_processed() {
			return this.Row_processed;
		}

		public Integer Row_rejected;

		public Integer getRow_rejected() {
			return this.Row_rejected;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.Timestamp = readDate(dis);

					this.RunID = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Connection_node = null;
					} else {
						this.Connection_node = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.log_type = readString(dis);

					this.origin = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

					this.Source_file = readString(dis);

					this.Target_file = readString(dis);

					this.Row_count = readInteger(dis);

					this.Row_processed = readInteger(dis);

					this.Row_rejected = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.Timestamp, dos);

				// String

				writeString(this.RunID, dos);

				// Long

				if (this.Connection_node == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.Connection_node);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.log_type, dos);

				// String

				writeString(this.origin, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

				// String

				writeString(this.Source_file, dos);

				// String

				writeString(this.Target_file, dos);

				// Integer

				writeInteger(this.Row_count, dos);

				// Integer

				writeInteger(this.Row_processed, dos);

				// Integer

				writeInteger(this.Row_rejected, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Timestamp=" + String.valueOf(Timestamp));
			sb.append(",RunID=" + RunID);
			sb.append(",Connection_node=" + String.valueOf(Connection_node));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",log_type=" + log_type);
			sb.append(",origin=" + origin);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append(",Source_file=" + Source_file);
			sb.append(",Target_file=" + Target_file);
			sb.append(",Row_count=" + String.valueOf(Row_count));
			sb.append(",Row_processed=" + String.valueOf(Row_processed));
			sb.append(",Row_rejected=" + String.valueOf(Row_rejected));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Output_rowStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row9Struct implements
			routines.system.IPersistableRow<row9Struct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String log_type;

		public String getLog_type() {
			return this.log_type;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		public String Source_file;

		public String getSource_file() {
			return this.Source_file;
		}

		public String Target_file;

		public String getTarget_file() {
			return this.Target_file;
		}

		public Integer Row_count;

		public Integer getRow_count() {
			return this.Row_count;
		}

		public Integer Row_processed;

		public Integer getRow_processed() {
			return this.Row_processed;
		}

		public Integer Row_rejected;

		public Integer getRow_rejected() {
			return this.Row_rejected;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.log_type = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

					this.Source_file = readString(dis);

					this.Target_file = readString(dis);

					this.Row_count = readInteger(dis);

					this.Row_processed = readInteger(dis);

					this.Row_rejected = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.log_type, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

				// String

				writeString(this.Source_file, dos);

				// String

				writeString(this.Target_file, dos);

				// Integer

				writeInteger(this.Row_count, dos);

				// Integer

				writeInteger(this.Row_processed, dos);

				// Integer

				writeInteger(this.Row_rejected, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",log_type=" + log_type);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",Source_file=" + Source_file);
			sb.append(",Target_file=" + Target_file);
			sb.append(",Row_count=" + String.valueOf(Row_count));
			sb.append(",Row_processed=" + String.valueOf(Row_processed));
			sb.append(",Row_rejected=" + String.valueOf(Row_rejected));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row9Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class logDataStruct implements
			routines.system.IPersistableRow<logDataStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String log_type;

		public String getLog_type() {
			return this.log_type;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		public String Source_file;

		public String getSource_file() {
			return this.Source_file;
		}

		public String Target_file;

		public String getTarget_file() {
			return this.Target_file;
		}

		public Integer Row_count;

		public Integer getRow_count() {
			return this.Row_count;
		}

		public Integer Row_processed;

		public Integer getRow_processed() {
			return this.Row_processed;
		}

		public Integer Row_rejected;

		public Integer getRow_rejected() {
			return this.Row_rejected;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.log_type = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

					this.Source_file = readString(dis);

					this.Target_file = readString(dis);

					this.Row_count = readInteger(dis);

					this.Row_processed = readInteger(dis);

					this.Row_rejected = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.log_type, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

				// String

				writeString(this.Source_file, dos);

				// String

				writeString(this.Target_file, dos);

				// Integer

				writeInteger(this.Row_count, dos);

				// Integer

				writeInteger(this.Row_processed, dos);

				// Integer

				writeInteger(this.Row_rejected, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",log_type=" + log_type);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",Source_file=" + Source_file);
			sb.append(",Target_file=" + Target_file);
			sb.append(",Row_count=" + String.valueOf(Row_count));
			sb.append(",Row_processed=" + String.valueOf(Row_processed));
			sb.append(",Row_rejected=" + String.valueOf(Row_rejected));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(logDataStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row4Struct implements
			routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					this.project = readString(dis);

					this.job = readString(dis);

					this.context = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.origin = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.context, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",context=" + context);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",origin=" + origin);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Assert_DataStruct implements
			routines.system.IPersistableRow<Assert_DataStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String log_type;

		public String getLog_type() {
			return this.log_type;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		public String Source_file;

		public String getSource_file() {
			return this.Source_file;
		}

		public String Target_file;

		public String getTarget_file() {
			return this.Target_file;
		}

		public Integer Row_count;

		public Integer getRow_count() {
			return this.Row_count;
		}

		public Integer Row_processed;

		public Integer getRow_processed() {
			return this.Row_processed;
		}

		public Integer Row_rejected;

		public Integer getRow_rejected() {
			return this.Row_rejected;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.log_type = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

					this.Source_file = readString(dis);

					this.Target_file = readString(dis);

					this.Row_count = readInteger(dis);

					this.Row_processed = readInteger(dis);

					this.Row_rejected = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.log_type, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

				// String

				writeString(this.Source_file, dos);

				// String

				writeString(this.Target_file, dos);

				// Integer

				writeInteger(this.Row_count, dos);

				// Integer

				writeInteger(this.Row_processed, dos);

				// Integer

				writeInteger(this.Row_rejected, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",log_type=" + log_type);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",Source_file=" + Source_file);
			sb.append(",Target_file=" + Target_file);
			sb.append(",Row_count=" + String.valueOf(Row_count));
			sb.append(",Row_processed=" + String.valueOf(Row_processed));
			sb.append(",Row_rejected=" + String.valueOf(Row_rejected));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Assert_DataStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row6Struct implements
			routines.system.IPersistableRow<row6Struct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String language;

		public String getLanguage() {
			return this.language;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String status;

		public String getStatus() {
			return this.status;
		}

		public String substatus;

		public String getSubstatus() {
			return this.substatus;
		}

		public String description;

		public String getDescription() {
			return this.description;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.project = readString(dis);

					this.job = readString(dis);

					this.language = readString(dis);

					this.origin = readString(dis);

					this.status = readString(dis);

					this.substatus = readString(dis);

					this.description = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.language, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.status, dos);

				// String

				writeString(this.substatus, dos);

				// String

				writeString(this.description, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",language=" + language);
			sb.append(",origin=" + origin);
			sb.append(",status=" + status);
			sb.append(",substatus=" + substatus);
			sb.append(",description=" + description);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row6Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class StatDataStruct implements
			routines.system.IPersistableRow<StatDataStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String log_type;

		public String getLog_type() {
			return this.log_type;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		public String Source_file;

		public String getSource_file() {
			return this.Source_file;
		}

		public String Target_file;

		public String getTarget_file() {
			return this.Target_file;
		}

		public Integer Row_count;

		public Integer getRow_count() {
			return this.Row_count;
		}

		public Integer Row_processed;

		public Integer getRow_processed() {
			return this.Row_processed;
		}

		public Integer Row_rejected;

		public Integer getRow_rejected() {
			return this.Row_rejected;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.log_type = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

					this.Source_file = readString(dis);

					this.Target_file = readString(dis);

					this.Row_count = readInteger(dis);

					this.Row_processed = readInteger(dis);

					this.Row_rejected = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.log_type, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

				// String

				writeString(this.Source_file, dos);

				// String

				writeString(this.Target_file, dos);

				// Integer

				writeInteger(this.Row_count, dos);

				// Integer

				writeInteger(this.Row_processed, dos);

				// Integer

				writeInteger(this.Row_rejected, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",log_type=" + log_type);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",Source_file=" + Source_file);
			sb.append(",Target_file=" + Target_file);
			sb.append(",Row_count=" + String.valueOf(Row_count));
			sb.append(",Row_processed=" + String.valueOf(Row_processed));
			sb.append(",Row_rejected=" + String.valueOf(Row_rejected));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(StatDataStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements
			routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message_type;

		public String getMessage_type() {
			return this.message_type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.father_pid = readString(dis);

					this.root_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.message_type = readString(dis);

					this.message = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.root_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message_type, dos);

				// String

				writeString(this.message, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",message_type=" + message_type);
			sb.append(",message=" + message);
			sb.append(",duration=" + String.valueOf(duration));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tLogCatcher_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception()
						.getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row4Struct row4 = new row4Struct();
				logDataStruct logData = new logDataStruct();

				row3Struct row3 = new row3Struct();
				StatDataStruct StatData = new StatDataStruct();

				row6Struct row6 = new row6Struct();
				Assert_DataStruct Assert_Data = new Assert_DataStruct();

				row9Struct row9 = new row9Struct();
				Output_rowStruct Output_row = new Output_rowStruct();

				/**
				 * [tDBOutput_2 begin ] start
				 */

				ok_Hash.put("tDBOutput_2", false);
				start_Hash.put("tDBOutput_2", System.currentTimeMillis());

				currentComponent = "tDBOutput_2";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection(
								"Output_row" + iterateId, 0, 0);

					}
				}

				int tos_count_tDBOutput_2 = 0;

				int nb_line_tDBOutput_2 = 0;
				int nb_line_update_tDBOutput_2 = 0;
				int nb_line_inserted_tDBOutput_2 = 0;
				int nb_line_deleted_tDBOutput_2 = 0;
				int nb_line_rejected_tDBOutput_2 = 0;

				int deletedCount_tDBOutput_2 = 0;
				int updatedCount_tDBOutput_2 = 0;
				int insertedCount_tDBOutput_2 = 0;

				int rejectedCount_tDBOutput_2 = 0;

				String tableName_tDBOutput_2 = context.Table;
				boolean whetherReject_tDBOutput_2 = false;

				java.util.Calendar calendar_tDBOutput_2 = java.util.Calendar
						.getInstance();
				calendar_tDBOutput_2.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_2 = calendar_tDBOutput_2.getTime()
						.getTime();
				calendar_tDBOutput_2.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_2 = calendar_tDBOutput_2.getTime()
						.getTime();
				long date_tDBOutput_2;

				java.sql.Connection conn_tDBOutput_2 = null;
				String dbProperties_tDBOutput_2 = "useUnicode=true&characterEncoding=utf8";
				String url_tDBOutput_2 = null;
				if (dbProperties_tDBOutput_2 == null
						|| dbProperties_tDBOutput_2.trim().length() == 0) {
					url_tDBOutput_2 = "jdbc:mysql://" + context.Host + ":"
							+ context.Port + "/" + context.Database + "?"
							+ "rewriteBatchedStatements=true";
				} else {
					String properties_tDBOutput_2 = "useUnicode=true&characterEncoding=utf8";
					if (!properties_tDBOutput_2
							.contains("rewriteBatchedStatements")) {
						properties_tDBOutput_2 += "&rewriteBatchedStatements=true";
					}

					url_tDBOutput_2 = "jdbc:mysql://" + context.Host + ":"
							+ context.Port + "/" + context.Database + "?"
							+ properties_tDBOutput_2;
				}
				String driverClass_tDBOutput_2 = "com.mysql.cj.jdbc.Driver";

				String dbUser_tDBOutput_2 = context.Username;

				final String decryptedPassword_tDBOutput_2 = context.Password;

				String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;
				java.lang.Class.forName(driverClass_tDBOutput_2);

				conn_tDBOutput_2 = java.sql.DriverManager.getConnection(
						url_tDBOutput_2, dbUser_tDBOutput_2, dbPwd_tDBOutput_2);

				resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);
				conn_tDBOutput_2.setAutoCommit(false);
				int commitEvery_tDBOutput_2 = 10000;
				int commitCounter_tDBOutput_2 = 0;

				int count_tDBOutput_2 = 0;

				java.sql.DatabaseMetaData dbMetaData_tDBOutput_2 = conn_tDBOutput_2
						.getMetaData();
				boolean whetherExist_tDBOutput_2 = false;
				try (java.sql.ResultSet rsTable_tDBOutput_2 = dbMetaData_tDBOutput_2
						.getTables(context.Database, null, null,
								new String[] { "TABLE" })) {
					while (rsTable_tDBOutput_2.next()) {
						String table_tDBOutput_2 = rsTable_tDBOutput_2
								.getString("TABLE_NAME");
						if (table_tDBOutput_2.equalsIgnoreCase(context.Table)) {
							whetherExist_tDBOutput_2 = true;
							break;
						}
					}
				}
				if (!whetherExist_tDBOutput_2) {
					try (java.sql.Statement stmtCreate_tDBOutput_2 = conn_tDBOutput_2
							.createStatement()) {
						stmtCreate_tDBOutput_2
								.execute("CREATE TABLE `"
										+ tableName_tDBOutput_2
										+ "`(`Timestamp` DATETIME ,`RunID` VARCHAR(0)  ,`Connection_node` BIGINT(8)  ,`project` VARCHAR(50)  ,`job` VARCHAR(255)  ,`log_type` VARCHAR(100)  ,`origin` VARCHAR(255)  ,`priority` INT(3)  ,`type` VARCHAR(255)  ,`message` VARCHAR(255)  ,`code` INT(3)  ,`Source_file` VARCHAR(100)  ,`Target_file` VARCHAR(100)  ,`Row_count` INT(0)  ,`Row_processed` INT(0)  ,`Row_rejected` INT(0)  )");
					}
				}

				String insert_tDBOutput_2 = "INSERT INTO `"
						+ context.Table
						+ "` (`Timestamp`,`RunID`,`Connection_node`,`project`,`job`,`log_type`,`origin`,`priority`,`type`,`message`,`code`,`Source_file`,`Target_file`,`Row_count`,`Row_processed`,`Row_rejected`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				int batchSize_tDBOutput_2 = 100;
				int batchSizeCounter_tDBOutput_2 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2
						.prepareStatement(insert_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);

				/**
				 * [tDBOutput_2 begin ] stop
				 */

				/**
				 * [tMap_5 begin ] start
				 */

				ok_Hash.put("tMap_5", false);
				start_Hash.put("tMap_5", System.currentTimeMillis());

				currentComponent = "tMap_5";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("row9" + iterateId, 0, 0);

					}
				}

				int tos_count_tMap_5 = 0;

				// ###############################
				// # Lookup's keys initialization
				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_5__Struct {
				}
				Var__tMap_5__Struct Var__tMap_5 = new Var__tMap_5__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				Output_rowStruct Output_row_tmp = new Output_rowStruct();
				// ###############################

				/**
				 * [tMap_5 begin ] stop
				 */

				/**
				 * [tUnite_1 begin ] start
				 */

				ok_Hash.put("tUnite_1", false);
				start_Hash.put("tUnite_1", System.currentTimeMillis());

				currentComponent = "tUnite_1";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("logData" + iterateId,
								0, 0);

					}
				}

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("StatData" + iterateId,
								0, 0);

					}
				}

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("Assert_Data"
								+ iterateId, 0, 0);

					}
				}

				int tos_count_tUnite_1 = 0;

				int nb_line_tUnite_1 = 0;

				/**
				 * [tUnite_1 begin ] stop
				 */

				/**
				 * [tMap_3 begin ] start
				 */

				ok_Hash.put("tMap_3", false);
				start_Hash.put("tMap_3", System.currentTimeMillis());

				currentComponent = "tMap_3";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("row4" + iterateId, 0, 0);

					}
				}

				int tos_count_tMap_3 = 0;

				// ###############################
				// # Lookup's keys initialization
				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_3__Struct {
				}
				Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				logDataStruct logData_tmp = new logDataStruct();
				// ###############################

				/**
				 * [tMap_3 begin ] stop
				 */

				/**
				 * [tLogCatcher_1 begin ] start
				 */

				ok_Hash.put("tLogCatcher_1", false);
				start_Hash.put("tLogCatcher_1", System.currentTimeMillis());

				currentComponent = "tLogCatcher_1";

				int tos_count_tLogCatcher_1 = 0;

				try {
					for (LogCatcherUtils.LogCatcherMessage lcm : tLogCatcher_1
							.getMessages()) {
						row4.type = lcm.getType();
						row4.origin = (lcm.getOrigin() == null
								|| lcm.getOrigin().length() < 1 ? null : lcm
								.getOrigin());
						row4.priority = lcm.getPriority();
						row4.message = lcm.getMessage();
						row4.code = lcm.getCode();

						row4.moment = java.util.Calendar.getInstance()
								.getTime();

						row4.pid = pid;
						row4.root_pid = rootPid;
						row4.father_pid = fatherPid;

						row4.project = projectName;
						row4.job = jobName;
						row4.context = contextStr;

						/**
						 * [tLogCatcher_1 begin ] stop
						 */

						/**
						 * [tLogCatcher_1 main ] start
						 */

						currentComponent = "tLogCatcher_1";

						tos_count_tLogCatcher_1++;

						/**
						 * [tLogCatcher_1 main ] stop
						 */

						/**
						 * [tLogCatcher_1 process_data_begin ] start
						 */

						currentComponent = "tLogCatcher_1";

						/**
						 * [tLogCatcher_1 process_data_begin ] stop
						 */

						/**
						 * [tMap_3 main ] start
						 */

						currentComponent = "tMap_3";

						// row4
						// row4

						if (execStat) {
							runStat.updateStatOnConnection("row4" + iterateId,
									1, 1);
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;

						// ###############################
						// # Input tables (lookups)
						boolean rejectedInnerJoin_tMap_3 = false;
						boolean mainRowRejected_tMap_3 = false;

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
							// ###############################
							// # Output tables

							logData = null;

							// # Output table : 'logData'
							logData_tmp.moment = row4.moment;
							logData_tmp.pid = row4.pid;
							logData_tmp.root_pid = row4.root_pid;
							logData_tmp.father_pid = row4.father_pid;
							logData_tmp.system_pid = null;
							logData_tmp.project = row4.project;
							logData_tmp.job = row4.job;
							logData_tmp.job_repository_id = null;
							logData_tmp.job_version = null;
							logData_tmp.log_type = "Error Log";
							logData_tmp.context = row4.context;
							logData_tmp.origin = row4.origin;
							logData_tmp.priority = row4.priority;
							logData_tmp.type = row4.type;
							logData_tmp.message = row4.message;
							logData_tmp.code = row4.code;
							logData_tmp.duration = null;
							logData_tmp.Source_file = context.InputFile;
							logData_tmp.Target_file = context.OutputFile;
							logData_tmp.Row_count = Relational
									.ISNULL(row4.origin) ? 0
									: ((Integer) globalMap.get(row4.origin
											+ "_NB_LINE"));
							logData_tmp.Row_processed = Relational
									.ISNULL((Integer) globalMap.get(row4.origin
											+ "_NB_LINE_INSERTED"))
									|| Relational.ISNULL((Integer) globalMap
											.get(row4.origin
													+ "_NB_LINE_UPDATED"))
									|| Relational.ISNULL((Integer) globalMap
											.get(row4.origin
													+ "_NB_LINE_DELETED")) ? 0
									: (((Integer) globalMap.get(row4.origin
											+ "_NB_LINE_INSERTED"))
											+ ((Integer) globalMap
													.get(row4.origin
															+ "_NB_LINE_UPDATED")) + ((Integer) globalMap
											.get(row4.origin
													+ "_NB_LINE_DELETED")));
							logData_tmp.Row_rejected = Relational
									.ISNULL(((Integer) globalMap
											.get(row4.origin
													+ "_NB_LINE_REJECTED"))) ? 0
									: ((Integer) globalMap.get(row4.origin
											+ "_NB_LINE_REJECTED"));
							logData = logData_tmp;
							// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_3 = false;

						tos_count_tMap_3++;

						/**
						 * [tMap_3 main ] stop
						 */

						/**
						 * [tMap_3 process_data_begin ] start
						 */

						currentComponent = "tMap_3";

						/**
						 * [tMap_3 process_data_begin ] stop
						 */
						// Start of branch "logData"
						if (logData != null) {

							/**
							 * [tUnite_1 main ] start
							 */

							currentComponent = "tUnite_1";

							// logData
							// logData

							if (execStat) {
								runStat.updateStatOnConnection("logData"
										+ iterateId, 1, 1);
							}

							// StatData
							// logData

							// Assert_Data
							// logData

							// ////////

							// for output
							row9 = new row9Struct();

							row9.moment = logData.moment;
							row9.pid = logData.pid;
							row9.root_pid = logData.root_pid;
							row9.father_pid = logData.father_pid;
							row9.system_pid = logData.system_pid;
							row9.project = logData.project;
							row9.job = logData.job;
							row9.job_repository_id = logData.job_repository_id;
							row9.job_version = logData.job_version;
							row9.log_type = logData.log_type;
							row9.context = logData.context;
							row9.origin = logData.origin;
							row9.priority = logData.priority;
							row9.type = logData.type;
							row9.message = logData.message;
							row9.code = logData.code;
							row9.duration = logData.duration;
							row9.Source_file = logData.Source_file;
							row9.Target_file = logData.Target_file;
							row9.Row_count = logData.Row_count;
							row9.Row_processed = logData.Row_processed;
							row9.Row_rejected = logData.Row_rejected;

							nb_line_tUnite_1++;

							// ////////

							tos_count_tUnite_1++;

							/**
							 * [tUnite_1 main ] stop
							 */

							/**
							 * [tUnite_1 process_data_begin ] start
							 */

							currentComponent = "tUnite_1";

							/**
							 * [tUnite_1 process_data_begin ] stop
							 */

							/**
							 * [tMap_5 main ] start
							 */

							currentComponent = "tMap_5";

							// row9
							// row9

							if (execStat) {
								runStat.updateStatOnConnection("row9"
										+ iterateId, 1, 1);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_5 = false;
							boolean mainRowRejected_tMap_5 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
								// ###############################
								// # Output tables

								Output_row = null;

								// # Output table : 'Output_row'
								Output_row_tmp.Timestamp = row9.moment;
								Output_row_tmp.RunID = workspace_UUID;
								Output_row_tmp.Connection_node = row9.system_pid;
								Output_row_tmp.project = row9.project;
								Output_row_tmp.job = row9.job;
								Output_row_tmp.log_type = row9.log_type;
								Output_row_tmp.origin = row9.origin;
								Output_row_tmp.priority = row9.priority;
								Output_row_tmp.type = row9.type;
								Output_row_tmp.message = row9.message;
								Output_row_tmp.code = row9.code;
								Output_row_tmp.Source_file = row9.Source_file;
								Output_row_tmp.Target_file = row9.Target_file;
								Output_row_tmp.Row_count = row9.Row_count;
								Output_row_tmp.Row_processed = row9.Row_processed;
								Output_row_tmp.Row_rejected = row9.Row_rejected;
								Output_row = Output_row_tmp;
								// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_5 = false;

							tos_count_tMap_5++;

							/**
							 * [tMap_5 main ] stop
							 */

							/**
							 * [tMap_5 process_data_begin ] start
							 */

							currentComponent = "tMap_5";

							/**
							 * [tMap_5 process_data_begin ] stop
							 */
							// Start of branch "Output_row"
							if (Output_row != null) {

								/**
								 * [tDBOutput_2 main ] start
								 */

								currentComponent = "tDBOutput_2";

								// Output_row
								// Output_row

								if (execStat) {
									runStat.updateStatOnConnection("Output_row"
											+ iterateId, 1, 1);
								}

								whetherReject_tDBOutput_2 = false;
								if (Output_row.Timestamp != null) {
									date_tDBOutput_2 = Output_row.Timestamp
											.getTime();
									if (date_tDBOutput_2 < year1_tDBOutput_2
											|| date_tDBOutput_2 >= year10000_tDBOutput_2) {
										pstmt_tDBOutput_2.setString(1,
												"0000-00-00 00:00:00");
									} else {
										pstmt_tDBOutput_2.setTimestamp(1,
												new java.sql.Timestamp(
														date_tDBOutput_2));
									}
								} else {
									pstmt_tDBOutput_2.setNull(1,
											java.sql.Types.DATE);
								}

								if (Output_row.RunID == null) {
									pstmt_tDBOutput_2.setNull(2,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(2,
											Output_row.RunID);
								}

								if (Output_row.Connection_node == null) {
									pstmt_tDBOutput_2.setNull(3,
											java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setLong(3,
											Output_row.Connection_node);
								}

								if (Output_row.project == null) {
									pstmt_tDBOutput_2.setNull(4,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(4,
											Output_row.project);
								}

								if (Output_row.job == null) {
									pstmt_tDBOutput_2.setNull(5,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(5,
											Output_row.job);
								}

								if (Output_row.log_type == null) {
									pstmt_tDBOutput_2.setNull(6,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(6,
											Output_row.log_type);
								}

								if (Output_row.origin == null) {
									pstmt_tDBOutput_2.setNull(7,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(7,
											Output_row.origin);
								}

								if (Output_row.priority == null) {
									pstmt_tDBOutput_2.setNull(8,
											java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(8,
											Output_row.priority);
								}

								if (Output_row.type == null) {
									pstmt_tDBOutput_2.setNull(9,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(9,
											Output_row.type);
								}

								if (Output_row.message == null) {
									pstmt_tDBOutput_2.setNull(10,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(10,
											Output_row.message);
								}

								if (Output_row.code == null) {
									pstmt_tDBOutput_2.setNull(11,
											java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(11,
											Output_row.code);
								}

								if (Output_row.Source_file == null) {
									pstmt_tDBOutput_2.setNull(12,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(12,
											Output_row.Source_file);
								}

								if (Output_row.Target_file == null) {
									pstmt_tDBOutput_2.setNull(13,
											java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(13,
											Output_row.Target_file);
								}

								if (Output_row.Row_count == null) {
									pstmt_tDBOutput_2.setNull(14,
											java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(14,
											Output_row.Row_count);
								}

								if (Output_row.Row_processed == null) {
									pstmt_tDBOutput_2.setNull(15,
											java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(15,
											Output_row.Row_processed);
								}

								if (Output_row.Row_rejected == null) {
									pstmt_tDBOutput_2.setNull(16,
											java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setInt(16,
											Output_row.Row_rejected);
								}

								pstmt_tDBOutput_2.addBatch();
								nb_line_tDBOutput_2++;

								batchSizeCounter_tDBOutput_2++;
								if (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2) {
									try {
										int countSum_tDBOutput_2 = 0;
										for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
												.executeBatch()) {
											countSum_tDBOutput_2 += (countEach_tDBOutput_2 == java.sql.Statement.EXECUTE_FAILED ? 0
													: 1);
										}
										insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									} catch (java.sql.BatchUpdateException e) {
										int countSum_tDBOutput_2 = 0;
										for (int countEach_tDBOutput_2 : e
												.getUpdateCounts()) {
											countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
													: countEach_tDBOutput_2);
										}
										insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
										System.err.println(e.getMessage());
									}

									batchSizeCounter_tDBOutput_2 = 0;
								}
								commitCounter_tDBOutput_2++;

								if (commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {

									try {
										int countSum_tDBOutput_2 = 0;
										for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
												.executeBatch()) {
											countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
													: 1);
										}
										insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									} catch (java.sql.BatchUpdateException e) {
										int countSum_tDBOutput_2 = 0;
										for (int countEach_tDBOutput_2 : e
												.getUpdateCounts()) {
											countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
													: countEach_tDBOutput_2);
										}
										insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
										System.err.println(e.getMessage());

									}
									conn_tDBOutput_2.commit();
									commitCounter_tDBOutput_2 = 0;

								}

								tos_count_tDBOutput_2++;

								/**
								 * [tDBOutput_2 main ] stop
								 */

								/**
								 * [tDBOutput_2 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_2";

								/**
								 * [tDBOutput_2 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_2 process_data_end ] start
								 */

								currentComponent = "tDBOutput_2";

								/**
								 * [tDBOutput_2 process_data_end ] stop
								 */

							} // End of branch "Output_row"

							/**
							 * [tMap_5 process_data_end ] start
							 */

							currentComponent = "tMap_5";

							/**
							 * [tMap_5 process_data_end ] stop
							 */

							/**
							 * [tUnite_1 process_data_end ] start
							 */

							currentComponent = "tUnite_1";

							/**
							 * [tUnite_1 process_data_end ] stop
							 */

						} // End of branch "logData"

						/**
						 * [tMap_3 process_data_end ] start
						 */

						currentComponent = "tMap_3";

						/**
						 * [tMap_3 process_data_end ] stop
						 */

						/**
						 * [tLogCatcher_1 process_data_end ] start
						 */

						currentComponent = "tLogCatcher_1";

						/**
						 * [tLogCatcher_1 process_data_end ] stop
						 */

						/**
						 * [tLogCatcher_1 end ] start
						 */

						currentComponent = "tLogCatcher_1";

					}
				} catch (Exception e_tLogCatcher_1) {
					logIgnoredError(
							String.format(
									"tLogCatcher_1 - tLogCatcher failed to process log message(s) due to internal error: %s",
									e_tLogCatcher_1), e_tLogCatcher_1);
				}

				ok_Hash.put("tLogCatcher_1", true);
				end_Hash.put("tLogCatcher_1", System.currentTimeMillis());

				/**
				 * [tLogCatcher_1 end ] stop
				 */

				/**
				 * [tMap_3 end ] start
				 */

				currentComponent = "tMap_3";

				// ###############################
				// # Lookup hashes releasing
				// ###############################

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("row4" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("tMap_3", true);
				end_Hash.put("tMap_3", System.currentTimeMillis());

				/**
				 * [tMap_3 end ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("row3" + iterateId, 0, 0);

					}
				}

				int tos_count_tMap_1 = 0;

				// ###############################
				// # Lookup's keys initialization
				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				StatDataStruct StatData_tmp = new StatDataStruct();
				// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tStatCatcher_1 begin ] start
				 */

				ok_Hash.put("tStatCatcher_1", false);
				start_Hash.put("tStatCatcher_1", System.currentTimeMillis());

				currentComponent = "tStatCatcher_1";

				int tos_count_tStatCatcher_1 = 0;

				for (StatCatcherUtils.StatCatcherMessage scm : tStatCatcher_1
						.getMessages()) {
					row3.pid = pid;
					row3.root_pid = rootPid;
					row3.father_pid = fatherPid;
					row3.project = projectName;
					row3.job = jobName;
					row3.context = contextStr;
					row3.origin = (scm.getOrigin() == null
							|| scm.getOrigin().length() < 1 ? null : scm
							.getOrigin());
					row3.message = scm.getMessage();
					row3.duration = scm.getDuration();
					row3.moment = scm.getMoment();
					row3.message_type = scm.getMessageType();
					row3.job_version = scm.getJobVersion();
					row3.job_repository_id = scm.getJobId();
					row3.system_pid = scm.getSystemPid();

					/**
					 * [tStatCatcher_1 begin ] stop
					 */

					/**
					 * [tStatCatcher_1 main ] start
					 */

					currentComponent = "tStatCatcher_1";

					tos_count_tStatCatcher_1++;

					/**
					 * [tStatCatcher_1 main ] stop
					 */

					/**
					 * [tStatCatcher_1 process_data_begin ] start
					 */

					currentComponent = "tStatCatcher_1";

					/**
					 * [tStatCatcher_1 process_data_begin ] stop
					 */

					/**
					 * [tMap_1 main ] start
					 */

					currentComponent = "tMap_1";

					// row3
					// row3

					if (execStat) {
						runStat.updateStatOnConnection("row3" + iterateId, 1, 1);
					}

					boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

					// ###############################
					// # Input tables (lookups)
					boolean rejectedInnerJoin_tMap_1 = false;
					boolean mainRowRejected_tMap_1 = false;

					// ###############################
					{ // start of Var scope

						// ###############################
						// # Vars tables

						Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
						// ###############################
						// # Output tables

						StatData = null;

						// # Output table : 'StatData'
						StatData_tmp.moment = row3.moment;
						StatData_tmp.pid = row3.pid;
						StatData_tmp.root_pid = row3.root_pid;
						StatData_tmp.father_pid = row3.father_pid;
						StatData_tmp.system_pid = row3.system_pid;
						StatData_tmp.project = row3.project;
						StatData_tmp.job = row3.job;
						StatData_tmp.job_repository_id = row3.job_repository_id;
						StatData_tmp.job_version = null;
						StatData_tmp.log_type = "Statistics Log";
						StatData_tmp.context = row3.context;
						StatData_tmp.origin = row3.origin;
						StatData_tmp.priority = null;
						StatData_tmp.type = row3.message_type;
						StatData_tmp.message = row3.message;
						StatData_tmp.code = null;
						StatData_tmp.duration = row3.duration;
						StatData_tmp.Source_file = context.InputFile;
						StatData_tmp.Target_file = context.OutputFile;
						StatData_tmp.Row_count = Relational
								.ISNULL((Integer) globalMap.get(row3.origin
										+ "_NB_LINE")) ? 0
								: ((Integer) globalMap.get(row3.origin
										+ "_NB_LINE"));
						StatData_tmp.Row_processed = Relational
								.ISNULL((Integer) globalMap.get(row3.origin
										+ "_NB_LINE_INSERTED"))
								|| Relational.ISNULL((Integer) globalMap
										.get(row3.origin + "_NB_LINE_UPDATED"))
								|| Relational.ISNULL((Integer) globalMap
										.get(row3.origin + "_NB_LINE_DELETED")) ? 0
								: (((Integer) globalMap.get(row3.origin
										+ "_NB_LINE_INSERTED"))
										+ ((Integer) globalMap.get(row3.origin
												+ "_NB_LINE_UPDATED")) + ((Integer) globalMap
										.get(row3.origin + "_NB_LINE_DELETED")));
						StatData_tmp.Row_rejected = Relational
								.ISNULL((Integer) globalMap.get(row3.origin
										+ "_NB_LINE_REJECTED")) ? 0
								: ((Integer) globalMap.get(row3.origin
										+ "_NB_LINE_REJECTED"));
						StatData = StatData_tmp;
						// ###############################

					} // end of Var scope

					rejectedInnerJoin_tMap_1 = false;

					tos_count_tMap_1++;

					/**
					 * [tMap_1 main ] stop
					 */

					/**
					 * [tMap_1 process_data_begin ] start
					 */

					currentComponent = "tMap_1";

					/**
					 * [tMap_1 process_data_begin ] stop
					 */
					// Start of branch "StatData"
					if (StatData != null) {

						/**
						 * [tUnite_1 main ] start
						 */

						currentComponent = "tUnite_1";

						// logData
						// StatData

						// StatData
						// StatData

						if (execStat) {
							runStat.updateStatOnConnection("StatData"
									+ iterateId, 1, 1);
						}

						// Assert_Data
						// StatData

						// ////////

						// for output
						row9 = new row9Struct();

						row9.moment = StatData.moment;
						row9.pid = StatData.pid;
						row9.root_pid = StatData.root_pid;
						row9.father_pid = StatData.father_pid;
						row9.system_pid = StatData.system_pid;
						row9.project = StatData.project;
						row9.job = StatData.job;
						row9.job_repository_id = StatData.job_repository_id;
						row9.job_version = StatData.job_version;
						row9.log_type = StatData.log_type;
						row9.context = StatData.context;
						row9.origin = StatData.origin;
						row9.priority = StatData.priority;
						row9.type = StatData.type;
						row9.message = StatData.message;
						row9.code = StatData.code;
						row9.duration = StatData.duration;
						row9.Source_file = StatData.Source_file;
						row9.Target_file = StatData.Target_file;
						row9.Row_count = StatData.Row_count;
						row9.Row_processed = StatData.Row_processed;
						row9.Row_rejected = StatData.Row_rejected;

						nb_line_tUnite_1++;

						// ////////

						tos_count_tUnite_1++;

						/**
						 * [tUnite_1 main ] stop
						 */

						/**
						 * [tUnite_1 process_data_begin ] start
						 */

						currentComponent = "tUnite_1";

						/**
						 * [tUnite_1 process_data_begin ] stop
						 */

						/**
						 * [tMap_5 main ] start
						 */

						currentComponent = "tMap_5";

						// row9
						// row9

						if (execStat) {
							runStat.updateStatOnConnection("row9" + iterateId,
									1, 1);
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;

						// ###############################
						// # Input tables (lookups)
						boolean rejectedInnerJoin_tMap_5 = false;
						boolean mainRowRejected_tMap_5 = false;

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
							// ###############################
							// # Output tables

							Output_row = null;

							// # Output table : 'Output_row'
							Output_row_tmp.Timestamp = row9.moment;
							Output_row_tmp.RunID = workspace_UUID;
							Output_row_tmp.Connection_node = row9.system_pid;
							Output_row_tmp.project = row9.project;
							Output_row_tmp.job = row9.job;
							Output_row_tmp.log_type = row9.log_type;
							Output_row_tmp.origin = row9.origin;
							Output_row_tmp.priority = row9.priority;
							Output_row_tmp.type = row9.type;
							Output_row_tmp.message = row9.message;
							Output_row_tmp.code = row9.code;
							Output_row_tmp.Source_file = row9.Source_file;
							Output_row_tmp.Target_file = row9.Target_file;
							Output_row_tmp.Row_count = row9.Row_count;
							Output_row_tmp.Row_processed = row9.Row_processed;
							Output_row_tmp.Row_rejected = row9.Row_rejected;
							Output_row = Output_row_tmp;
							// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_5 = false;

						tos_count_tMap_5++;

						/**
						 * [tMap_5 main ] stop
						 */

						/**
						 * [tMap_5 process_data_begin ] start
						 */

						currentComponent = "tMap_5";

						/**
						 * [tMap_5 process_data_begin ] stop
						 */
						// Start of branch "Output_row"
						if (Output_row != null) {

							/**
							 * [tDBOutput_2 main ] start
							 */

							currentComponent = "tDBOutput_2";

							// Output_row
							// Output_row

							if (execStat) {
								runStat.updateStatOnConnection("Output_row"
										+ iterateId, 1, 1);
							}

							whetherReject_tDBOutput_2 = false;
							if (Output_row.Timestamp != null) {
								date_tDBOutput_2 = Output_row.Timestamp
										.getTime();
								if (date_tDBOutput_2 < year1_tDBOutput_2
										|| date_tDBOutput_2 >= year10000_tDBOutput_2) {
									pstmt_tDBOutput_2.setString(1,
											"0000-00-00 00:00:00");
								} else {
									pstmt_tDBOutput_2.setTimestamp(1,
											new java.sql.Timestamp(
													date_tDBOutput_2));
								}
							} else {
								pstmt_tDBOutput_2.setNull(1,
										java.sql.Types.DATE);
							}

							if (Output_row.RunID == null) {
								pstmt_tDBOutput_2.setNull(2,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2
										.setString(2, Output_row.RunID);
							}

							if (Output_row.Connection_node == null) {
								pstmt_tDBOutput_2.setNull(3,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setLong(3,
										Output_row.Connection_node);
							}

							if (Output_row.project == null) {
								pstmt_tDBOutput_2.setNull(4,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(4,
										Output_row.project);
							}

							if (Output_row.job == null) {
								pstmt_tDBOutput_2.setNull(5,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(5, Output_row.job);
							}

							if (Output_row.log_type == null) {
								pstmt_tDBOutput_2.setNull(6,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(6,
										Output_row.log_type);
							}

							if (Output_row.origin == null) {
								pstmt_tDBOutput_2.setNull(7,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(7,
										Output_row.origin);
							}

							if (Output_row.priority == null) {
								pstmt_tDBOutput_2.setNull(8,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2
										.setInt(8, Output_row.priority);
							}

							if (Output_row.type == null) {
								pstmt_tDBOutput_2.setNull(9,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(9, Output_row.type);
							}

							if (Output_row.message == null) {
								pstmt_tDBOutput_2.setNull(10,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(10,
										Output_row.message);
							}

							if (Output_row.code == null) {
								pstmt_tDBOutput_2.setNull(11,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(11, Output_row.code);
							}

							if (Output_row.Source_file == null) {
								pstmt_tDBOutput_2.setNull(12,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(12,
										Output_row.Source_file);
							}

							if (Output_row.Target_file == null) {
								pstmt_tDBOutput_2.setNull(13,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(13,
										Output_row.Target_file);
							}

							if (Output_row.Row_count == null) {
								pstmt_tDBOutput_2.setNull(14,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(14,
										Output_row.Row_count);
							}

							if (Output_row.Row_processed == null) {
								pstmt_tDBOutput_2.setNull(15,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(15,
										Output_row.Row_processed);
							}

							if (Output_row.Row_rejected == null) {
								pstmt_tDBOutput_2.setNull(16,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(16,
										Output_row.Row_rejected);
							}

							pstmt_tDBOutput_2.addBatch();
							nb_line_tDBOutput_2++;

							batchSizeCounter_tDBOutput_2++;
							if (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2) {
								try {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
											.executeBatch()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 == java.sql.Statement.EXECUTE_FAILED ? 0
												: 1);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
								} catch (java.sql.BatchUpdateException e) {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : e
											.getUpdateCounts()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
												: countEach_tDBOutput_2);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									System.err.println(e.getMessage());
								}

								batchSizeCounter_tDBOutput_2 = 0;
							}
							commitCounter_tDBOutput_2++;

							if (commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {

								try {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
											.executeBatch()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
												: 1);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
								} catch (java.sql.BatchUpdateException e) {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : e
											.getUpdateCounts()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
												: countEach_tDBOutput_2);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									System.err.println(e.getMessage());

								}
								conn_tDBOutput_2.commit();
								commitCounter_tDBOutput_2 = 0;

							}

							tos_count_tDBOutput_2++;

							/**
							 * [tDBOutput_2 main ] stop
							 */

							/**
							 * [tDBOutput_2 process_data_begin ] start
							 */

							currentComponent = "tDBOutput_2";

							/**
							 * [tDBOutput_2 process_data_begin ] stop
							 */

							/**
							 * [tDBOutput_2 process_data_end ] start
							 */

							currentComponent = "tDBOutput_2";

							/**
							 * [tDBOutput_2 process_data_end ] stop
							 */

						} // End of branch "Output_row"

						/**
						 * [tMap_5 process_data_end ] start
						 */

						currentComponent = "tMap_5";

						/**
						 * [tMap_5 process_data_end ] stop
						 */

						/**
						 * [tUnite_1 process_data_end ] start
						 */

						currentComponent = "tUnite_1";

						/**
						 * [tUnite_1 process_data_end ] stop
						 */

					} // End of branch "StatData"

					/**
					 * [tMap_1 process_data_end ] start
					 */

					currentComponent = "tMap_1";

					/**
					 * [tMap_1 process_data_end ] stop
					 */

					/**
					 * [tStatCatcher_1 process_data_end ] start
					 */

					currentComponent = "tStatCatcher_1";

					/**
					 * [tStatCatcher_1 process_data_end ] stop
					 */

					/**
					 * [tStatCatcher_1 end ] start
					 */

					currentComponent = "tStatCatcher_1";

				}

				ok_Hash.put("tStatCatcher_1", true);
				end_Hash.put("tStatCatcher_1", System.currentTimeMillis());

				/**
				 * [tStatCatcher_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

				// ###############################
				// # Lookup hashes releasing
				// ###############################

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("row3" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tMap_4 begin ] start
				 */

				ok_Hash.put("tMap_4", false);
				start_Hash.put("tMap_4", System.currentTimeMillis());

				currentComponent = "tMap_4";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("row6" + iterateId, 0, 0);

					}
				}

				int tos_count_tMap_4 = 0;

				// ###############################
				// # Lookup's keys initialization
				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_4__Struct {
				}
				Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				Assert_DataStruct Assert_Data_tmp = new Assert_DataStruct();
				// ###############################

				/**
				 * [tMap_4 begin ] stop
				 */

				/**
				 * [tAssertCatcher_1 begin ] start
				 */

				ok_Hash.put("tAssertCatcher_1", false);
				start_Hash.put("tAssertCatcher_1", System.currentTimeMillis());

				currentComponent = "tAssertCatcher_1";

				int tos_count_tAssertCatcher_1 = 0;

				for (AssertCatcherUtils.AssertCatcherMessage acm : tAssertCatcher_1
						.getMessages()) {
					row6.moment = acm.getMoment();
					row6.pid = acm.getPid();
					row6.project = acm.getProject();
					row6.job = acm.getJob();
					row6.language = acm.getLanguage();

					row6.origin = (acm.getOrigin() == null
							|| acm.getOrigin().length() < 1 ? null : acm
							.getOrigin());

					row6.status = acm.getStatus();
					row6.substatus = acm.getSubstatus();
					row6.description = acm.getDescription();

					/**
					 * [tAssertCatcher_1 begin ] stop
					 */

					/**
					 * [tAssertCatcher_1 main ] start
					 */

					currentComponent = "tAssertCatcher_1";

					tos_count_tAssertCatcher_1++;

					/**
					 * [tAssertCatcher_1 main ] stop
					 */

					/**
					 * [tAssertCatcher_1 process_data_begin ] start
					 */

					currentComponent = "tAssertCatcher_1";

					/**
					 * [tAssertCatcher_1 process_data_begin ] stop
					 */

					/**
					 * [tMap_4 main ] start
					 */

					currentComponent = "tMap_4";

					// row6
					// row6

					if (execStat) {
						runStat.updateStatOnConnection("row6" + iterateId, 1, 1);
					}

					boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;

					// ###############################
					// # Input tables (lookups)
					boolean rejectedInnerJoin_tMap_4 = false;
					boolean mainRowRejected_tMap_4 = false;

					// ###############################
					{ // start of Var scope

						// ###############################
						// # Vars tables

						Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
						// ###############################
						// # Output tables

						Assert_Data = null;

						// # Output table : 'Assert_Data'
						Assert_Data_tmp.moment = row6.moment;
						Assert_Data_tmp.pid = row6.pid;
						Assert_Data_tmp.root_pid = null;
						Assert_Data_tmp.father_pid = null;
						Assert_Data_tmp.system_pid = null;
						Assert_Data_tmp.project = row6.project;
						Assert_Data_tmp.job = row6.job;
						Assert_Data_tmp.job_repository_id = null;
						Assert_Data_tmp.job_version = null;
						Assert_Data_tmp.log_type = "Assert Log";
						Assert_Data_tmp.context = null;
						Assert_Data_tmp.origin = null;
						Assert_Data_tmp.priority = null;
						Assert_Data_tmp.type = null;
						Assert_Data_tmp.message = "Status" + row6.status
								+ "Substatus" + row6.substatus
								+ row6.description;
						Assert_Data_tmp.code = null;
						Assert_Data_tmp.duration = null;
						Assert_Data_tmp.Source_file = context.InputFile;
						Assert_Data_tmp.Target_file = context.OutputFile;
						Assert_Data_tmp.Row_count = Relational
								.ISNULL((Integer) globalMap.get(row6.origin
										+ "_NB_LINE")) ? 0
								: ((Integer) globalMap.get(row6.origin
										+ "_NB_LINE"));
						Assert_Data_tmp.Row_processed = Relational
								.ISNULL((Integer) globalMap.get(row6.origin
										+ "_NB_LINE_INSERTED"))
								|| Relational.ISNULL((Integer) globalMap
										.get(row6.origin + "_NB_LINE_UPDATED"))
								|| Relational.ISNULL((Integer) globalMap
										.get(row6.origin + "_NB_LINE_DELETED")) ? 0
								: (((Integer) globalMap.get(row6.origin
										+ "_NB_LINE_INSERTED"))
										+ ((Integer) globalMap.get(row6.origin
												+ "_NB_LINE_UPDATED")) + ((Integer) globalMap
										.get(row6.origin + "_NB_LINE_DELETED")));
						Assert_Data_tmp.Row_rejected = Relational
								.ISNULL(((Integer) globalMap.get(row6.origin
										+ "_NB_LINE_REJECTED"))) ? 0
								: ((Integer) globalMap.get(row6.origin
										+ "_NB_LINE_REJECTED"));
						Assert_Data = Assert_Data_tmp;
						// ###############################

					} // end of Var scope

					rejectedInnerJoin_tMap_4 = false;

					tos_count_tMap_4++;

					/**
					 * [tMap_4 main ] stop
					 */

					/**
					 * [tMap_4 process_data_begin ] start
					 */

					currentComponent = "tMap_4";

					/**
					 * [tMap_4 process_data_begin ] stop
					 */
					// Start of branch "Assert_Data"
					if (Assert_Data != null) {

						/**
						 * [tUnite_1 main ] start
						 */

						currentComponent = "tUnite_1";

						// logData
						// Assert_Data

						// StatData
						// Assert_Data

						// Assert_Data
						// Assert_Data

						if (execStat) {
							runStat.updateStatOnConnection("Assert_Data"
									+ iterateId, 1, 1);
						}

						// ////////

						// for output
						row9 = new row9Struct();

						row9.moment = Assert_Data.moment;
						row9.pid = Assert_Data.pid;
						row9.root_pid = Assert_Data.root_pid;
						row9.father_pid = Assert_Data.father_pid;
						row9.system_pid = Assert_Data.system_pid;
						row9.project = Assert_Data.project;
						row9.job = Assert_Data.job;
						row9.job_repository_id = Assert_Data.job_repository_id;
						row9.job_version = Assert_Data.job_version;
						row9.log_type = Assert_Data.log_type;
						row9.context = Assert_Data.context;
						row9.origin = Assert_Data.origin;
						row9.priority = Assert_Data.priority;
						row9.type = Assert_Data.type;
						row9.message = Assert_Data.message;
						row9.code = Assert_Data.code;
						row9.duration = Assert_Data.duration;
						row9.Source_file = Assert_Data.Source_file;
						row9.Target_file = Assert_Data.Target_file;
						row9.Row_count = Assert_Data.Row_count;
						row9.Row_processed = Assert_Data.Row_processed;
						row9.Row_rejected = Assert_Data.Row_rejected;

						nb_line_tUnite_1++;

						// ////////

						tos_count_tUnite_1++;

						/**
						 * [tUnite_1 main ] stop
						 */

						/**
						 * [tUnite_1 process_data_begin ] start
						 */

						currentComponent = "tUnite_1";

						/**
						 * [tUnite_1 process_data_begin ] stop
						 */

						/**
						 * [tMap_5 main ] start
						 */

						currentComponent = "tMap_5";

						// row9
						// row9

						if (execStat) {
							runStat.updateStatOnConnection("row9" + iterateId,
									1, 1);
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;

						// ###############################
						// # Input tables (lookups)
						boolean rejectedInnerJoin_tMap_5 = false;
						boolean mainRowRejected_tMap_5 = false;

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
							// ###############################
							// # Output tables

							Output_row = null;

							// # Output table : 'Output_row'
							Output_row_tmp.Timestamp = row9.moment;
							Output_row_tmp.RunID = workspace_UUID;
							Output_row_tmp.Connection_node = row9.system_pid;
							Output_row_tmp.project = row9.project;
							Output_row_tmp.job = row9.job;
							Output_row_tmp.log_type = row9.log_type;
							Output_row_tmp.origin = row9.origin;
							Output_row_tmp.priority = row9.priority;
							Output_row_tmp.type = row9.type;
							Output_row_tmp.message = row9.message;
							Output_row_tmp.code = row9.code;
							Output_row_tmp.Source_file = row9.Source_file;
							Output_row_tmp.Target_file = row9.Target_file;
							Output_row_tmp.Row_count = row9.Row_count;
							Output_row_tmp.Row_processed = row9.Row_processed;
							Output_row_tmp.Row_rejected = row9.Row_rejected;
							Output_row = Output_row_tmp;
							// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_5 = false;

						tos_count_tMap_5++;

						/**
						 * [tMap_5 main ] stop
						 */

						/**
						 * [tMap_5 process_data_begin ] start
						 */

						currentComponent = "tMap_5";

						/**
						 * [tMap_5 process_data_begin ] stop
						 */
						// Start of branch "Output_row"
						if (Output_row != null) {

							/**
							 * [tDBOutput_2 main ] start
							 */

							currentComponent = "tDBOutput_2";

							// Output_row
							// Output_row

							if (execStat) {
								runStat.updateStatOnConnection("Output_row"
										+ iterateId, 1, 1);
							}

							whetherReject_tDBOutput_2 = false;
							if (Output_row.Timestamp != null) {
								date_tDBOutput_2 = Output_row.Timestamp
										.getTime();
								if (date_tDBOutput_2 < year1_tDBOutput_2
										|| date_tDBOutput_2 >= year10000_tDBOutput_2) {
									pstmt_tDBOutput_2.setString(1,
											"0000-00-00 00:00:00");
								} else {
									pstmt_tDBOutput_2.setTimestamp(1,
											new java.sql.Timestamp(
													date_tDBOutput_2));
								}
							} else {
								pstmt_tDBOutput_2.setNull(1,
										java.sql.Types.DATE);
							}

							if (Output_row.RunID == null) {
								pstmt_tDBOutput_2.setNull(2,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2
										.setString(2, Output_row.RunID);
							}

							if (Output_row.Connection_node == null) {
								pstmt_tDBOutput_2.setNull(3,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setLong(3,
										Output_row.Connection_node);
							}

							if (Output_row.project == null) {
								pstmt_tDBOutput_2.setNull(4,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(4,
										Output_row.project);
							}

							if (Output_row.job == null) {
								pstmt_tDBOutput_2.setNull(5,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(5, Output_row.job);
							}

							if (Output_row.log_type == null) {
								pstmt_tDBOutput_2.setNull(6,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(6,
										Output_row.log_type);
							}

							if (Output_row.origin == null) {
								pstmt_tDBOutput_2.setNull(7,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(7,
										Output_row.origin);
							}

							if (Output_row.priority == null) {
								pstmt_tDBOutput_2.setNull(8,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2
										.setInt(8, Output_row.priority);
							}

							if (Output_row.type == null) {
								pstmt_tDBOutput_2.setNull(9,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(9, Output_row.type);
							}

							if (Output_row.message == null) {
								pstmt_tDBOutput_2.setNull(10,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(10,
										Output_row.message);
							}

							if (Output_row.code == null) {
								pstmt_tDBOutput_2.setNull(11,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(11, Output_row.code);
							}

							if (Output_row.Source_file == null) {
								pstmt_tDBOutput_2.setNull(12,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(12,
										Output_row.Source_file);
							}

							if (Output_row.Target_file == null) {
								pstmt_tDBOutput_2.setNull(13,
										java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(13,
										Output_row.Target_file);
							}

							if (Output_row.Row_count == null) {
								pstmt_tDBOutput_2.setNull(14,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(14,
										Output_row.Row_count);
							}

							if (Output_row.Row_processed == null) {
								pstmt_tDBOutput_2.setNull(15,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(15,
										Output_row.Row_processed);
							}

							if (Output_row.Row_rejected == null) {
								pstmt_tDBOutput_2.setNull(16,
										java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(16,
										Output_row.Row_rejected);
							}

							pstmt_tDBOutput_2.addBatch();
							nb_line_tDBOutput_2++;

							batchSizeCounter_tDBOutput_2++;
							if (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2) {
								try {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
											.executeBatch()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 == java.sql.Statement.EXECUTE_FAILED ? 0
												: 1);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
								} catch (java.sql.BatchUpdateException e) {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : e
											.getUpdateCounts()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
												: countEach_tDBOutput_2);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									System.err.println(e.getMessage());
								}

								batchSizeCounter_tDBOutput_2 = 0;
							}
							commitCounter_tDBOutput_2++;

							if (commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {

								try {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
											.executeBatch()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
												: 1);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
								} catch (java.sql.BatchUpdateException e) {
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : e
											.getUpdateCounts()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
												: countEach_tDBOutput_2);
									}
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									System.err.println(e.getMessage());

								}
								conn_tDBOutput_2.commit();
								commitCounter_tDBOutput_2 = 0;

							}

							tos_count_tDBOutput_2++;

							/**
							 * [tDBOutput_2 main ] stop
							 */

							/**
							 * [tDBOutput_2 process_data_begin ] start
							 */

							currentComponent = "tDBOutput_2";

							/**
							 * [tDBOutput_2 process_data_begin ] stop
							 */

							/**
							 * [tDBOutput_2 process_data_end ] start
							 */

							currentComponent = "tDBOutput_2";

							/**
							 * [tDBOutput_2 process_data_end ] stop
							 */

						} // End of branch "Output_row"

						/**
						 * [tMap_5 process_data_end ] start
						 */

						currentComponent = "tMap_5";

						/**
						 * [tMap_5 process_data_end ] stop
						 */

						/**
						 * [tUnite_1 process_data_end ] start
						 */

						currentComponent = "tUnite_1";

						/**
						 * [tUnite_1 process_data_end ] stop
						 */

					} // End of branch "Assert_Data"

					/**
					 * [tMap_4 process_data_end ] start
					 */

					currentComponent = "tMap_4";

					/**
					 * [tMap_4 process_data_end ] stop
					 */

					/**
					 * [tAssertCatcher_1 process_data_end ] start
					 */

					currentComponent = "tAssertCatcher_1";

					/**
					 * [tAssertCatcher_1 process_data_end ] stop
					 */

					/**
					 * [tAssertCatcher_1 end ] start
					 */

					currentComponent = "tAssertCatcher_1";

				}

				ok_Hash.put("tAssertCatcher_1", true);
				end_Hash.put("tAssertCatcher_1", System.currentTimeMillis());

				/**
				 * [tAssertCatcher_1 end ] stop
				 */

				/**
				 * [tMap_4 end ] start
				 */

				currentComponent = "tMap_4";

				// ###############################
				// # Lookup hashes releasing
				// ###############################

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("row6" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("tMap_4", true);
				end_Hash.put("tMap_4", System.currentTimeMillis());

				/**
				 * [tMap_4 end ] stop
				 */

				/**
				 * [tUnite_1 end ] start
				 */

				currentComponent = "tUnite_1";

				globalMap.put("tUnite_1_NB_LINE", nb_line_tUnite_1);
				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("logData" + iterateId,
								2, 0);
					}
				}

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("StatData" + iterateId,
								2, 0);
					}
				}

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("Assert_Data"
								+ iterateId, 2, 0);
					}
				}

				ok_Hash.put("tUnite_1", true);
				end_Hash.put("tUnite_1", System.currentTimeMillis());

				/**
				 * [tUnite_1 end ] stop
				 */

				/**
				 * [tMap_5 end ] start
				 */

				currentComponent = "tMap_5";

				// ###############################
				// # Lookup hashes releasing
				// ###############################

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("row9" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("tMap_5", true);
				end_Hash.put("tMap_5", System.currentTimeMillis());

				/**
				 * [tMap_5 end ] stop
				 */

				/**
				 * [tDBOutput_2 end ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					if (batchSizeCounter_tDBOutput_2 != 0) {
						int countSum_tDBOutput_2 = 0;

						for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2
								.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}

						insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

					}

				} catch (java.sql.BatchUpdateException e) {

					int countSum_tDBOutput_2 = 0;
					for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0
								: countEach_tDBOutput_2);
					}

					insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

					globalMap.put(currentComponent + "_ERROR_MESSAGE",
							e.getMessage());
					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_2 = 0;

				if (pstmt_tDBOutput_2 != null) {

					pstmt_tDBOutput_2.close();
					resourceMap.remove("pstmt_tDBOutput_2");

				}
				resourceMap.put("statementClosed_tDBOutput_2", true);
				if (commitCounter_tDBOutput_2 > 0) {

					conn_tDBOutput_2.commit();

				}

				conn_tDBOutput_2.close();

				resourceMap.put("finish_tDBOutput_2", true);

				nb_line_deleted_tDBOutput_2 = nb_line_deleted_tDBOutput_2
						+ deletedCount_tDBOutput_2;
				nb_line_update_tDBOutput_2 = nb_line_update_tDBOutput_2
						+ updatedCount_tDBOutput_2;
				nb_line_inserted_tDBOutput_2 = nb_line_inserted_tDBOutput_2
						+ insertedCount_tDBOutput_2;
				nb_line_rejected_tDBOutput_2 = nb_line_rejected_tDBOutput_2
						+ rejectedCount_tDBOutput_2;

				globalMap.put("tDBOutput_2_NB_LINE", nb_line_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_UPDATED",
						nb_line_update_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_INSERTED",
						nb_line_inserted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_DELETED",
						nb_line_deleted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_REJECTED",
						nb_line_rejected_tDBOutput_2);

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection(
								"Output_row" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("tDBOutput_2", true);
				end_Hash.put("tDBOutput_2", System.currentTimeMillis());

				/**
				 * [tDBOutput_2 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tLogCatcher_1 finally ] start
				 */

				currentComponent = "tLogCatcher_1";

				/**
				 * [tLogCatcher_1 finally ] stop
				 */

				/**
				 * [tMap_3 finally ] start
				 */

				currentComponent = "tMap_3";

				/**
				 * [tMap_3 finally ] stop
				 */

				/**
				 * [tStatCatcher_1 finally ] start
				 */

				currentComponent = "tStatCatcher_1";

				/**
				 * [tStatCatcher_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tAssertCatcher_1 finally ] start
				 */

				currentComponent = "tAssertCatcher_1";

				/**
				 * [tAssertCatcher_1 finally ] stop
				 */

				/**
				 * [tMap_4 finally ] start
				 */

				currentComponent = "tMap_4";

				/**
				 * [tMap_4 finally ] stop
				 */

				/**
				 * [tUnite_1 finally ] start
				 */

				currentComponent = "tUnite_1";

				/**
				 * [tUnite_1 finally ] stop
				 */

				/**
				 * [tMap_5 finally ] start
				 */

				currentComponent = "tMap_5";

				/**
				 * [tMap_5 finally ] stop
				 */

				/**
				 * [tDBOutput_2 finally ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
						if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_2")) != null) {
							pstmtToClose_tDBOutput_2.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_2") == null) {
						java.sql.Connection ctn_tDBOutput_2 = null;
						if ((ctn_tDBOutput_2 = (java.sql.Connection) resourceMap
								.get("conn_tDBOutput_2")) != null) {
							try {
								ctn_tDBOutput_2.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_2) {
								String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :"
										+ sqlEx_tDBOutput_2.getMessage();
								System.err.println(errorMessage_tDBOutput_2);
							}
						}
					}
				}

				/**
				 * [tDBOutput_2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 1);
	}

	public void tPrejob_1Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception()
						.getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tPrejob_1 begin ] start
				 */

				ok_Hash.put("tPrejob_1", false);
				start_Hash.put("tPrejob_1", System.currentTimeMillis());

				currentComponent = "tPrejob_1";

				int tos_count_tPrejob_1 = 0;

				/**
				 * [tPrejob_1 begin ] stop
				 */

				/**
				 * [tPrejob_1 main ] start
				 */

				currentComponent = "tPrejob_1";

				tos_count_tPrejob_1++;

				/**
				 * [tPrejob_1 main ] stop
				 */

				/**
				 * [tPrejob_1 process_data_begin ] start
				 */

				currentComponent = "tPrejob_1";

				/**
				 * [tPrejob_1 process_data_begin ] stop
				 */

				/**
				 * [tPrejob_1 process_data_end ] start
				 */

				currentComponent = "tPrejob_1";

				/**
				 * [tPrejob_1 process_data_end ] stop
				 */

				/**
				 * [tPrejob_1 end ] start
				 */

				currentComponent = "tPrejob_1";

				ok_Hash.put("tPrejob_1", true);
				end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if (execStat) {
					runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tJava_1Process(globalMap);

				/**
				 * [tPrejob_1 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tPrejob_1 finally ] start
				 */

				currentComponent = "tPrejob_1";

				/**
				 * [tPrejob_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}

	public static class row_talendStats_FILEStruct implements
			routines.system.IPersistableRow<row_talendStats_FILEStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message_type;

		public String getMessage_type() {
			return this.message_type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.father_pid = readString(dis);

					this.root_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.message_type = readString(dis);

					this.message = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.root_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message_type, dos);

				// String

				writeString(this.message, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",message_type=" + message_type);
			sb.append(",message=" + message);
			sb.append(",duration=" + String.valueOf(duration));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendStats_FILEStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row_talendStats_STATSStruct implements
			routines.system.IPersistableRow<row_talendStats_STATSStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message_type;

		public String getMessage_type() {
			return this.message_type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.father_pid = readString(dis);

					this.root_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.message_type = readString(dis);

					this.message = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.root_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message_type, dos);

				// String

				writeString(this.message, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",message_type=" + message_type);
			sb.append(",message=" + message);
			sb.append(",duration=" + String.valueOf(duration));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendStats_STATSStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void talendStats_STATSProcess(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception()
						.getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row_talendStats_STATSStruct row_talendStats_STATS = new row_talendStats_STATSStruct();
				row_talendStats_STATSStruct row_talendStats_FILE = row_talendStats_STATS;

				/**
				 * [talendStats_CONSOLE begin ] start
				 */

				ok_Hash.put("talendStats_CONSOLE", false);
				start_Hash.put("talendStats_CONSOLE",
						System.currentTimeMillis());

				currentVirtualComponent = "talendStats_CONSOLE";

				currentComponent = "talendStats_CONSOLE";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);

					}
				}

				int tos_count_talendStats_CONSOLE = 0;

				// /////////////////////

				final String OUTPUT_FIELD_SEPARATOR_talendStats_CONSOLE = "|";
				java.io.PrintStream consoleOut_talendStats_CONSOLE = null;

				StringBuilder strBuffer_talendStats_CONSOLE = null;
				int nb_line_talendStats_CONSOLE = 0;
				// /////////////////////

				/**
				 * [talendStats_CONSOLE begin ] stop
				 */

				/**
				 * [talendStats_FILE begin ] start
				 */

				ok_Hash.put("talendStats_FILE", false);
				start_Hash.put("talendStats_FILE", System.currentTimeMillis());

				currentVirtualComponent = "talendStats_FILE";

				currentComponent = "talendStats_FILE";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);

					}
				}

				int tos_count_talendStats_FILE = 0;

				String fileName_talendStats_FILE = "";
				fileName_talendStats_FILE = (new java.io.File(
						"C:/Users/ruchiagarwal3/Documents/Ruchi- Deloitte/CDP 2.0/talend"
								+ "/" + "stats_file.xls")).getAbsolutePath()
						.replace("\\", "/");
				String fullName_talendStats_FILE = null;
				String extension_talendStats_FILE = null;
				String directory_talendStats_FILE = null;
				if ((fileName_talendStats_FILE.indexOf("/") != -1)) {
					if (fileName_talendStats_FILE.lastIndexOf(".") < fileName_talendStats_FILE
							.lastIndexOf("/")) {
						fullName_talendStats_FILE = fileName_talendStats_FILE;
						extension_talendStats_FILE = "";
					} else {
						fullName_talendStats_FILE = fileName_talendStats_FILE
								.substring(0, fileName_talendStats_FILE
										.lastIndexOf("."));
						extension_talendStats_FILE = fileName_talendStats_FILE
								.substring(fileName_talendStats_FILE
										.lastIndexOf("."));
					}
					directory_talendStats_FILE = fileName_talendStats_FILE
							.substring(0,
									fileName_talendStats_FILE.lastIndexOf("/"));
				} else {
					if (fileName_talendStats_FILE.lastIndexOf(".") != -1) {
						fullName_talendStats_FILE = fileName_talendStats_FILE
								.substring(0, fileName_talendStats_FILE
										.lastIndexOf("."));
						extension_talendStats_FILE = fileName_talendStats_FILE
								.substring(fileName_talendStats_FILE
										.lastIndexOf("."));
					} else {
						fullName_talendStats_FILE = fileName_talendStats_FILE;
						extension_talendStats_FILE = "";
					}
					directory_talendStats_FILE = "";
				}
				boolean isFileGenerated_talendStats_FILE = true;
				java.io.File filetalendStats_FILE = new java.io.File(
						fileName_talendStats_FILE);
				globalMap.put("talendStats_FILE_FILE_NAME",
						fileName_talendStats_FILE);
				if (filetalendStats_FILE.exists()) {
					isFileGenerated_talendStats_FILE = false;
				}
				int nb_line_talendStats_FILE = 0;
				int splitedFileNo_talendStats_FILE = 0;
				int currentRow_talendStats_FILE = 0;

				final String OUT_DELIM_talendStats_FILE = /**
				 * Start field
				 * talendStats_FILE:FIELDSEPARATOR
				 */
				";"/** End field talendStats_FILE:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_talendStats_FILE = /**
				 * Start field
				 * talendStats_FILE:ROWSEPARATOR
				 */
				"\n"/** End field talendStats_FILE:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_talendStats_FILE != null
						&& directory_talendStats_FILE.trim().length() != 0) {
					java.io.File dir_talendStats_FILE = new java.io.File(
							directory_talendStats_FILE);
					if (!dir_talendStats_FILE.exists()) {
						dir_talendStats_FILE.mkdirs();
					}
				}

				// routines.system.Row
				java.io.Writer outtalendStats_FILE = null;

				outtalendStats_FILE = new java.io.BufferedWriter(
						new java.io.OutputStreamWriter(
								new java.io.FileOutputStream(
										fileName_talendStats_FILE, true),
								"UTF-8"));

				resourceMap.put("out_talendStats_FILE", outtalendStats_FILE);
				resourceMap.put("nb_line_talendStats_FILE",
						nb_line_talendStats_FILE);

				/**
				 * [talendStats_FILE begin ] stop
				 */

				/**
				 * [talendStats_STATS begin ] start
				 */

				ok_Hash.put("talendStats_STATS", false);
				start_Hash.put("talendStats_STATS", System.currentTimeMillis());

				currentVirtualComponent = "talendStats_STATS";

				currentComponent = "talendStats_STATS";

				int tos_count_talendStats_STATS = 0;

				for (StatCatcherUtils.StatCatcherMessage scm : talendStats_STATS
						.getMessages()) {
					row_talendStats_STATS.pid = pid;
					row_talendStats_STATS.root_pid = rootPid;
					row_talendStats_STATS.father_pid = fatherPid;
					row_talendStats_STATS.project = projectName;
					row_talendStats_STATS.job = jobName;
					row_talendStats_STATS.context = contextStr;
					row_talendStats_STATS.origin = (scm.getOrigin() == null
							|| scm.getOrigin().length() < 1 ? null : scm
							.getOrigin());
					row_talendStats_STATS.message = scm.getMessage();
					row_talendStats_STATS.duration = scm.getDuration();
					row_talendStats_STATS.moment = scm.getMoment();
					row_talendStats_STATS.message_type = scm.getMessageType();
					row_talendStats_STATS.job_version = scm.getJobVersion();
					row_talendStats_STATS.job_repository_id = scm.getJobId();
					row_talendStats_STATS.system_pid = scm.getSystemPid();

					/**
					 * [talendStats_STATS begin ] stop
					 */

					/**
					 * [talendStats_STATS main ] start
					 */

					currentVirtualComponent = "talendStats_STATS";

					currentComponent = "talendStats_STATS";

					tos_count_talendStats_STATS++;

					/**
					 * [talendStats_STATS main ] stop
					 */

					/**
					 * [talendStats_STATS process_data_begin ] start
					 */

					currentVirtualComponent = "talendStats_STATS";

					currentComponent = "talendStats_STATS";

					/**
					 * [talendStats_STATS process_data_begin ] stop
					 */

					/**
					 * [talendStats_FILE main ] start
					 */

					currentVirtualComponent = "talendStats_FILE";

					currentComponent = "talendStats_FILE";

					// Main
					// row_talendStats_STATS

					if (execStat) {
						runStat.updateStatOnConnection("Main" + iterateId, 1, 1);
					}

					StringBuilder sb_talendStats_FILE = new StringBuilder();
					if (row_talendStats_STATS.moment != null) {
						sb_talendStats_FILE.append(FormatterUtils.format_Date(
								row_talendStats_STATS.moment,
								"yyyy-MM-dd HH:mm:ss"));
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.pid != null) {
						sb_talendStats_FILE.append(row_talendStats_STATS.pid);
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.father_pid != null) {
						sb_talendStats_FILE
								.append(row_talendStats_STATS.father_pid);
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.root_pid != null) {
						sb_talendStats_FILE
								.append(row_talendStats_STATS.root_pid);
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.system_pid != null) {
						sb_talendStats_FILE
								.append(row_talendStats_STATS.system_pid);
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.project != null) {
						sb_talendStats_FILE
								.append(row_talendStats_STATS.project);
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.job != null) {
						sb_talendStats_FILE.append(row_talendStats_STATS.job);
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.job_repository_id != null) {
						sb_talendStats_FILE
								.append(row_talendStats_STATS.job_repository_id);
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.job_version != null) {
						sb_talendStats_FILE
								.append(row_talendStats_STATS.job_version);
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.context != null) {
						sb_talendStats_FILE
								.append(row_talendStats_STATS.context);
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.origin != null) {
						sb_talendStats_FILE
								.append(row_talendStats_STATS.origin);
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.message_type != null) {
						sb_talendStats_FILE
								.append(row_talendStats_STATS.message_type);
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.message != null) {
						sb_talendStats_FILE
								.append(row_talendStats_STATS.message);
					}
					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);
					if (row_talendStats_STATS.duration != null) {
						sb_talendStats_FILE
								.append(row_talendStats_STATS.duration);
					}
					sb_talendStats_FILE
							.append(OUT_DELIM_ROWSEP_talendStats_FILE);

					nb_line_talendStats_FILE++;
					resourceMap.put("nb_line_talendStats_FILE",
							nb_line_talendStats_FILE);

					outtalendStats_FILE.write(sb_talendStats_FILE.toString());

					row_talendStats_FILE = row_talendStats_STATS;

					tos_count_talendStats_FILE++;

					/**
					 * [talendStats_FILE main ] stop
					 */

					/**
					 * [talendStats_FILE process_data_begin ] start
					 */

					currentVirtualComponent = "talendStats_FILE";

					currentComponent = "talendStats_FILE";

					/**
					 * [talendStats_FILE process_data_begin ] stop
					 */

					/**
					 * [talendStats_CONSOLE main ] start
					 */

					currentVirtualComponent = "talendStats_CONSOLE";

					currentComponent = "talendStats_CONSOLE";

					// Main
					// row_talendStats_FILE

					if (execStat) {
						runStat.updateStatOnConnection("Main" + iterateId, 1, 1);
					}

					// /////////////////////

					strBuffer_talendStats_CONSOLE = new StringBuilder();

					if (row_talendStats_FILE.moment != null) { //

						strBuffer_talendStats_CONSOLE.append(FormatterUtils
								.format_Date(row_talendStats_FILE.moment,
										"yyyy-MM-dd HH:mm:ss"));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.pid != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_FILE.pid));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.father_pid != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_FILE.father_pid));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.root_pid != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_FILE.root_pid));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.system_pid != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_FILE.system_pid));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.project != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_FILE.project));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.job != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_FILE.job));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.job_repository_id != null) { //

						strBuffer_talendStats_CONSOLE
								.append(String
										.valueOf(row_talendStats_FILE.job_repository_id));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.job_version != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_FILE.job_version));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.context != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_FILE.context));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.origin != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_FILE.origin));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.message_type != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_FILE.message_type));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.message != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_FILE.message));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_FILE.duration != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_FILE.duration));

					} //

					if (globalMap.get("tLogRow_CONSOLE") != null) {
						consoleOut_talendStats_CONSOLE = (java.io.PrintStream) globalMap
								.get("tLogRow_CONSOLE");
					} else {
						consoleOut_talendStats_CONSOLE = new java.io.PrintStream(
								new java.io.BufferedOutputStream(System.out));
						globalMap.put("tLogRow_CONSOLE",
								consoleOut_talendStats_CONSOLE);
					}
					consoleOut_talendStats_CONSOLE
							.println(strBuffer_talendStats_CONSOLE.toString());
					consoleOut_talendStats_CONSOLE.flush();
					nb_line_talendStats_CONSOLE++;
					// ////

					// ////

					// /////////////////////

					tos_count_talendStats_CONSOLE++;

					/**
					 * [talendStats_CONSOLE main ] stop
					 */

					/**
					 * [talendStats_CONSOLE process_data_begin ] start
					 */

					currentVirtualComponent = "talendStats_CONSOLE";

					currentComponent = "talendStats_CONSOLE";

					/**
					 * [talendStats_CONSOLE process_data_begin ] stop
					 */

					/**
					 * [talendStats_CONSOLE process_data_end ] start
					 */

					currentVirtualComponent = "talendStats_CONSOLE";

					currentComponent = "talendStats_CONSOLE";

					/**
					 * [talendStats_CONSOLE process_data_end ] stop
					 */

					/**
					 * [talendStats_FILE process_data_end ] start
					 */

					currentVirtualComponent = "talendStats_FILE";

					currentComponent = "talendStats_FILE";

					/**
					 * [talendStats_FILE process_data_end ] stop
					 */

					/**
					 * [talendStats_STATS process_data_end ] start
					 */

					currentVirtualComponent = "talendStats_STATS";

					currentComponent = "talendStats_STATS";

					/**
					 * [talendStats_STATS process_data_end ] stop
					 */

					/**
					 * [talendStats_STATS end ] start
					 */

					currentVirtualComponent = "talendStats_STATS";

					currentComponent = "talendStats_STATS";

				}

				ok_Hash.put("talendStats_STATS", true);
				end_Hash.put("talendStats_STATS", System.currentTimeMillis());

				/**
				 * [talendStats_STATS end ] stop
				 */

				/**
				 * [talendStats_FILE end ] start
				 */

				currentVirtualComponent = "talendStats_FILE";

				currentComponent = "talendStats_FILE";

				if (outtalendStats_FILE != null) {
					outtalendStats_FILE.flush();
					outtalendStats_FILE.close();
				}

				globalMap.put("talendStats_FILE_NB_LINE",
						nb_line_talendStats_FILE);
				globalMap.put("talendStats_FILE_FILE_NAME",
						fileName_talendStats_FILE);

				resourceMap.put("finish_talendStats_FILE", true);

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("Main" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("talendStats_FILE", true);
				end_Hash.put("talendStats_FILE", System.currentTimeMillis());

				/**
				 * [talendStats_FILE end ] stop
				 */

				/**
				 * [talendStats_CONSOLE end ] start
				 */

				currentVirtualComponent = "talendStats_CONSOLE";

				currentComponent = "talendStats_CONSOLE";

				// ////
				// ////
				globalMap.put("talendStats_CONSOLE_NB_LINE",
						nb_line_talendStats_CONSOLE);

				// /////////////////////

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("Main" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("talendStats_CONSOLE", true);
				end_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());

				/**
				 * [talendStats_CONSOLE end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [talendStats_STATS finally ] start
				 */

				currentVirtualComponent = "talendStats_STATS";

				currentComponent = "talendStats_STATS";

				/**
				 * [talendStats_STATS finally ] stop
				 */

				/**
				 * [talendStats_FILE finally ] start
				 */

				currentVirtualComponent = "talendStats_FILE";

				currentComponent = "talendStats_FILE";

				if (resourceMap.get("finish_talendStats_FILE") == null) {

					java.io.Writer outtalendStats_FILE = (java.io.Writer) resourceMap
							.get("out_talendStats_FILE");
					if (outtalendStats_FILE != null) {
						outtalendStats_FILE.flush();
						outtalendStats_FILE.close();
					}

				}

				/**
				 * [talendStats_FILE finally ] stop
				 */

				/**
				 * [talendStats_CONSOLE finally ] start
				 */

				currentVirtualComponent = "talendStats_CONSOLE";

				currentComponent = "talendStats_CONSOLE";

				/**
				 * [talendStats_CONSOLE finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 1);
	}

	public static class row_talendLogs_FILEStruct implements
			routines.system.IPersistableRow<row_talendLogs_FILEStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					this.project = readString(dis);

					this.job = readString(dis);

					this.context = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.origin = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.context, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",context=" + context);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",origin=" + origin);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendLogs_FILEStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row_talendLogs_LOGSStruct implements
			routines.system.IPersistableRow<row_talendLogs_LOGSStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					this.project = readString(dis);

					this.job = readString(dis);

					this.context = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.origin = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.context, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",context=" + context);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",origin=" + origin);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendLogs_LOGSStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void talendLogs_LOGSProcess(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception()
						.getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row_talendLogs_LOGSStruct row_talendLogs_LOGS = new row_talendLogs_LOGSStruct();
				row_talendLogs_LOGSStruct row_talendLogs_FILE = row_talendLogs_LOGS;

				/**
				 * [talendLogs_CONSOLE begin ] start
				 */

				ok_Hash.put("talendLogs_CONSOLE", false);
				start_Hash
						.put("talendLogs_CONSOLE", System.currentTimeMillis());

				currentVirtualComponent = "talendLogs_CONSOLE";

				currentComponent = "talendLogs_CONSOLE";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);

					}
				}

				int tos_count_talendLogs_CONSOLE = 0;

				// /////////////////////

				final String OUTPUT_FIELD_SEPARATOR_talendLogs_CONSOLE = "|";
				java.io.PrintStream consoleOut_talendLogs_CONSOLE = null;

				StringBuilder strBuffer_talendLogs_CONSOLE = null;
				int nb_line_talendLogs_CONSOLE = 0;
				// /////////////////////

				/**
				 * [talendLogs_CONSOLE begin ] stop
				 */

				/**
				 * [talendLogs_FILE begin ] start
				 */

				ok_Hash.put("talendLogs_FILE", false);
				start_Hash.put("talendLogs_FILE", System.currentTimeMillis());

				currentVirtualComponent = "talendLogs_FILE";

				currentComponent = "talendLogs_FILE";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);

					}
				}

				int tos_count_talendLogs_FILE = 0;

				String fileName_talendLogs_FILE = "";
				fileName_talendLogs_FILE = (new java.io.File(
						"C:/Users/ruchiagarwal3/Documents/Ruchi- Deloitte/CDP 2.0/talend"
								+ "/" + "logs_file.xls")).getAbsolutePath()
						.replace("\\", "/");
				String fullName_talendLogs_FILE = null;
				String extension_talendLogs_FILE = null;
				String directory_talendLogs_FILE = null;
				if ((fileName_talendLogs_FILE.indexOf("/") != -1)) {
					if (fileName_talendLogs_FILE.lastIndexOf(".") < fileName_talendLogs_FILE
							.lastIndexOf("/")) {
						fullName_talendLogs_FILE = fileName_talendLogs_FILE;
						extension_talendLogs_FILE = "";
					} else {
						fullName_talendLogs_FILE = fileName_talendLogs_FILE
								.substring(0, fileName_talendLogs_FILE
										.lastIndexOf("."));
						extension_talendLogs_FILE = fileName_talendLogs_FILE
								.substring(fileName_talendLogs_FILE
										.lastIndexOf("."));
					}
					directory_talendLogs_FILE = fileName_talendLogs_FILE
							.substring(0,
									fileName_talendLogs_FILE.lastIndexOf("/"));
				} else {
					if (fileName_talendLogs_FILE.lastIndexOf(".") != -1) {
						fullName_talendLogs_FILE = fileName_talendLogs_FILE
								.substring(0, fileName_talendLogs_FILE
										.lastIndexOf("."));
						extension_talendLogs_FILE = fileName_talendLogs_FILE
								.substring(fileName_talendLogs_FILE
										.lastIndexOf("."));
					} else {
						fullName_talendLogs_FILE = fileName_talendLogs_FILE;
						extension_talendLogs_FILE = "";
					}
					directory_talendLogs_FILE = "";
				}
				boolean isFileGenerated_talendLogs_FILE = true;
				java.io.File filetalendLogs_FILE = new java.io.File(
						fileName_talendLogs_FILE);
				globalMap.put("talendLogs_FILE_FILE_NAME",
						fileName_talendLogs_FILE);
				if (filetalendLogs_FILE.exists()) {
					isFileGenerated_talendLogs_FILE = false;
				}
				int nb_line_talendLogs_FILE = 0;
				int splitedFileNo_talendLogs_FILE = 0;
				int currentRow_talendLogs_FILE = 0;

				final String OUT_DELIM_talendLogs_FILE = /**
				 * Start field
				 * talendLogs_FILE:FIELDSEPARATOR
				 */
				";"/** End field talendLogs_FILE:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_talendLogs_FILE = /**
				 * Start field
				 * talendLogs_FILE:ROWSEPARATOR
				 */
				"\n"/** End field talendLogs_FILE:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_talendLogs_FILE != null
						&& directory_talendLogs_FILE.trim().length() != 0) {
					java.io.File dir_talendLogs_FILE = new java.io.File(
							directory_talendLogs_FILE);
					if (!dir_talendLogs_FILE.exists()) {
						dir_talendLogs_FILE.mkdirs();
					}
				}

				// routines.system.Row
				java.io.Writer outtalendLogs_FILE = null;

				outtalendLogs_FILE = new java.io.BufferedWriter(
						new java.io.OutputStreamWriter(
								new java.io.FileOutputStream(
										fileName_talendLogs_FILE, true),
								"UTF-8"));

				resourceMap.put("out_talendLogs_FILE", outtalendLogs_FILE);
				resourceMap.put("nb_line_talendLogs_FILE",
						nb_line_talendLogs_FILE);

				/**
				 * [talendLogs_FILE begin ] stop
				 */

				/**
				 * [talendLogs_LOGS begin ] start
				 */

				ok_Hash.put("talendLogs_LOGS", false);
				start_Hash.put("talendLogs_LOGS", System.currentTimeMillis());

				currentVirtualComponent = "talendLogs_LOGS";

				currentComponent = "talendLogs_LOGS";

				int tos_count_talendLogs_LOGS = 0;

				try {
					for (LogCatcherUtils.LogCatcherMessage lcm : talendLogs_LOGS
							.getMessages()) {
						row_talendLogs_LOGS.type = lcm.getType();
						row_talendLogs_LOGS.origin = (lcm.getOrigin() == null
								|| lcm.getOrigin().length() < 1 ? null : lcm
								.getOrigin());
						row_talendLogs_LOGS.priority = lcm.getPriority();
						row_talendLogs_LOGS.message = lcm.getMessage();
						row_talendLogs_LOGS.code = lcm.getCode();

						row_talendLogs_LOGS.moment = java.util.Calendar
								.getInstance().getTime();

						row_talendLogs_LOGS.pid = pid;
						row_talendLogs_LOGS.root_pid = rootPid;
						row_talendLogs_LOGS.father_pid = fatherPid;

						row_talendLogs_LOGS.project = projectName;
						row_talendLogs_LOGS.job = jobName;
						row_talendLogs_LOGS.context = contextStr;

						/**
						 * [talendLogs_LOGS begin ] stop
						 */

						/**
						 * [talendLogs_LOGS main ] start
						 */

						currentVirtualComponent = "talendLogs_LOGS";

						currentComponent = "talendLogs_LOGS";

						tos_count_talendLogs_LOGS++;

						/**
						 * [talendLogs_LOGS main ] stop
						 */

						/**
						 * [talendLogs_LOGS process_data_begin ] start
						 */

						currentVirtualComponent = "talendLogs_LOGS";

						currentComponent = "talendLogs_LOGS";

						/**
						 * [talendLogs_LOGS process_data_begin ] stop
						 */

						/**
						 * [talendLogs_FILE main ] start
						 */

						currentVirtualComponent = "talendLogs_FILE";

						currentComponent = "talendLogs_FILE";

						// Main
						// row_talendLogs_LOGS

						if (execStat) {
							runStat.updateStatOnConnection("Main" + iterateId,
									1, 1);
						}

						StringBuilder sb_talendLogs_FILE = new StringBuilder();
						if (row_talendLogs_LOGS.moment != null) {
							sb_talendLogs_FILE.append(FormatterUtils
									.format_Date(row_talendLogs_LOGS.moment,
											"yyyy-MM-dd HH:mm:ss"));
						}
						sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);
						if (row_talendLogs_LOGS.pid != null) {
							sb_talendLogs_FILE.append(row_talendLogs_LOGS.pid);
						}
						sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);
						if (row_talendLogs_LOGS.root_pid != null) {
							sb_talendLogs_FILE
									.append(row_talendLogs_LOGS.root_pid);
						}
						sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);
						if (row_talendLogs_LOGS.father_pid != null) {
							sb_talendLogs_FILE
									.append(row_talendLogs_LOGS.father_pid);
						}
						sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);
						if (row_talendLogs_LOGS.project != null) {
							sb_talendLogs_FILE
									.append(row_talendLogs_LOGS.project);
						}
						sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);
						if (row_talendLogs_LOGS.job != null) {
							sb_talendLogs_FILE.append(row_talendLogs_LOGS.job);
						}
						sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);
						if (row_talendLogs_LOGS.context != null) {
							sb_talendLogs_FILE
									.append(row_talendLogs_LOGS.context);
						}
						sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);
						if (row_talendLogs_LOGS.priority != null) {
							sb_talendLogs_FILE
									.append(row_talendLogs_LOGS.priority);
						}
						sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);
						if (row_talendLogs_LOGS.type != null) {
							sb_talendLogs_FILE.append(row_talendLogs_LOGS.type);
						}
						sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);
						if (row_talendLogs_LOGS.origin != null) {
							sb_talendLogs_FILE
									.append(row_talendLogs_LOGS.origin);
						}
						sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);
						if (row_talendLogs_LOGS.message != null) {
							sb_talendLogs_FILE
									.append(row_talendLogs_LOGS.message);
						}
						sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);
						if (row_talendLogs_LOGS.code != null) {
							sb_talendLogs_FILE.append(row_talendLogs_LOGS.code);
						}
						sb_talendLogs_FILE
								.append(OUT_DELIM_ROWSEP_talendLogs_FILE);

						nb_line_talendLogs_FILE++;
						resourceMap.put("nb_line_talendLogs_FILE",
								nb_line_talendLogs_FILE);

						outtalendLogs_FILE.write(sb_talendLogs_FILE.toString());

						row_talendLogs_FILE = row_talendLogs_LOGS;

						tos_count_talendLogs_FILE++;

						/**
						 * [talendLogs_FILE main ] stop
						 */

						/**
						 * [talendLogs_FILE process_data_begin ] start
						 */

						currentVirtualComponent = "talendLogs_FILE";

						currentComponent = "talendLogs_FILE";

						/**
						 * [talendLogs_FILE process_data_begin ] stop
						 */

						/**
						 * [talendLogs_CONSOLE main ] start
						 */

						currentVirtualComponent = "talendLogs_CONSOLE";

						currentComponent = "talendLogs_CONSOLE";

						// Main
						// row_talendLogs_FILE

						if (execStat) {
							runStat.updateStatOnConnection("Main" + iterateId,
									1, 1);
						}

						// /////////////////////

						strBuffer_talendLogs_CONSOLE = new StringBuilder();

						if (row_talendLogs_FILE.moment != null) { //

							strBuffer_talendLogs_CONSOLE.append(FormatterUtils
									.format_Date(row_talendLogs_FILE.moment,
											"yyyy-MM-dd HH:mm:ss"));

						} //

						strBuffer_talendLogs_CONSOLE.append("|");

						if (row_talendLogs_FILE.pid != null) { //

							strBuffer_talendLogs_CONSOLE.append(String
									.valueOf(row_talendLogs_FILE.pid));

						} //

						strBuffer_talendLogs_CONSOLE.append("|");

						if (row_talendLogs_FILE.root_pid != null) { //

							strBuffer_talendLogs_CONSOLE.append(String
									.valueOf(row_talendLogs_FILE.root_pid));

						} //

						strBuffer_talendLogs_CONSOLE.append("|");

						if (row_talendLogs_FILE.father_pid != null) { //

							strBuffer_talendLogs_CONSOLE.append(String
									.valueOf(row_talendLogs_FILE.father_pid));

						} //

						strBuffer_talendLogs_CONSOLE.append("|");

						if (row_talendLogs_FILE.project != null) { //

							strBuffer_talendLogs_CONSOLE.append(String
									.valueOf(row_talendLogs_FILE.project));

						} //

						strBuffer_talendLogs_CONSOLE.append("|");

						if (row_talendLogs_FILE.job != null) { //

							strBuffer_talendLogs_CONSOLE.append(String
									.valueOf(row_talendLogs_FILE.job));

						} //

						strBuffer_talendLogs_CONSOLE.append("|");

						if (row_talendLogs_FILE.context != null) { //

							strBuffer_talendLogs_CONSOLE.append(String
									.valueOf(row_talendLogs_FILE.context));

						} //

						strBuffer_talendLogs_CONSOLE.append("|");

						if (row_talendLogs_FILE.priority != null) { //

							strBuffer_talendLogs_CONSOLE.append(String
									.valueOf(row_talendLogs_FILE.priority));

						} //

						strBuffer_talendLogs_CONSOLE.append("|");

						if (row_talendLogs_FILE.type != null) { //

							strBuffer_talendLogs_CONSOLE.append(String
									.valueOf(row_talendLogs_FILE.type));

						} //

						strBuffer_talendLogs_CONSOLE.append("|");

						if (row_talendLogs_FILE.origin != null) { //

							strBuffer_talendLogs_CONSOLE.append(String
									.valueOf(row_talendLogs_FILE.origin));

						} //

						strBuffer_talendLogs_CONSOLE.append("|");

						if (row_talendLogs_FILE.message != null) { //

							strBuffer_talendLogs_CONSOLE.append(String
									.valueOf(row_talendLogs_FILE.message));

						} //

						strBuffer_talendLogs_CONSOLE.append("|");

						if (row_talendLogs_FILE.code != null) { //

							strBuffer_talendLogs_CONSOLE.append(String
									.valueOf(row_talendLogs_FILE.code));

						} //

						if (globalMap.get("tLogRow_CONSOLE") != null) {
							consoleOut_talendLogs_CONSOLE = (java.io.PrintStream) globalMap
									.get("tLogRow_CONSOLE");
						} else {
							consoleOut_talendLogs_CONSOLE = new java.io.PrintStream(
									new java.io.BufferedOutputStream(System.out));
							globalMap.put("tLogRow_CONSOLE",
									consoleOut_talendLogs_CONSOLE);
						}
						consoleOut_talendLogs_CONSOLE
								.println(strBuffer_talendLogs_CONSOLE
										.toString());
						consoleOut_talendLogs_CONSOLE.flush();
						nb_line_talendLogs_CONSOLE++;
						// ////

						// ////

						// /////////////////////

						tos_count_talendLogs_CONSOLE++;

						/**
						 * [talendLogs_CONSOLE main ] stop
						 */

						/**
						 * [talendLogs_CONSOLE process_data_begin ] start
						 */

						currentVirtualComponent = "talendLogs_CONSOLE";

						currentComponent = "talendLogs_CONSOLE";

						/**
						 * [talendLogs_CONSOLE process_data_begin ] stop
						 */

						/**
						 * [talendLogs_CONSOLE process_data_end ] start
						 */

						currentVirtualComponent = "talendLogs_CONSOLE";

						currentComponent = "talendLogs_CONSOLE";

						/**
						 * [talendLogs_CONSOLE process_data_end ] stop
						 */

						/**
						 * [talendLogs_FILE process_data_end ] start
						 */

						currentVirtualComponent = "talendLogs_FILE";

						currentComponent = "talendLogs_FILE";

						/**
						 * [talendLogs_FILE process_data_end ] stop
						 */

						/**
						 * [talendLogs_LOGS process_data_end ] start
						 */

						currentVirtualComponent = "talendLogs_LOGS";

						currentComponent = "talendLogs_LOGS";

						/**
						 * [talendLogs_LOGS process_data_end ] stop
						 */

						/**
						 * [talendLogs_LOGS end ] start
						 */

						currentVirtualComponent = "talendLogs_LOGS";

						currentComponent = "talendLogs_LOGS";

					}
				} catch (Exception e_talendLogs_LOGS) {
					logIgnoredError(
							String.format(
									"talendLogs_LOGS - tLogCatcher failed to process log message(s) due to internal error: %s",
									e_talendLogs_LOGS), e_talendLogs_LOGS);
				}

				ok_Hash.put("talendLogs_LOGS", true);
				end_Hash.put("talendLogs_LOGS", System.currentTimeMillis());

				/**
				 * [talendLogs_LOGS end ] stop
				 */

				/**
				 * [talendLogs_FILE end ] start
				 */

				currentVirtualComponent = "talendLogs_FILE";

				currentComponent = "talendLogs_FILE";

				if (outtalendLogs_FILE != null) {
					outtalendLogs_FILE.flush();
					outtalendLogs_FILE.close();
				}

				globalMap.put("talendLogs_FILE_NB_LINE",
						nb_line_talendLogs_FILE);
				globalMap.put("talendLogs_FILE_FILE_NAME",
						fileName_talendLogs_FILE);

				resourceMap.put("finish_talendLogs_FILE", true);

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("Main" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("talendLogs_FILE", true);
				end_Hash.put("talendLogs_FILE", System.currentTimeMillis());

				/**
				 * [talendLogs_FILE end ] stop
				 */

				/**
				 * [talendLogs_CONSOLE end ] start
				 */

				currentVirtualComponent = "talendLogs_CONSOLE";

				currentComponent = "talendLogs_CONSOLE";

				// ////
				// ////
				globalMap.put("talendLogs_CONSOLE_NB_LINE",
						nb_line_talendLogs_CONSOLE);

				// /////////////////////

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("Main" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("talendLogs_CONSOLE", true);
				end_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());

				/**
				 * [talendLogs_CONSOLE end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [talendLogs_LOGS finally ] start
				 */

				currentVirtualComponent = "talendLogs_LOGS";

				currentComponent = "talendLogs_LOGS";

				/**
				 * [talendLogs_LOGS finally ] stop
				 */

				/**
				 * [talendLogs_FILE finally ] start
				 */

				currentVirtualComponent = "talendLogs_FILE";

				currentComponent = "talendLogs_FILE";

				if (resourceMap.get("finish_talendLogs_FILE") == null) {

					java.io.Writer outtalendLogs_FILE = (java.io.Writer) resourceMap
							.get("out_talendLogs_FILE");
					if (outtalendLogs_FILE != null) {
						outtalendLogs_FILE.flush();
						outtalendLogs_FILE.close();
					}

				}

				/**
				 * [talendLogs_FILE finally ] stop
				 */

				/**
				 * [talendLogs_CONSOLE finally ] start
				 */

				currentVirtualComponent = "talendLogs_CONSOLE";

				currentComponent = "talendLogs_CONSOLE";

				/**
				 * [talendLogs_CONSOLE finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 1);
	}

	public static class row_talendMeter_FILEStruct implements
			routines.system.IPersistableRow<row_talendMeter_FILEStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String label;

		public String getLabel() {
			return this.label;
		}

		public Integer count;

		public Integer getCount() {
			return this.count;
		}

		public Integer reference;

		public Integer getReference() {
			return this.reference;
		}

		public String thresholds;

		public String getThresholds() {
			return this.thresholds;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.father_pid = readString(dis);

					this.root_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.label = readString(dis);

					this.count = readInteger(dis);

					this.reference = readInteger(dis);

					this.thresholds = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.root_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.label, dos);

				// Integer

				writeInteger(this.count, dos);

				// Integer

				writeInteger(this.reference, dos);

				// String

				writeString(this.thresholds, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",label=" + label);
			sb.append(",count=" + String.valueOf(count));
			sb.append(",reference=" + String.valueOf(reference));
			sb.append(",thresholds=" + thresholds);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendMeter_FILEStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row_talendMeter_METTERStruct implements
			routines.system.IPersistableRow<row_talendMeter_METTERStruct> {
		final static byte[] commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4 = new byte[0];
		static byte[] commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String label;

		public String getLabel() {
			return this.label;
		}

		public Integer count;

		public Integer getCount() {
			return this.count;
		}

		public Integer reference;

		public Integer getReference() {
			return this.reference;
		}

		public String thresholds;

		public String getThresholds() {
			return this.thresholds;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_SAMPLE_Copy_of_Sort_files_4.length) {
					if (length < 1024
							&& commonByteArray_SAMPLE_Copy_of_Sort_files_4.length == 0) {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[1024];
					} else {
						commonByteArray_SAMPLE_Copy_of_Sort_files_4 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0,
						length);
				strReturn = new String(
						commonByteArray_SAMPLE_Copy_of_Sort_files_4, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_SAMPLE_Copy_of_Sort_files_4) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.father_pid = readString(dis);

					this.root_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.label = readString(dis);

					this.count = readInteger(dis);

					this.reference = readInteger(dis);

					this.thresholds = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.root_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.label, dos);

				// Integer

				writeInteger(this.count, dos);

				// Integer

				writeInteger(this.reference, dos);

				// String

				writeString(this.thresholds, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",label=" + label);
			sb.append(",count=" + String.valueOf(count));
			sb.append(",reference=" + String.valueOf(reference));
			sb.append(",thresholds=" + thresholds);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendMeter_METTERStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void talendMeter_METTERProcess(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception()
						.getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row_talendMeter_METTERStruct row_talendMeter_METTER = new row_talendMeter_METTERStruct();
				row_talendMeter_METTERStruct row_talendMeter_FILE = row_talendMeter_METTER;

				/**
				 * [talendMeter_CONSOLE begin ] start
				 */

				ok_Hash.put("talendMeter_CONSOLE", false);
				start_Hash.put("talendMeter_CONSOLE",
						System.currentTimeMillis());

				currentVirtualComponent = "talendMeter_CONSOLE";

				currentComponent = "talendMeter_CONSOLE";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);

					}
				}

				int tos_count_talendMeter_CONSOLE = 0;

				// /////////////////////

				final String OUTPUT_FIELD_SEPARATOR_talendMeter_CONSOLE = "|";
				java.io.PrintStream consoleOut_talendMeter_CONSOLE = null;

				StringBuilder strBuffer_talendMeter_CONSOLE = null;
				int nb_line_talendMeter_CONSOLE = 0;
				// /////////////////////

				/**
				 * [talendMeter_CONSOLE begin ] stop
				 */

				/**
				 * [talendMeter_FILE begin ] start
				 */

				ok_Hash.put("talendMeter_FILE", false);
				start_Hash.put("talendMeter_FILE", System.currentTimeMillis());

				currentVirtualComponent = "talendMeter_FILE";

				currentComponent = "talendMeter_FILE";

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null) {

						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);

					}
				}

				int tos_count_talendMeter_FILE = 0;

				String fileName_talendMeter_FILE = "";
				fileName_talendMeter_FILE = (new java.io.File(
						"C:/Users/ruchiagarwal3/Documents/Ruchi- Deloitte/CDP 2.0/talend"
								+ "/" + "meter_file.xls")).getAbsolutePath()
						.replace("\\", "/");
				String fullName_talendMeter_FILE = null;
				String extension_talendMeter_FILE = null;
				String directory_talendMeter_FILE = null;
				if ((fileName_talendMeter_FILE.indexOf("/") != -1)) {
					if (fileName_talendMeter_FILE.lastIndexOf(".") < fileName_talendMeter_FILE
							.lastIndexOf("/")) {
						fullName_talendMeter_FILE = fileName_talendMeter_FILE;
						extension_talendMeter_FILE = "";
					} else {
						fullName_talendMeter_FILE = fileName_talendMeter_FILE
								.substring(0, fileName_talendMeter_FILE
										.lastIndexOf("."));
						extension_talendMeter_FILE = fileName_talendMeter_FILE
								.substring(fileName_talendMeter_FILE
										.lastIndexOf("."));
					}
					directory_talendMeter_FILE = fileName_talendMeter_FILE
							.substring(0,
									fileName_talendMeter_FILE.lastIndexOf("/"));
				} else {
					if (fileName_talendMeter_FILE.lastIndexOf(".") != -1) {
						fullName_talendMeter_FILE = fileName_talendMeter_FILE
								.substring(0, fileName_talendMeter_FILE
										.lastIndexOf("."));
						extension_talendMeter_FILE = fileName_talendMeter_FILE
								.substring(fileName_talendMeter_FILE
										.lastIndexOf("."));
					} else {
						fullName_talendMeter_FILE = fileName_talendMeter_FILE;
						extension_talendMeter_FILE = "";
					}
					directory_talendMeter_FILE = "";
				}
				boolean isFileGenerated_talendMeter_FILE = true;
				java.io.File filetalendMeter_FILE = new java.io.File(
						fileName_talendMeter_FILE);
				globalMap.put("talendMeter_FILE_FILE_NAME",
						fileName_talendMeter_FILE);
				if (filetalendMeter_FILE.exists()) {
					isFileGenerated_talendMeter_FILE = false;
				}
				int nb_line_talendMeter_FILE = 0;
				int splitedFileNo_talendMeter_FILE = 0;
				int currentRow_talendMeter_FILE = 0;

				final String OUT_DELIM_talendMeter_FILE = /**
				 * Start field
				 * talendMeter_FILE:FIELDSEPARATOR
				 */
				";"/** End field talendMeter_FILE:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_talendMeter_FILE = /**
				 * Start field
				 * talendMeter_FILE:ROWSEPARATOR
				 */
				"\n"/** End field talendMeter_FILE:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_talendMeter_FILE != null
						&& directory_talendMeter_FILE.trim().length() != 0) {
					java.io.File dir_talendMeter_FILE = new java.io.File(
							directory_talendMeter_FILE);
					if (!dir_talendMeter_FILE.exists()) {
						dir_talendMeter_FILE.mkdirs();
					}
				}

				// routines.system.Row
				java.io.Writer outtalendMeter_FILE = null;

				outtalendMeter_FILE = new java.io.BufferedWriter(
						new java.io.OutputStreamWriter(
								new java.io.FileOutputStream(
										fileName_talendMeter_FILE, true),
								"UTF-8"));

				resourceMap.put("out_talendMeter_FILE", outtalendMeter_FILE);
				resourceMap.put("nb_line_talendMeter_FILE",
						nb_line_talendMeter_FILE);

				/**
				 * [talendMeter_FILE begin ] stop
				 */

				/**
				 * [talendMeter_METTER begin ] start
				 */

				ok_Hash.put("talendMeter_METTER", false);
				start_Hash
						.put("talendMeter_METTER", System.currentTimeMillis());

				currentVirtualComponent = "talendMeter_METTER";

				currentComponent = "talendMeter_METTER";

				int tos_count_talendMeter_METTER = 0;

				for (MetterCatcherUtils.MetterCatcherMessage mcm : talendMeter_METTER
						.getMessages()) {
					row_talendMeter_METTER.pid = pid;
					row_talendMeter_METTER.root_pid = rootPid;
					row_talendMeter_METTER.father_pid = fatherPid;
					row_talendMeter_METTER.project = projectName;
					row_talendMeter_METTER.job = jobName;
					row_talendMeter_METTER.context = contextStr;
					row_talendMeter_METTER.origin = (mcm.getOrigin() == null
							|| mcm.getOrigin().length() < 1 ? null : mcm
							.getOrigin());
					row_talendMeter_METTER.moment = mcm.getMoment();
					row_talendMeter_METTER.job_version = mcm.getJobVersion();
					row_talendMeter_METTER.job_repository_id = mcm.getJobId();
					row_talendMeter_METTER.system_pid = mcm.getSystemPid();
					row_talendMeter_METTER.label = mcm.getLabel();
					row_talendMeter_METTER.count = mcm.getCount();
					row_talendMeter_METTER.reference = talendMeter_METTER
							.getConnLinesCount(mcm.getReferense() + "_count");
					row_talendMeter_METTER.thresholds = mcm.getThresholds();

					/**
					 * [talendMeter_METTER begin ] stop
					 */

					/**
					 * [talendMeter_METTER main ] start
					 */

					currentVirtualComponent = "talendMeter_METTER";

					currentComponent = "talendMeter_METTER";

					tos_count_talendMeter_METTER++;

					/**
					 * [talendMeter_METTER main ] stop
					 */

					/**
					 * [talendMeter_METTER process_data_begin ] start
					 */

					currentVirtualComponent = "talendMeter_METTER";

					currentComponent = "talendMeter_METTER";

					/**
					 * [talendMeter_METTER process_data_begin ] stop
					 */

					/**
					 * [talendMeter_FILE main ] start
					 */

					currentVirtualComponent = "talendMeter_FILE";

					currentComponent = "talendMeter_FILE";

					// Main
					// row_talendMeter_METTER

					if (execStat) {
						runStat.updateStatOnConnection("Main" + iterateId, 1, 1);
					}

					StringBuilder sb_talendMeter_FILE = new StringBuilder();
					if (row_talendMeter_METTER.moment != null) {
						sb_talendMeter_FILE.append(FormatterUtils.format_Date(
								row_talendMeter_METTER.moment,
								"yyyy-MM-dd HH:mm:ss"));
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.pid != null) {
						sb_talendMeter_FILE.append(row_talendMeter_METTER.pid);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.father_pid != null) {
						sb_talendMeter_FILE
								.append(row_talendMeter_METTER.father_pid);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.root_pid != null) {
						sb_talendMeter_FILE
								.append(row_talendMeter_METTER.root_pid);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.system_pid != null) {
						sb_talendMeter_FILE
								.append(row_talendMeter_METTER.system_pid);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.project != null) {
						sb_talendMeter_FILE
								.append(row_talendMeter_METTER.project);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.job != null) {
						sb_talendMeter_FILE.append(row_talendMeter_METTER.job);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.job_repository_id != null) {
						sb_talendMeter_FILE
								.append(row_talendMeter_METTER.job_repository_id);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.job_version != null) {
						sb_talendMeter_FILE
								.append(row_talendMeter_METTER.job_version);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.context != null) {
						sb_talendMeter_FILE
								.append(row_talendMeter_METTER.context);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.origin != null) {
						sb_talendMeter_FILE
								.append(row_talendMeter_METTER.origin);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.label != null) {
						sb_talendMeter_FILE
								.append(row_talendMeter_METTER.label);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.count != null) {
						sb_talendMeter_FILE
								.append(row_talendMeter_METTER.count);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.reference != null) {
						sb_talendMeter_FILE
								.append(row_talendMeter_METTER.reference);
					}
					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);
					if (row_talendMeter_METTER.thresholds != null) {
						sb_talendMeter_FILE
								.append(row_talendMeter_METTER.thresholds);
					}
					sb_talendMeter_FILE
							.append(OUT_DELIM_ROWSEP_talendMeter_FILE);

					nb_line_talendMeter_FILE++;
					resourceMap.put("nb_line_talendMeter_FILE",
							nb_line_talendMeter_FILE);

					outtalendMeter_FILE.write(sb_talendMeter_FILE.toString());

					row_talendMeter_FILE = row_talendMeter_METTER;

					tos_count_talendMeter_FILE++;

					/**
					 * [talendMeter_FILE main ] stop
					 */

					/**
					 * [talendMeter_FILE process_data_begin ] start
					 */

					currentVirtualComponent = "talendMeter_FILE";

					currentComponent = "talendMeter_FILE";

					/**
					 * [talendMeter_FILE process_data_begin ] stop
					 */

					/**
					 * [talendMeter_CONSOLE main ] start
					 */

					currentVirtualComponent = "talendMeter_CONSOLE";

					currentComponent = "talendMeter_CONSOLE";

					// Main
					// row_talendMeter_FILE

					if (execStat) {
						runStat.updateStatOnConnection("Main" + iterateId, 1, 1);
					}

					// /////////////////////

					strBuffer_talendMeter_CONSOLE = new StringBuilder();

					if (row_talendMeter_FILE.moment != null) { //

						strBuffer_talendMeter_CONSOLE.append(FormatterUtils
								.format_Date(row_talendMeter_FILE.moment,
										"yyyy-MM-dd HH:mm:ss"));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.pid != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.pid));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.father_pid != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.father_pid));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.root_pid != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.root_pid));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.system_pid != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.system_pid));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.project != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.project));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.job != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.job));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.job_repository_id != null) { //

						strBuffer_talendMeter_CONSOLE
								.append(String
										.valueOf(row_talendMeter_FILE.job_repository_id));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.job_version != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.job_version));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.context != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.context));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.origin != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.origin));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.label != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.label));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.count != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.count));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.reference != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.reference));

					} //

					strBuffer_talendMeter_CONSOLE.append("|");

					if (row_talendMeter_FILE.thresholds != null) { //

						strBuffer_talendMeter_CONSOLE.append(String
								.valueOf(row_talendMeter_FILE.thresholds));

					} //

					if (globalMap.get("tLogRow_CONSOLE") != null) {
						consoleOut_talendMeter_CONSOLE = (java.io.PrintStream) globalMap
								.get("tLogRow_CONSOLE");
					} else {
						consoleOut_talendMeter_CONSOLE = new java.io.PrintStream(
								new java.io.BufferedOutputStream(System.out));
						globalMap.put("tLogRow_CONSOLE",
								consoleOut_talendMeter_CONSOLE);
					}
					consoleOut_talendMeter_CONSOLE
							.println(strBuffer_talendMeter_CONSOLE.toString());
					consoleOut_talendMeter_CONSOLE.flush();
					nb_line_talendMeter_CONSOLE++;
					// ////

					// ////

					// /////////////////////

					tos_count_talendMeter_CONSOLE++;

					/**
					 * [talendMeter_CONSOLE main ] stop
					 */

					/**
					 * [talendMeter_CONSOLE process_data_begin ] start
					 */

					currentVirtualComponent = "talendMeter_CONSOLE";

					currentComponent = "talendMeter_CONSOLE";

					/**
					 * [talendMeter_CONSOLE process_data_begin ] stop
					 */

					/**
					 * [talendMeter_CONSOLE process_data_end ] start
					 */

					currentVirtualComponent = "talendMeter_CONSOLE";

					currentComponent = "talendMeter_CONSOLE";

					/**
					 * [talendMeter_CONSOLE process_data_end ] stop
					 */

					/**
					 * [talendMeter_FILE process_data_end ] start
					 */

					currentVirtualComponent = "talendMeter_FILE";

					currentComponent = "talendMeter_FILE";

					/**
					 * [talendMeter_FILE process_data_end ] stop
					 */

					/**
					 * [talendMeter_METTER process_data_end ] start
					 */

					currentVirtualComponent = "talendMeter_METTER";

					currentComponent = "talendMeter_METTER";

					/**
					 * [talendMeter_METTER process_data_end ] stop
					 */

					/**
					 * [talendMeter_METTER end ] start
					 */

					currentVirtualComponent = "talendMeter_METTER";

					currentComponent = "talendMeter_METTER";

				}

				ok_Hash.put("talendMeter_METTER", true);
				end_Hash.put("talendMeter_METTER", System.currentTimeMillis());

				/**
				 * [talendMeter_METTER end ] stop
				 */

				/**
				 * [talendMeter_FILE end ] start
				 */

				currentVirtualComponent = "talendMeter_FILE";

				currentComponent = "talendMeter_FILE";

				if (outtalendMeter_FILE != null) {
					outtalendMeter_FILE.flush();
					outtalendMeter_FILE.close();
				}

				globalMap.put("talendMeter_FILE_NB_LINE",
						nb_line_talendMeter_FILE);
				globalMap.put("talendMeter_FILE_FILE_NAME",
						fileName_talendMeter_FILE);

				resourceMap.put("finish_talendMeter_FILE", true);

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("Main" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("talendMeter_FILE", true);
				end_Hash.put("talendMeter_FILE", System.currentTimeMillis());

				/**
				 * [talendMeter_FILE end ] stop
				 */

				/**
				 * [talendMeter_CONSOLE end ] start
				 */

				currentVirtualComponent = "talendMeter_CONSOLE";

				currentComponent = "talendMeter_CONSOLE";

				// ////
				// ////
				globalMap.put("talendMeter_CONSOLE_NB_LINE",
						nb_line_talendMeter_CONSOLE);

				// /////////////////////

				if (execStat) {
					if (resourceMap.get("inIterateVComp") == null
							|| !((Boolean) resourceMap.get("inIterateVComp"))) {
						runStat.updateStatOnConnection("Main" + iterateId, 2, 0);
					}
				}

				ok_Hash.put("talendMeter_CONSOLE", true);
				end_Hash.put("talendMeter_CONSOLE", System.currentTimeMillis());

				/**
				 * [talendMeter_CONSOLE end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [talendMeter_METTER finally ] start
				 */

				currentVirtualComponent = "talendMeter_METTER";

				currentComponent = "talendMeter_METTER";

				/**
				 * [talendMeter_METTER finally ] stop
				 */

				/**
				 * [talendMeter_FILE finally ] start
				 */

				currentVirtualComponent = "talendMeter_FILE";

				currentComponent = "talendMeter_FILE";

				if (resourceMap.get("finish_talendMeter_FILE") == null) {

					java.io.Writer outtalendMeter_FILE = (java.io.Writer) resourceMap
							.get("out_talendMeter_FILE");
					if (outtalendMeter_FILE != null) {
						outtalendMeter_FILE.flush();
						outtalendMeter_FILE.close();
					}

				}

				/**
				 * [talendMeter_FILE finally ] stop
				 */

				/**
				 * [talendMeter_CONSOLE finally ] start
				 */

				currentVirtualComponent = "talendMeter_CONSOLE";

				currentComponent = "talendMeter_CONSOLE";

				/**
				 * [talendMeter_CONSOLE finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	private PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final Copy_of_Sort_files_4 Copy_of_Sort_files_4Class = new Copy_of_Sort_files_4();

		int exitCode = Copy_of_Sort_files_4Class.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket
				// can't open
				System.err.println("The statistics socket port " + portStats
						+ " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}

		try {
			// call job/subjob with an existing context, like:
			// --context=production. if without this parameter, there will use
			// the default context instead.
			java.io.InputStream inContext = Copy_of_Sort_files_4.class
					.getClassLoader().getResourceAsStream(
							"sample/copy_of_sort_files_4_0_1/contexts/"
									+ contextStr + ".properties");
			if (inContext == null) {
				inContext = Copy_of_Sort_files_4.class
						.getClassLoader()
						.getResourceAsStream(
								"config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				// defaultProps is in order to keep the original context value
				defaultProps.load(inContext);
				inContext.close();
				context = new ContextProperties(defaultProps);
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param
				// is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param
							.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			context.setContextType("InputFile", "id_String");

			context.InputFile = (String) context.getProperty("InputFile");
			context.setContextType("OutputFile", "id_String");

			context.OutputFile = (String) context.getProperty("OutputFile");
			context.setContextType("Host", "id_String");

			context.Host = (String) context.getProperty("Host");
			context.setContextType("Port", "id_String");

			context.Port = (String) context.getProperty("Port");
			context.setContextType("Database", "id_String");

			context.Database = (String) context.getProperty("Database");
			context.setContextType("Username", "id_String");

			context.Username = (String) context.getProperty("Username");
			context.setContextType("Password", "id_String");

			context.Password = (String) context.getProperty("Password");
			context.setContextType("Table", "id_String");

			context.Table = (String) context.getProperty("Table");
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
			if (parentContextMap.containsKey("InputFile")) {
				context.InputFile = (String) parentContextMap.get("InputFile");
			}
			if (parentContextMap.containsKey("OutputFile")) {
				context.OutputFile = (String) parentContextMap
						.get("OutputFile");
			}
			if (parentContextMap.containsKey("Host")) {
				context.Host = (String) parentContextMap.get("Host");
			}
			if (parentContextMap.containsKey("Port")) {
				context.Port = (String) parentContextMap.get("Port");
			}
			if (parentContextMap.containsKey("Database")) {
				context.Database = (String) parentContextMap.get("Database");
			}
			if (parentContextMap.containsKey("Username")) {
				context.Username = (String) parentContextMap.get("Username");
			}
			if (parentContextMap.containsKey("Password")) {
				context.Password = (String) parentContextMap.get("Password");
			}
			if (parentContextMap.containsKey("Table")) {
				context.Table = (String) parentContextMap.get("Table");
			}
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil
				.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName,
				jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName,
				parent_part_launcher, Thread.currentThread().getId() + "", "",
				"", "", "",
				resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();
		tStatCatcher_1.addMessage("begin");
		talendStats_STATS.addMessage("begin");

		this.globalResumeTicket = true;// to run tPreJob

		try {
			errorCode = null;
			tPrejob_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tPrejob_1) {
			globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

			e_tPrejob_1.printStackTrace();

		}

		try {
			tLogCatcher_1Process(globalMap);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
		try {
			talendStats_STATSProcess(globalMap);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputDelimited_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_1) {
			globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		if (false) {
			System.out
					.println((endUsedMemory - startUsedMemory)
							+ " bytes memory increase when running : Copy_of_Sort_files_4");
		}
		tStatCatcher_1.addMessage(status == "" ? "end" : status,
				(end - startTime));
		try {
			tLogCatcher_1Process(globalMap);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
		talendStats_STATS.addMessage(status == "" ? "end" : status,
				(end - startTime));
		try {
			talendStats_STATSProcess(globalMap);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;
		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher,
				Thread.currentThread().getId() + "", "", "" + returnCode, "",
				"", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index),
							keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index),
							keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		}

	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" },
			{ "\\'", "\'" }, { "\\r", "\r" }, { "\\f", "\f" }, { "\\b", "\b" },
			{ "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex,
							index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left
			// into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 384533 characters generated by Talend Real-time Big Data Platform on the June
 * 15, 2019 8:03:12 PM IST
 ************************************************************************************************/
